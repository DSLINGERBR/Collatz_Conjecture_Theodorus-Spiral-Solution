#!/usr/bin/env python3
"""Compara as chaves comuns das implementações A (Python) e B (C). Código 0 se idênticas."""
import json
import sys

a = json.load(open("resultados_loop_csc14_A.json", encoding="utf-8"))
b = json.load(open("resultados_loop_csc14_B.json", encoding="utf-8"))
ca, cb = a["chaves_comuns"], b["chaves_comuns"]
difs = [k for k in sorted(set(ca) | set(cb)) if ca.get(k) != cb.get(k)]
for k in sorted(set(ca) | set(cb)):
    print(f"  {k:<18} {'igual' if k not in difs else 'DIFERENTE'}")
ok = not difs and a["resumo"]["tudo_confere"] and b["tudo_confere"]
print("A e B CONCORDAM" if ok else "A e B DIVERGEM")
sys.exit(0 if ok else 1)
