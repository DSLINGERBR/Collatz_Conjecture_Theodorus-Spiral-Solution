/*
 * confere_laco_csc14.c — Teorema do loop da cossecante √14. Implementação B.
 *
 * Independente da implementação A: não lê nem chama loop_csc14.py. Só inteiros
 * (int64 e __int128). Contas exatas para n pequeno e certificados modulares que valem
 * para todo n:
 *   - posto 1 módulo 7: M' ≢ 0 e M'² ≡ 2·M' (mod 7) dão M'ⁿ ≡ 2ⁿ⁻¹·M' ≢ 0 (mod 7)
 *     para todo n ≥ 1, enquanto 91ⁿ·I ≡ 0 (mod 7); logo Rⁿ = M'ⁿ/91ⁿ ≠ I sempre;
 *   - o vetor Wₙ = M'ⁿ·(1,2,3) satisfaz Wₙ ≡ 2ⁿ⁻¹·(1,4,2) (mod 7): nenhuma coordenada
 *     é múltipla de 7, e 2Pₙ = Wₙ/91ⁿ tem valuação 7-ádica −n em cada coordenada;
 *   - Cₙ = 7ⁿ·Tₙ(6/7) e Dₖ = 7ᵏ·Uₖ(6/7): Cₙ ≡ 6·5ⁿ⁻¹ e Dₖ ≡ 5ᵏ (mod 7).
 *
 * Compilar:  gcc -O2 -std=gnu11 -o confere_laco_csc14 confere_laco_csc14.c
 * Executar:  ./confere_laco_csc14
 * Saída:     resumo na tela e resultados_loop_csc14_B.json; código 0 se tudo confere.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef long long i64;
typedef __int128 i128;

#define NMOD 1000000   /* iterações módulo 7 (conferência da indução) */
#define NEXATO 15      /* potências exatas em __int128 */
#define NESFERA 9      /* |Wₙ|² cabe em __int128 até n = 9 */
#define NTEO 10000000  /* passos de Teodoro classificados */

static long verificacoes = 0, falhas = 0;

static int confere(int ok, const char *onde) {
    verificacoes++;
    if (!ok) {
        falhas++;
        fprintf(stderr, "FALHA: %s\n", onde);
    }
    return ok;
}

/* ------------------------------------------------------------ inteiros */

static void imprime128(FILE *f, i128 x) {
    char buf[64];
    int i = 63, neg = x < 0;
    unsigned __int128 u = neg ? -(unsigned __int128)x : (unsigned __int128)x;
    buf[i] = '\0';
    do {
        buf[--i] = (char)('0' + (int)(u % 10));
        u /= 10;
    } while (u);
    if (neg) buf[--i] = '-';
    fputs(buf + i, f);
}

static i128 pot128(i128 b, int e) {
    i128 r = 1;
    while (e-- > 0) r *= b;
    return r;
}

static int mod7(i128 x) {
    int r = (int)(x % 7);
    return r < 0 ? r + 7 : r;
}

static void quat_mul(const i64 p[4], const i64 q[4], i64 r[4]) {
    r[0] = p[0] * q[0] - p[1] * q[1] - p[2] * q[2] - p[3] * q[3];
    r[1] = p[0] * q[1] + p[1] * q[0] + p[2] * q[3] - p[3] * q[2];
    r[2] = p[0] * q[2] - p[1] * q[3] + p[2] * q[0] + p[3] * q[1];
    r[3] = p[0] * q[3] + p[1] * q[2] - p[2] * q[1] + p[3] * q[0];
}

static i64 quat_norm2(const i64 q[4]) { return q[0] * q[0] + q[1] * q[1] + q[2] * q[2] + q[3] * q[3]; }

/* Euler–Rodrigues: R(q)/|q|² é a rotação X ↦ qXq⁻¹ */
static void rodrigues(const i64 q[4], i128 R[3][3]) {
    i64 a = q[0], b = q[1], c = q[2], d = q[3];
    R[0][0] = a * a + b * b - c * c - d * d; R[0][1] = 2 * (b * c - a * d); R[0][2] = 2 * (b * d + a * c);
    R[1][0] = 2 * (b * c + a * d); R[1][1] = a * a - b * b + c * c - d * d; R[1][2] = 2 * (c * d - a * b);
    R[2][0] = 2 * (b * d - a * c); R[2][1] = 2 * (c * d + a * b); R[2][2] = a * a - b * b - c * c + d * d;
}

static void mat_mul(i128 A[3][3], i128 B[3][3], i128 C[3][3]) {
    i128 T[3][3];
    for (int i = 0; i < 3; i++)
        for (int j = 0; j < 3; j++) {
            T[i][j] = 0;
            for (int k = 0; k < 3; k++) T[i][j] += A[i][k] * B[k][j];
        }
    memcpy(C, T, sizeof T);
}

static void mat_vec(i128 A[3][3], const i128 v[3], i128 w[3]) {
    i128 t[3];
    for (int i = 0; i < 3; i++) t[i] = A[i][0] * v[0] + A[i][1] * v[1] + A[i][2] * v[2];
    memcpy(w, t, sizeof t);
}

static int eh_escalar(i128 A[3][3], i128 s) {
    for (int i = 0; i < 3; i++)
        for (int j = 0; j < 3; j++)
            if (A[i][j] != (i == j ? s : 0)) return 0;
    return 1;
}

static i128 det3(i128 A[3][3]) {
    return A[0][0] * (A[1][1] * A[2][2] - A[1][2] * A[2][1])
         - A[0][1] * (A[1][0] * A[2][2] - A[1][2] * A[2][0])
         + A[0][2] * (A[1][0] * A[2][1] - A[1][1] * A[2][0]);
}

static i128 traco(i128 A[3][3]) { return A[0][0] + A[1][1] + A[2][2]; }

static void transposta(i128 A[3][3], i128 T[3][3]) {
    for (int i = 0; i < 3; i++)
        for (int j = 0; j < 3; j++) T[i][j] = A[j][i];
}

/* ------------------------------------------------------------ objetos (coordenadas dobradas: 2P inteiro) */

static const i64 A_FACE[3] = {0, 2, 3};      /* diagonal da face 2×3, quadrância 13 */
static const i64 D_DIAG[3] = {1, 2, 3};      /* 2P, diagonal da caixa, quadrância 14 */
static const i64 DP_LINHA[3] = {-1, 2, 3};   /* 2P' */
static const i64 Q_CSC[4] = {13, 0, 2, 3};
static const i64 B_CAIXA[4] = {1, 0, 2, 3};
static const i128 M_ESPERADA[3][3] = {{78, -39, 26}, {39, 82, 6}, {-26, 6, 87}};

/* ------------------------------------------------------------ certificados (sem efeito colateral) */

static int cert_triangulo(void) {
    /* vértices dobrados: −2P = (−1,−2,−3), 2P' = (−1,2,3), 2P = (1,2,3); quadrâncias ×4 */
    i64 mP[3] = {-1, -2, -3}, cat = 0, face = 0, diag = 0, reto = 0, du = 0, uu = 0, vv = 0;
    for (int i = 0; i < 3; i++) {
        i64 x = D_DIAG[i] - DP_LINHA[i], y = DP_LINHA[i] - mP[i], z = D_DIAG[i] - mP[i];
        cat += x * x; face += y * y; diag += z * z;
        reto += x * (mP[i] - DP_LINHA[i]);
        du += z * y; uu += z * z; vv += y * y;
    }
    /* spread em −P: 1 − (u·v)²/(|u|²|v|²) = 1/14  ⇔  14·(|u|²|v|² − (u·v)²) = |u|²|v|² */
    return cat == 4 && face == 52 && diag == 56 && reto == 0 && 14 * (uu * vv - du * du) == uu * vv;
}

static int cert_meio_angulo(const i64 q[4], const i64 eixo[3]) {
    const i64 *v = q + 1;
    i64 cx = v[1] * eixo[2] - v[2] * eixo[1], cy = v[2] * eixo[0] - v[0] * eixo[2], cz = v[0] * eixo[1] - v[1] * eixo[0];
    i64 dp = v[0] * eixo[0] + v[1] * eixo[1] + v[2] * eixo[2];
    i64 vv = v[0] * v[0] + v[1] * v[1] + v[2] * v[2];
    return cx == 0 && cy == 0 && cz == 0 && dp > 0 && 14 * vv == quat_norm2(q);
}

static int cert_rotacao(i128 M[3][3], i64 s, const i64 eixo[3]) {
    i128 T[3][3], P[3][3], e[3] = {eixo[0], eixo[1], eixo[2]}, w[3];
    transposta(M, T);
    mat_mul(M, T, P);
    mat_vec(M, e, w);
    return eh_escalar(P, (i128)s * s) && det3(M) == (i128)s * s * s &&
           w[0] == s * e[0] && w[1] == s * e[1] && w[2] == s * e[2];
}

/* posto 1 módulo 7: escala ≡ 0, M ≢ 0 e M² ≡ c·M com c = tr M ≢ 0 (mod 7) ⇒ Mⁿ ≢ 0 ≡ sⁿI para todo n */
static int cert_mod7(i128 M[3][3], i64 s) {
    i128 M7[3][3], Q[3][3];
    int nao_nulo = 0, c = mod7(traco(M));
    for (int i = 0; i < 3; i++)
        for (int j = 0; j < 3; j++) {
            M7[i][j] = mod7(M[i][j]);
            nao_nulo |= M7[i][j] != 0;
        }
    mat_mul(M7, M7, Q);
    for (int i = 0; i < 3; i++)
        for (int j = 0; j < 3; j++)
            if (mod7(Q[i][j]) != mod7((i128)c * M7[i][j])) return 0;
    return s % 7 == 0 && nao_nulo && c != 0;
}

static int cert_aberto_exato(i128 M[3][3], i64 s, int nmax) {
    i128 Mn[3][3] = {{1, 0, 0}, {0, 1, 0}, {0, 0, 1}}, sn = 1;
    for (int n = 1; n <= nmax; n++) {
        mat_mul(Mn, M, Mn);
        sn *= s;
        if (eh_escalar(Mn, sn)) return 0;
    }
    return 1;
}

static int fecha_em(i128 M[3][3], i64 s, int k) {
    i128 Mn[3][3] = {{1, 0, 0}, {0, 1, 0}, {0, 0, 1}}, sn = 1;
    for (int n = 1; n <= k; n++) {
        mat_mul(Mn, M, Mn);
        sn *= s;
    }
    return eh_escalar(Mn, sn);
}

static int ordem_exata(i128 M[3][3], i64 s, int kmax) {
    i128 Mn[3][3] = {{1, 0, 0}, {0, 1, 0}, {0, 0, 1}}, sn = 1;
    for (int n = 1; n <= kmax; n++) {
        mat_mul(Mn, M, Mn);
        sn *= s;
        if (eh_escalar(Mn, sn)) return n;
    }
    return 0;
}

/* Wₙ ≡ 2^(n−1+desloc)·(1,4,2) (mod 7) para 1 ≤ n ≤ nmax, por iteração módulo 7 */
static int cert_orbita_mod7(i128 M[3][3], int nmax, int desloc) {
    int M7[3][3], w[3] = {1, 2, 3}, p2 = 1;          /* p2 = 2^(n−1) mod 7 */
    for (int i = 0; i < 3; i++)
        for (int j = 0; j < 3; j++) M7[i][j] = mod7(M[i][j]);
    for (int d = 0; d < desloc; d++) p2 = p2 * 2 % 7;
    for (int n = 1; n <= nmax; n++) {
        int t[3];
        for (int i = 0; i < 3; i++) t[i] = (M7[i][0] * w[0] + M7[i][1] * w[1] + M7[i][2] * w[2]) % 7;
        memcpy(w, t, sizeof t);
        if (w[0] != p2 * 1 % 7 || w[1] != p2 * 4 % 7 || w[2] != p2 * 2 % 7) return 0;
        p2 = p2 * 2 % 7;
    }
    return 1;
}

/* produto q·b puro; R(q)R(b) = (|q|²|b|²/13)·(2aaᵀ − 13I); ponte por eixo_ponte leva 2P a 2P'; quadrado = I */
static int cert_meia_volta(const i64 q[4], const i64 b[4], const i64 eixo_ponte[3], i64 qb_out[4]) {
    i64 qb[4];
    i128 Rq[3][3], Rb[3][3], Pr[3][3], H13[3][3], Hu[3][3], Pr2[3][3];
    quat_mul(q, b, qb);
    if (qb_out) memcpy(qb_out, qb, sizeof qb);
    rodrigues(q, Rq);
    rodrigues(b, Rb);
    mat_mul(Rq, Rb, Pr);
    i64 nq = quat_norm2(q), nb = quat_norm2(b);
    for (int i = 0; i < 3; i++)
        for (int j = 0; j < 3; j++) H13[i][j] = 2 * A_FACE[i] * A_FACE[j] - (i == j ? 13 : 0);
    int igual = (nq * nb) % 13 == 0;
    for (int i = 0; i < 3 && igual; i++)
        for (int j = 0; j < 3; j++)
            if (Pr[i][j] != (i128)(nq * nb / 13) * H13[i][j]) igual = 0;
    i64 u2 = eixo_ponte[0] * eixo_ponte[0] + eixo_ponte[1] * eixo_ponte[1] + eixo_ponte[2] * eixo_ponte[2];
    for (int i = 0; i < 3; i++)
        for (int j = 0; j < 3; j++) Hu[i][j] = 2 * eixo_ponte[i] * eixo_ponte[j] - (i == j ? u2 : 0);
    i128 dp[3] = {D_DIAG[0], D_DIAG[1], D_DIAG[2]}, w[3];
    mat_vec(Hu, dp, w);
    int ponte = w[0] == u2 * DP_LINHA[0] && w[1] == u2 * DP_LINHA[1] && w[2] == u2 * DP_LINHA[2];
    mat_mul(Pr, Pr, Pr2);
    return qb[0] == 0 && igual && ponte && eh_escalar(Pr2, (i128)(nq * nb) * (nq * nb));
}

/* seno zero: sen² = 0 ⇒ sen²·csc² = 0 ≠ 1 para qualquer csc² alegado; K(10⁻ᵏ)² = 13·10²ᵏ + 1 */
static int cert_seno_zero(int com_alegacao, i64 csc2_alegado) {
    int ok = 1;
    i128 dez = 1;
    for (int k = 1; k <= 18; k++) {
        dez *= 100;                                   /* 10^(2k) */
        i128 K2_vezes_t2 = 13 * dez + 1;              /* (13 + t²)/t² com t = 10⁻ᵏ, multiplicado por 1 */
        ok &= K2_vezes_t2 > dez;                      /* cresce sem cota */
    }
    ok &= (13 + 1) == 14;                             /* K(1)² = 14 */
    if (com_alegacao) ok &= (0 * csc2_alegado == 1);  /* identidade sen²·csc² = 1 em seno zero */
    return ok;
}

/* T_{p,q} da seção 15.4: numerador (q² − 14p²)I + 2pqK + 2p²ddᵀ, escala q² + 14p² */
static void T_doc(i64 p, i64 q, i128 M[3][3], i64 *s) {
    const i64 d[3] = {1, 2, 3};
    i64 K[3][3] = {{0, -d[2], d[1]}, {d[2], 0, -d[0]}, {-d[1], d[0], 0}};
    for (int i = 0; i < 3; i++)
        for (int j = 0; j < 3; j++)
            M[i][j] = (i == j ? q * q - 14 * p * p : 0) + 2 * p * q * K[i][j] + 2 * p * p * d[i] * d[j];
    *s = q * q + 14 * p * p;
}

/* critério: fecha ⇔ 2cos = tr − 1 é inteiro em [−2, 2]; ordem 1, 6, 4, 3, 2 para 2cos = 2, 1, 0, −1, −2 */
static int ordem_pelo_criterio(i128 tr_num, i64 s) {
    i128 dois_cos_num = tr_num - s;
    if (dois_cos_num % s != 0) return 0;
    i128 k = dois_cos_num / s;
    switch ((int)k) {
        case 2: return 1;
        case 1: return 6;
        case 0: return 4;
        case -1: return 3;
        case -2: return 2;
        default: return 0;
    }
}

/* ------------------------------------------------------------ principal */

int main(void) {
    FILE *js = fopen("resultados_loop_csc14_B.json", "w");
    if (!js) { perror("json"); return 2; }

    /* P1 */
    int p1 = confere(cert_triangulo(), "P1 triângulo 1, √13, √14 e spread 1/14");

    /* P2 */
    i128 R[3][3], M[3][3];
    rodrigues(Q_CSC, R);
    int pares = 1, igual_lit = 1;
    for (int i = 0; i < 3; i++)
        for (int j = 0; j < 3; j++) {
            pares &= R[i][j] % 2 == 0;
            M[i][j] = R[i][j] / 2;
            igual_lit &= M[i][j] == M_ESPERADA[i][j];
        }
    int p2 = confere(pares && igual_lit, "P2 R(q) = 2M'");
    p2 &= confere(quat_norm2(Q_CSC) == 182, "P2 norma 182");
    p2 &= confere(cert_meio_angulo(Q_CSC, A_FACE), "P2 meio-ângulo θ em torno de a");
    p2 &= confere(cert_rotacao(M, 91, A_FACE), "P2 rotação exata");
    p2 &= confere(traco(M) == 247 && (247 - 91) * 7 == 12 * 91, "P2 tr = 19/7, cos 2θ = 6/7");

    /* P3: certificado para todo n + conferências */
    int p3 = confere(cert_mod7(M, 91), "P3 posto 1 módulo 7 (todo n)");
    {
        int Mm[3][3], Mn[3][3], p2n = 1, ok = 1;     /* Mn = M'ⁿ mod 7, p2n = 2ⁿ⁻¹ mod 7 */
        for (int i = 0; i < 3; i++)
            for (int j = 0; j < 3; j++) Mm[i][j] = Mn[i][j] = mod7(M[i][j]);
        for (int n = 2; n <= NMOD && ok; n++) {
            int T[3][3];
            p2n = p2n * 2 % 7;
            for (int i = 0; i < 3; i++)
                for (int j = 0; j < 3; j++)
                    T[i][j] = (Mn[i][0] * Mm[0][j] + Mn[i][1] * Mm[1][j] + Mn[i][2] * Mm[2][j]) % 7;
            memcpy(Mn, T, sizeof T);
            for (int i = 0; i < 3; i++)
                for (int j = 0; j < 3; j++) ok &= Mn[i][j] == p2n * Mm[i][j] % 7;
        }
        p3 &= confere(ok, "P3 M'ⁿ ≡ 2ⁿ⁻¹M' (mod 7), n ≤ 10⁶");
    }
    i128 C[21], Dk[21];
    C[0] = 1; C[1] = 6; Dk[0] = 1; Dk[1] = 12;
    for (int n = 1; n < 20; n++) {
        C[n + 1] = 12 * C[n] - 49 * C[n - 1];
        Dk[n + 1] = 12 * Dk[n] - 49 * Dk[n - 1];
    }
    {
        int ok = 1, c5 = 6, d5 = 1;                   /* 6·5ⁿ⁻¹ e 5ᵏ mod 7 */
        for (int n = 1; n <= 20; n++) {
            ok &= mod7(C[n]) == c5;
            c5 = c5 * 5 % 7;
        }
        for (int k = 0; k <= 20; k++) {
            ok &= mod7(Dk[k]) == d5;
            d5 = d5 * 5 % 7;
        }
        p3 &= confere(ok, "P3 Cₙ ≡ 6·5ⁿ⁻¹ e Dₖ ≡ 5ᵏ (mod 7)");
    }
    i128 W[NEXATO + 1][3];
    {
        i128 Mn[3][3] = {{1, 0, 0}, {0, 1, 0}, {0, 0, 1}}, w[3] = {1, 2, 3};
        int ok_ab = 1, ok_tr = 1, ok_w = 1, ok_pl = 1, ok_esf = 1, ok_v7 = 1, ok_ret = 1;
        for (int n = 1; n <= NEXATO; n++) {
            mat_mul(Mn, M, Mn);
            mat_vec(M, w, w);
            memcpy(W[n], w, sizeof w);
            i128 s91 = pot128(91, n), s13 = pot128(13, n), s7 = pot128(7, n);
            ok_ab &= !eh_escalar(Mn, s91);
            ok_tr &= traco(Mn) == s13 * (s7 + 2 * C[n]);
            ok_w &= w[0] == s13 * C[n] && w[1] == 2 * s91 + 3 * s13 * Dk[n - 1] && w[2] == 3 * s91 - 2 * s13 * Dk[n - 1];
            ok_pl &= 2 * w[1] + 3 * w[2] == 13 * s91;
            if (n <= NESFERA) ok_esf &= w[0] * w[0] + w[1] * w[1] + w[2] * w[2] == 14 * s91 * s91;
            ok_v7 &= mod7(w[0]) != 0 && mod7(w[1]) != 0 && mod7(w[2]) != 0;
            ok_ret &= !(w[0] == s91 * 1 && w[1] == s91 * 2 && w[2] == s91 * 3) &&
                      !(w[0] == -s91 && w[1] == s91 * 2 && w[2] == s91 * 3);
        }
        p3 &= confere(ok_ab, "P3 Rⁿ ≠ I exato, n ≤ 15");
        p3 &= confere(ok_tr, "P3 tr M'ⁿ = 13ⁿ(7ⁿ + 2Cₙ), n ≤ 15");
        int p4 = 1;
        p4 &= confere(ok_w, "P4 forma fechada de Wₙ, n ≤ 15");
        p4 &= confere(ok_pl, "P4 Pₙ no plano X·a = 13/2, n ≤ 15");
        p4 &= confere(ok_esf, "P4 Pₙ na esfera 𝒮, n ≤ 9");
        p4 &= confere(ok_v7, "P4 7 ∤ Wₙ (valuação −n), n ≤ 15");
        p4 &= confere(ok_ret, "P4 Pₙ ∉ {P, P'}, n ≤ 15");
        p4 &= confere(cert_orbita_mod7(M, NMOD, 0), "P4 Wₙ ≡ 2ⁿ⁻¹(1,4,2) (mod 7), n ≤ 10⁶");
        fprintf(js, "{\n \"P4_ok\": %d,\n", p4);
    }

    /* P5 */
    i64 qb[4];
    i64 ponte[3] = {D_DIAG[0] + DP_LINHA[0], D_DIAG[1] + DP_LINHA[1], D_DIAG[2] + DP_LINHA[2]};
    for (int i = 0; i < 3; i++) ponte[i] /= 2;       /* P + P' = (0,2,3) */
    int p5 = confere(cert_meia_volta(Q_CSC, B_CAIXA, ponte, qb), "P5 meia-volta q·b e ponte P → P'");

    /* P6 */
    int teo_n[8], teo_k[8], nteo = 0;
    for (i64 n = 1; n <= NTEO; n++)
        if ((2 * (n - 1)) % (n + 1) == 0) {
            if (nteo < 8) teo_n[nteo] = (int)n;
            nteo++;
        }
    int p6 = confere(nteo == 2 && teo_n[0] == 1 && teo_n[1] == 3, "P6 só n = 1 e n = 3 fecham");
    {
        i64 q1[4] = {1, 1, 0, 0}, q3[4] = {3, 1, 1, 1};
        i128 R1[3][3], R3[3][3];
        rodrigues(q1, R1);
        rodrigues(q3, R3);
        teo_k[0] = ordem_exata(R1, quat_norm2(q1), 12);
        teo_k[1] = ordem_exata(R3, quat_norm2(q3), 12);
        p6 &= confere(teo_k[0] == 4 && teo_k[1] == 6, "P6 ordens 4 e 6 exatas");
    }

    /* P7 */
    int p7 = confere(cert_seno_zero(0, 0), "P7 seno zero sem cossecante");

    /* P8 */
    const char *ids[6] = {"T_-1_3", "T_1_1", "M3", "M7", "Rq", "Rb"};
    int ordens[6], p8 = 1;
    {
        i128 A[6][3][3];
        i64 s[6];
        T_doc(-1, 3, A[0], &s[0]);
        T_doc(1, 1, A[1], &s[1]);
        { i64 q[4] = {1, 1, 1, 0}; rodrigues(q, A[2]); s[2] = 3; }
        for (int i = 0; i < 3; i++)
            for (int j = 0; j < 3; j++) A[3][i][j] = D_DIAG[i] * D_DIAG[j] - (i == j ? 7 : 0);
        s[3] = 7;
        rodrigues(Q_CSC, A[4]); s[4] = 182;
        rodrigues(B_CAIXA, A[5]); s[5] = 14;
        for (int c = 0; c < 6; c++) {
            i128 T[3][3], Pm[3][3];
            transposta(A[c], T);
            mat_mul(A[c], T, Pm);
            int rot = eh_escalar(Pm, (i128)s[c] * s[c]) && det3(A[c]) == (i128)s[c] * s[c] * s[c];
            ordens[c] = ordem_pelo_criterio(traco(A[c]), s[c]);
            int direta = ordem_exata(A[c], s[c], 12);
            p8 &= confere(rot && ordens[c] == direta, ids[c]);
        }
    }

    /* P10: Teodoro e o tetraedro regular de aresta √7 (referencial próprio, quadrância real = (7/2)·|x|²) */
    int p10 = 1;
    i128 E[64];                                       /* Eₖ = 3ᵏ·Tₖ(1/3): E₀ = 1, E₁ = 1, Eₖ₊₁ = 2Eₖ − 9Eₖ₋₁ */
    {
        i64 v[4][3] = {{1, 1, 1}, {1, 0, 0}, {0, 1, 0}, {0, 0, 1}};
        int ok = 1;
        for (int i = 0; i < 4; i++)
            for (int j = i + 1; j < 4; j++) {
                i64 d2 = 0;
                for (int k = 0; k < 3; k++) d2 += (v[i][k] - v[j][k]) * (v[i][k] - v[j][k]);
                ok &= d2 == 2;                        /* (7/2)·2 = 7 */
            }
        p10 &= confere(ok, "P10 seis arestas de quadrância 7");
        /* face: ângulo de 60° (2u·v = u·u); altura da face: (7/4) + (21/4) = 7, spread 1/4 no vértice → csc 2 */
        i64 u[3], w[3], uu = 0, uw = 0;
        for (int k = 0; k < 3; k++) { u[k] = v[2][k] - v[1][k]; w[k] = v[3][k] - v[1][k]; uu += u[k] * u[k]; uw += u[k] * w[k]; }
        /* coordenadas ×2: pé da altura m = (b+c)/2; a−b e a−m dobrados */
        i64 ab[3], am[3], ab2 = 0, am2 = 0, abam = 0;
        for (int k = 0; k < 3; k++) {
            ab[k] = 2 * (v[1][k] - v[2][k]);
            am[k] = 2 * v[1][k] - (v[2][k] + v[3][k]);
            ab2 += ab[k] * ab[k]; am2 += am[k] * am[k]; abam += ab[k] * am[k];
        }
        /* spread 1 − (ab·am)²/(|ab|²|am|²) = 1/4 ⇔ 4(|ab|²|am|² − (ab·am)²) = |ab|²|am|² */
        p10 &= confere(2 * uw == uu && 4 * (ab2 * am2 - abam * abam) == ab2 * am2, "P10 face 60° e Teodoro 1, √3, 2");
        /* diedro ao longo de bc: normais n1 = (b−a)×(c−a), n2 = (c−v0)×(b−v0); cos δ = −n1·n2/|n1|² = 1/3 */
        i64 x[3], y[3], z[3], t[3], n1[3], n2[3], n11 = 0, n22 = 0, n12 = 0;
        for (int k = 0; k < 3; k++) { x[k] = v[2][k] - v[1][k]; y[k] = v[3][k] - v[1][k]; z[k] = v[3][k] - v[0][k]; t[k] = v[2][k] - v[0][k]; }
        n1[0] = x[1] * y[2] - x[2] * y[1]; n1[1] = x[2] * y[0] - x[0] * y[2]; n1[2] = x[0] * y[1] - x[1] * y[0];
        n2[0] = z[1] * t[2] - z[2] * t[1]; n2[1] = z[2] * t[0] - z[0] * t[2]; n2[2] = z[0] * t[1] - z[1] * t[0];
        for (int k = 0; k < 3; k++) { n11 += n1[k] * n1[k]; n22 += n2[k] * n2[k]; n12 += n1[k] * n2[k]; }
        p10 &= confere(n11 == n22 && -3 * n12 == n11, "P10 diedro cos δ = 1/3");
        E[0] = 1; E[1] = 1;
        for (int k = 1; k < 63; k++) E[k + 1] = 2 * E[k] - 9 * E[k - 1];
        int ok3 = 1, p = 1;                           /* Eₖ ≡ 2ᵏ⁻¹ (mod 3) ≠ 0: 3ᵏ divide o denominador */
        for (int k = 1; k <= 30; k++) {               /* 3³⁰·T₃₀ cabe em __int128 */
            ok3 &= ((E[k] % 3) + 3) % 3 == p && E[k] != pot128(3, k);
            p = p * 2 % 3;
        }
        p10 &= confere(ok3 && E[5] == 241, "P10 Tₖ(1/3) ≠ 1, fenda 241/243 com cinco");
        /* quatro tetraedros K em torno do eixo √14: dobra 7 + 7 = 14 (csc √2) e giro (α,β,γ) ↦ (α,−γ,β) de ordem 4 */
        i128 G[3][3] = {{1, 0, 0}, {0, 0, -1}, {0, 1, 0}};
        i64 e[3] = {2, 0, 0}, f[3] = {1, 1, 0}, ee = 4, ff = 2, ef = 2;
        (void)e; (void)f;
        p10 &= confere(2 * (ee * ff - ef * ef) == ee * ff && ordem_exata(G, 1, 12) == 4, "P10 quatro tetraedros K fecham em 4");
    }

    /* P11: tangentes externas a partir de X = (2,3,6), em coordenadas dobradas (2T = (2,3,−1)) */
    int p11 = 1;
    {
        i64 X2[3] = {4, 6, 12}, T2[3] = {2, 3, -1}, xo[3], xt[3], oo = 0, tt = 0, ot = 0, t2 = 0, rt = 0, tx = 0;
        for (int k = 0; k < 3; k++) {
            xo[k] = -X2[k]; xt[k] = T2[k] - X2[k];
            oo += xo[k] * xo[k]; tt += xt[k] * xt[k]; ot += xo[k] * xt[k];
            t2 += T2[k] * T2[k]; rt += T2[k] * xt[k]; tx += T2[k] * X2[k];
        }
        /* |2T|² = 14 (T ∈ 𝒮), raio ⟂ tangente, spread em X = 1/14, T no plano polar 2T·2X = 4ρ = 14 */
        p11 &= confere(t2 == 14 && rt == 0 && 14 * (oo * tt - ot * ot) == oo * tt && tx == 14 && oo == 196,
                       "P11 cone tangente de X: csc √14, raio ⟂ tangente");
        /* X' = ρX/|X|² = X/14: |X'|²·|X|² = ρ² ⇔ (49/196)·49 = 49/4 */
        p11 &= confere(49 * 49 * 4 == 196 * 49, "P11 inversão |OX'|·|OX| = R²");
    }

    /* P9: sabotagens */
    const char *nomes[10] = {
        "SB1 quatérnio 12 + 2j + 3k", "SB2 vetor do quatérnio na diagonal (1,2,3)",
        "SB3 sinal trocado numa entrada de M'", "SB4 passo de Teodoro 3 → 4 (csc 2)",
        "SB5 passo de Teodoro 1 → 2 (csc √2)", "SB6 parceiro 2 + 2j + 3k na meia-volta",
        "SB7 ponte pelo eixo P − P'", "SB8 cossecante √14 em seno zero",
        "SB9 expoente 2ⁿ no lugar de 2ⁿ⁻¹ na órbita módulo 7", "SB10 loop fechado em 12 passos"};
    int acusada[10];
    {
        i64 q12[4] = {12, 0, 2, 3}, q13d[4] = {13, 1, 2, 3}, q3[4] = {3, 1, 1, 1}, q1[4] = {1, 1, 0, 0};
        i64 b2[4] = {2, 0, 2, 3}, eixo_errado[3] = {1, 0, 0};
        i128 Ms[3][3], R2[3][3], R3[3][3], R1[3][3];
        acusada[0] = !cert_meio_angulo(q12, A_FACE);
        rodrigues(q13d, R2);
        acusada[1] = !(cert_meio_angulo(q13d, A_FACE) && cert_rotacao(R2, quat_norm2(q13d), A_FACE));
        memcpy(Ms, M, sizeof Ms);
        Ms[0][1] = -Ms[0][1];
        acusada[2] = !cert_rotacao(Ms, 91, A_FACE);
        rodrigues(q3, R3);
        acusada[3] = !(cert_mod7(R3, quat_norm2(q3)) && cert_aberto_exato(R3, quat_norm2(q3), 12));
        rodrigues(q1, R1);
        acusada[4] = !(cert_mod7(R1, quat_norm2(q1)) && cert_aberto_exato(R1, quat_norm2(q1), 12));
        acusada[5] = !cert_meia_volta(Q_CSC, b2, ponte, NULL);
        acusada[6] = !cert_meia_volta(Q_CSC, B_CAIXA, eixo_errado, NULL);
        acusada[7] = !cert_seno_zero(1, 14);
        acusada[8] = !cert_orbita_mod7(M, 50, 1);
        acusada[9] = fecha_em(M, 91, 12) ? 0 : 1;
    }
    int n_acus = 0;
    for (int i = 0; i < 10; i++) n_acus += acusada[i];
    int p9 = confere(n_acus == 10, "P9 sabotagens acusadas");

    /* JSON */
    fprintf(js, " \"P1_ok\": %d, \"P2_ok\": %d, \"P3_ok\": %d, \"P5_ok\": %d, \"P6_ok\": %d, \"P7_ok\": %d, \"P8_ok\": %d, \"P9_ok\": %d, \"P10_ok\": %d,\n",
            p1, p2, p3, p5, p6, p7, p8, p9, p10);
    fputs(" \"T5_um_terco_vezes_243\": ", js); imprime128(js, E[5]); fputs(",\n", js);
    fprintf(js, " \"sabotagens\": [");
    for (int i = 0; i < 10; i++) fprintf(js, "%s{\"sabotagem\": \"%s\", \"acusada\": %s}", i ? ", " : "", nomes[i], acusada[i] ? "true" : "false");
    fprintf(js, "],\n \"chaves_comuns\": {\n  \"M_linha\": [");
    for (int i = 0; i < 3; i++) {
        fprintf(js, "%s[", i ? ", " : "");
        for (int j = 0; j < 3; j++) { if (j) fputs(", ", js); imprime128(js, M[i][j]); }
        fputs("]", js);
    }
    fputs("],\n  \"traco_M_linha\": ", js); imprime128(js, traco(M));
    fputs(",\n  \"cos2theta\": [6, 7],\n  \"C\": [", js);
    for (int n = 1; n <= 20; n++) { if (n > 1) fputs(", ", js); imprime128(js, C[n]); }
    fputs("],\n  \"D\": [", js);
    for (int k = 0; k <= 19; k++) { if (k) fputs(", ", js); imprime128(js, Dk[k]); }
    fputs("],\n  \"W\": {", js);
    for (int n = 1; n <= 9; n++) {
        fprintf(js, "%s\"%d\": [", n > 1 ? ", " : "", n);
        for (int i = 0; i < 3; i++) { if (i) fputs(", ", js); imprime128(js, W[n][i]); }
        fputs("]", js);
    }
    fprintf(js, "},\n  \"q_vezes_b\": [%lld, %lld, %lld, %lld],\n  \"treze_H\": [", qb[0], qb[1], qb[2], qb[3]);
    for (int i = 0; i < 3; i++) {
        fprintf(js, "%s[", i ? ", " : "");
        for (int j = 0; j < 3; j++) fprintf(js, "%s%lld", j ? ", " : "", 2 * A_FACE[i] * A_FACE[j] - (i == j ? 13 : 0));
        fputs("]", js);
    }
    fprintf(js, "],\n  \"teodoro_fecham\": {\"%d\": %d, \"%d\": %d},\n  \"auditoria_ordens\": {", teo_n[0], teo_k[0], teo_n[1], teo_k[1]);
    for (int c = 0; c < 6; c++) {
        fprintf(js, "%s\"%s\": ", c ? ", " : "", ids[c]);
        if (ordens[c]) fprintf(js, "%d", ordens[c]); else fputs("null", js);
    }
    int tudo = falhas == 0;
    fprintf(js, "}\n },\n \"verificacoes\": %ld, \"falhas\": %ld, \"tudo_confere\": %s\n}\n", verificacoes, falhas, tudo ? "true" : "false");
    fclose(js);

    printf("Implementação B — certificados módulo 7 para todo n; exatos até n = %d\n", NEXATO);
    printf("  P1 %s  P2 %s  P3 %s  P5 %s  P6 %s  P7 %s  P8 %s  P9 %s  P10 %s  P11 %s\n",
           p1 ? "ok" : "FALHA", p2 ? "ok" : "FALHA", p3 ? "ok" : "FALHA", p5 ? "ok" : "FALHA",
           p6 ? "ok" : "FALHA", p7 ? "ok" : "FALHA", p8 ? "ok" : "FALHA", p9 ? "ok" : "FALHA",
           p10 ? "ok" : "FALHA", p11 ? "ok" : "FALHA");
    printf("  sabotagens acusadas: %d/10; verificações: %ld; falhas: %ld\n", n_acus, verificacoes, falhas);
    puts(tudo ? "TUDO CONFERE" : "HÁ FALHAS");
    return tudo ? 0 : 1;
}
