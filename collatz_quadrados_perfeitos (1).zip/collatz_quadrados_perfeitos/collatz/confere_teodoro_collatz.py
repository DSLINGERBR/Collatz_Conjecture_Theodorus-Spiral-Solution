#!/usr/bin/env python3
"""
confere_teodoro_collatz.py — certificados exatos do artigo "A espiral de Teodoro, o círculo de lado 1 e o problema 3n+1".
Python 3, só biblioteca padrão; inteiros e frações exatas (nenhum ponto flutuante decide nada).

Pré-registro (previsões fixadas antes da execução):
  T1  |v_N|² = N: o produto ∏_{k<N} |1 + i/√k|² = ∏ (k+1)/k telescopa em N (até N = 10⁵).
  T2  Coordenadas exatas de v_1, …, v_25 no corpo gerado por √2, √3, √5, … (cada coordenada é Σ c·√s, c racional,
      s livre de quadrados), calculadas pela própria recorrência: Q(v_N) = N; o passo u_N tem quadrância 1 e é
      perpendicular a v_N; (v_N × v_(N+1))² = N, isto é, spread 1/(N+1) no centro; spread N/(N+1) em v_(N+1);
      Q(v_N + t·u_N) = N + t² para t = 1/2 e 1/3; potência de v_M em relação ao círculo x²+y² = N igual a M − N;
      v_2 = (1, 1). Planificação: o triângulo de Teodoro tem as mesmas quadrâncias que (0, d_N, d_(N+1)) em Z^(N+1)
      (vetores inteiros calculados) e, se N = a² + b², que o triângulo (0,0,0), (a,b,0), (a,b,1) da caixa a×b×1
      (5050 caixas com 1 ≤ a ≤ b ≤ 100; N = 13: caixa 2×3×1, cossecante √14).
  T3  Fileira de n quadrados de lado 1: 3n + 1 segmentos (contagem direta por quadrância 1, n ≤ 59) e Euler V − A + F = 2.
  T4  Porta: para todo n ≤ 10⁶ que não é potência de 2, a primeira potência de 2 da trajetória 3n+1 é 4^k, k ≥ 2,
      alcançada a partir do ímpar (4^k − 1)/3.
  T5  Portas raras: para 3 | k, exatamente ⌊log₂(N/p_k)⌋ + 1 números n ≤ N usam a porta 4^k, p_k = (4^k − 1)/3;
      conferido para N = 10⁶ (contagem própria) e para o N do programa em C (arquivo JSON opcional).
  T6  3n − 1: ciclos 5 → 14 → 7 → 20 → 10 → 5 e o ciclo de 17 (18 termos), sem potência de 2; quando uma trajetória de
      3n − 1 alcança potência de 2, a porta é 2·4^k (expoente ímpar, não é quadrado perfeito).
  T7  5n + 1: as portas são 16^k (quadrados perfeitos) e, mesmo assim, há os ciclos de 13 (10 termos) e de 17 (10 termos).
  T8  Teeteto: os 16 triângulos até a hipotenusa √17 somam menos de uma volta e os 17 até √18 somam mais
      (limites racionais rigorosos para arctan e para π, série alternada e fórmula de Machin).
  T9  Progressão de quadrados: S_j inscrito em x²+y² = 2^j, com vértices inteiros, lados tangentes a x²+y² = 2^(j−1)
      exatamente nos vértices de S_(j−1); aresta de S_j com quadrância 2^(j+1); o raio de nível j é a aresta de S_(j−1).
  T10 Elevação ao paraboloide z = x²+y²: com as coordenadas exatas de T2, cada passo elevado tem quadrância 2 e spread
      1/2 com o plano (45°).
  Sabotagens: sete versões erradas de propósito; cada uma deve ser recusada pelo certificado correspondente.
Uso: python3 confere_teodoro_collatz.py [portas_do_C.json]
"""
import json
import math
import sys
from collections import Counter
from fractions import Fraction as F

res, falhas = {}, []


def confere(nome, ok):
    if not ok:
        falhas.append(nome)
    return bool(ok)


def pot2(x):
    return x > 0 and x & (x - 1) == 0


# ---------------------------------------------------------------- T1
def t1(nmax, erro=0):
    prod = F(1)
    for N in range(2, nmax + 1):
        prod *= F(N + erro, N - 1)            # |1 + i/√(N−1)|² = 1 + 1/(N−1) = N/(N−1)
        if prod != N:
            return False
    return True


res["T1_quadrancia_igual_N_ate_1e5"] = confere("T1", t1(100_000))


# ---------------------------------------------------------------- T2: coordenadas exatas no corpo Q(√2, √3, √5, …)
def parte_livre(n):
    """n = k²·t com t livre de quadrados; devolve (k, t)."""
    k, t, d = 1, 1, 2
    while d * d <= n:
        while n % (d * d) == 0:
            n //= d * d
            k *= d
        if n % d == 0:
            n //= d
            t *= d
        d += 1
    return k, t * n


def soma(a, b, sinal=1):
    r = dict(a)
    for s_, c in b.items():
        r[s_] = r.get(s_, 0) + sinal * c
        if r[s_] == 0:
            del r[s_]
    return r


def produto(a, b):
    r = {}
    for s1, c1 in a.items():
        for s2, c2 in b.items():
            g = math.gcd(s1, s2)
            t = (s1 // g) * (s2 // g)          # √s1·√s2 = g·√t, com t livre de quadrados
            r[t] = r.get(t, 0) + c1 * c2 * g
    return {s_: c for s_, c in r.items() if c != 0}


def racional(q):
    return {1: F(q)} if q != 0 else {}


def espiral_exata(nmax, erro=0):
    """v[1..nmax] pela recorrência v_(N+1) = v_N + J v_N / √N, com 1/√N = (k/N)·√t quando N = k²·t."""
    v = [None, (racional(1), {})]
    for N in range(1, nmax):
        x, y = v[N]
        k, t = parte_livre(N + erro)
        inv = {t: F(k, N + erro)}
        v.append((soma(x, produto(y, inv), -1), soma(y, produto(x, inv))))
    return v


def quad(p):
    return soma(produto(p[0], p[0]), produto(p[1], p[1]))


def escalar(p, q):
    return soma(produto(p[0], q[0]), produto(p[1], q[1]))


def vetorial(p, q):
    return soma(produto(p[0], q[1]), produto(p[1], q[0]), -1)


def menos(p, q):
    return (soma(p[0], q[0], -1), soma(p[1], q[1], -1))


def mais_t(p, u, t):
    return (soma(p[0], produto(racional(t), u[0])), soma(p[1], produto(racional(t), u[1])))


NEXATO = 25


def t2(nmax=NEXATO, erro=0):
    v = espiral_exata(nmax, erro)
    Qv = [None] + [quad(v[N]) for N in range(1, nmax + 1)]                    # quadrâncias calculadas uma vez
    ok = v[2] == (racional(1), racional(1))                                   # v_2 = (1, 1)
    for N in range(1, nmax):
        u = menos(v[N + 1], v[N])
        ok &= Qv[N] == racional(N) and quad(u) == racional(1) and escalar(u, v[N]) == {}
        c = vetorial(v[N], v[N + 1])
        ok &= produto(c, c) == racional(N)                                    # spread no centro: N/(N(N+1)) = 1/(N+1)
        c2 = vetorial(menos(({}, {}), v[N + 1]), menos(v[N], v[N + 1]))
        ok &= produto(c2, c2) == racional(N)                                  # spread em v_(N+1): N/((N+1)·1)
        for t in (F(1, 2), F(1, 3)):
            ok &= quad(mais_t(v[N], u, t)) == racional(N + t * t)             # Proposição 4
        dN = [1] * N + [0]
        dN1 = [1] * (N + 1)
        e = [b - a for a, b in zip(dN, dN1)]
        ok &= (sum(x * x for x in dN), sum(x * x for x in e), sum(a * b for a, b in zip(dN, e)), sum(x * x for x in dN1)) \
            == (N, 1, 0, N + 1)                                               # planificação em Z^(N+1)
    for M in range(1, nmax + 1):                                              # potência de v_M em relação a x²+y² = N
        for N in range(1, M + 1):
            ok &= soma(Qv[M], racional(-N)) == racional(M - N)
    caixas = 0
    for a in range(1, 101):                                                   # N = a² + b²: caixa a × b × 1
        for b in range(a, 101):
            N = a * a + b * b
            d, d1 = (a, b, 0), (a, b, 1)
            e = tuple(y - x for x, y in zip(d, d1))
            q = (sum(x * x for x in d), sum(x * x for x in e), sum(x * y for x, y in zip(d, e)), sum(x * x for x in d1))
            ok &= q == (N, 1, 0, N + 1)
            if N < nmax:
                ok &= Qv[N] == racional(q[0]) and Qv[N + 1] == racional(q[3])
            caixas += 1
    return ok, caixas, v


ok2, caixas, V_EXATO = t2()
res["T2_coordenadas_exatas_ate_v25"] = confere("T2", ok2)
res["T2_termos_na_coordenada_de_v25"] = len(V_EXATO[NEXATO][0]) + len(V_EXATO[NEXATO][1])
res["T2_caixas_axbx1_conferidas"] = caixas
res["T2_triangulo_13"] = {"caixa": "2x3x1", "quadrancias": [13, 1, 14], "spread_centro": "1/14", "cossecante_ao_quadrado": 14}


# ---------------------------------------------------------------- T3
def t3(nmax):
    ok = True
    for n in range(1, nmax + 1):
        V = {(x, y) for x in range(n + 1) for y in (0, 1)}
        E = {frozenset((a, b)) for a in V for b in V if (a[0] - b[0]) ** 2 + (a[1] - b[1]) ** 2 == 1}
        ok &= len(E) == 3 * n + 1 and len(V) - len(E) + (n + 1) == 2
    return ok


res["T3_palitos_3n_mais_1_ate_59"] = confere("T3", t3(59))


# ---------------------------------------------------------------- T4
def primeira_potencia(n, a=3, b=1):
    """Trajetória de n pelo mapa ímpar → a·x + b, par → x/2, até a primeira potência de 2 (n não é potência de 2)."""
    x = n
    while True:
        ant = x
        x = x // 2 if x % 2 == 0 else a * x + b
        if pot2(x):
            return x, ant


def t4(nmax):
    portas, ok = Counter(), True
    for n in range(1, nmax + 1):
        if pot2(n):
            continue
        p2, ant = primeira_potencia(n)
        k = math.isqrt(p2)
        ok &= k * k == p2 and pot2(k) and k >= 4 and ant % 2 == 1 and 3 * ant + 1 == p2
        portas[p2] += 1
    return ok, portas


NMAX = 1_000_000
ok4, portas = t4(NMAX)
res["T4_porta_quadrado_ate_1e6"] = confere("T4", ok4)
res["T4_contagem_1e6"] = {f"4^{(p.bit_length() - 1) // 2}": c for p, c in sorted(portas.items())}


# ---------------------------------------------------------------- T5
def previsao(k, N, erro=0):
    p = (4 ** k - 1) // 3
    return 0 if p > N else (N // p).bit_length() + erro     # número de a ≥ 0 com p·2^a ≤ N


def t5(portas, N, ks, erro=0):
    ok, tab = True, {}
    for k in ks:
        obs = portas.get(4 ** k, 0)
        ok &= obs == previsao(k, N, erro)
        tab[f"4^{k}"] = {"previsto": previsao(k, N, erro), "contado": obs}
    return ok, tab


ok5, tab = t5(portas, NMAX, range(3, 13, 3))
res["T5_portas_raras_1e6"] = tab
if len(sys.argv) > 1:
    c = json.load(open(sys.argv[1]))
    portas_c = Counter({2 ** int(chave[2:]): v for chave, v in c["portas"].items()})
    ok5c, tab8 = t5(portas_c, c["N"], range(3, 33, 3))
    ok5 &= ok5c and c["falhas"] == 0 and c["estouros"] == 0
    ok5 &= all(int(chave[2:]) % 2 == 0 and int(chave[2:]) >= 4 for chave in c["portas"])
    res["T5_portas_C"] = {"N": c["N"], "portas_raras": tab8, "falhas_no_C": c["falhas"], "estouros_no_C": c["estouros"],
                          "todas_as_portas_sao_4^k_k>=2": all(int(ch[2:]) % 2 == 0 and int(ch[2:]) >= 4 for ch in c["portas"])}
res["T5_ok"] = confere("T5", ok5)


# ---------------------------------------------------------------- T6 e T7: mapas vizinhos
def destino(n, a, b, teto):
    """Segue n pelo mapa (ímpar → a·x + b, par → x/2) até potência de 2, repetição (ciclo) ou passar do teto.
    Na porta devolve (potência, antecessor); no ciclo devolve o menor elemento do ciclo."""
    x, ant, vistos, seq = n, None, set(), []
    while not pot2(x) and x not in vistos and x < teto:
        vistos.add(x)
        seq.append(x)
        ant, x = x, (x // 2 if x % 2 == 0 else a * x + b)
    if pot2(x):
        return "porta", x, ant
    return ("ciclo", min(seq[seq.index(x):]), None) if x in vistos else ("teto", x, None)


def ciclo(n, a, b):
    vistos, x = [], n
    while x not in vistos:
        vistos.append(x)
        x = x // 2 if x % 2 == 0 else a * x + b
    return vistos[vistos.index(x):]


def t6():
    c5, c17 = ciclo(5, 3, -1), ciclo(17, 3, -1)
    ok = c5 == [5, 14, 7, 20, 10] and len(c17) == 18 and not any(pot2(x) for x in c5 + c17)
    cont, ciclos = Counter(), Counter()
    for n in range(1, 100_001):
        if pot2(n):
            continue
        tipo, x, ant = destino(n, 3, -1, 10 ** 30)
        cont[tipo] += 1
        if tipo == "porta":
            ok &= ant % 2 == 1 and (x.bit_length() - 1) % 2 == 1 and math.isqrt(x) ** 2 != x
        elif tipo == "ciclo":
            ciclos[x] += 1
    ok &= set(ciclos) == {5, 17} and cont["teto"] == 0
    return ok and cont["ciclo"] > 0, c5, c17, cont, ciclos


ok6, c5, c17, cont6, ciclos6 = t6()
res["T6_3n_menos_1"] = {"ciclo_de_5": c5, "ciclo_de_17": c17, "ate_1e5": dict(cont6),
                        "ciclos_por_menor_elemento": {str(k): v for k, v in sorted(ciclos6.items())}}
res["T6_ok"] = confere("T6", ok6)


def t7(nmax=20_000):
    c13, c17 = ciclo(13, 5, 1), ciclo(17, 5, 1)
    ok = len(c13) == 10 and len(c17) == 10 and not any(pot2(x) for x in c13 + c17)
    cont, portas5, ciclos = Counter(), Counter(), Counter()
    for n in range(1, nmax + 1):
        if pot2(n):
            continue
        tipo, x, ant = destino(n, 5, 1, 10 ** 40)
        cont[tipo] += 1
        if tipo == "porta":
            portas5[x] += 1
            e = x.bit_length() - 1
            ok &= ant % 2 == 1 and e % 4 == 0 and math.isqrt(x) ** 2 == x     # 16^k: quadrado perfeito
        elif tipo == "ciclo":
            ciclos[x] += 1
    ok &= set(ciclos) == {13, 17}
    return ok and cont["ciclo"] > 0, c13, c17, cont, portas5, ciclos


ok7, c13, c17b, cont7, portas5, ciclos7 = t7()
res["T7_5n_mais_1"] = {"ciclo_de_13": c13, "ciclo_de_17": c17b, "ate_2e4": dict(cont7),
                       "ciclos_por_menor_elemento": {str(k): v for k, v in sorted(ciclos7.items())},
                       "portas": {f"16^{(p.bit_length() - 1) // 4}": v for p, v in sorted(portas5.items())}}
res["T7_ok"] = confere("T7", ok7)


# ---------------------------------------------------------------- T8: Teeteto, 16 triângulos < uma volta < 17 triângulos
def atan_limites(xl, xu, termos=25):
    """arctan em [xl, xu] ⊂ (0, 1): série alternada; S_(2m) é limite superior e S_(2m+1) inferior."""
    def parcial(x, n):
        return sum(F((-1) ** i, 2 * i + 1) * x ** (2 * i + 1) for i in range(n + 1))
    return parcial(xl, 2 * termos + 1), parcial(xu, 2 * termos)


def pi_limites():
    a5, b5 = atan_limites(F(1, 5), F(1, 5), 40)
    a239, b239 = atan_limites(F(1, 239), F(1, 239), 20)
    return 4 * (4 * a5 - b239), 4 * (4 * b5 - a239)        # Machin: π/4 = 4 arctan(1/5) − arctan(1/239)


def soma_angulos(m, escala=10 ** 12):
    """Limites para Σ_{k=1}^{m} arctan(1/√k); k = 1 dá π/4 exato, k quadrado perfeito dá 1/√k exato."""
    pl, pu = pi_limites()
    lo, hi = pl / 4, pu / 4
    for k in range(2, m + 1):
        r = math.isqrt(k)
        if r * r == k:
            xl = xu = F(1, r)
        else:
            a = math.isqrt(k * escala * escala)               # a ≤ √k·escala < a + 1
            xl, xu = F(escala, a + 1), F(escala, a)
        l, u = atan_limites(xl, xu)
        lo, hi = lo + l, hi + u
    return lo, hi


def t8(m_dentro=16, m_fora=17):
    pl, pu = pi_limites()
    lo16, hi16 = soma_angulos(m_dentro)
    lo17, hi17 = soma_angulos(m_fora)
    return hi16 < 2 * pl and lo17 > 2 * pu, (lo16, hi16, lo17, hi17, pl, pu)


ok8, (lo16, hi16, lo17, hi17, pl, pu) = t8()
res["T8_teeteto"] = {"soma_16_triangulos_graus_intervalo": [f"{float(lo16 * 180 / pu):.6f}", f"{float(hi16 * 180 / pl):.6f}"],
                     "soma_17_triangulos_graus_intervalo": [f"{float(lo17 * 180 / pu):.6f}", f"{float(hi17 * 180 / pl):.6f}"],
                     "pi_entre": [f"{float(pl):.15f}", f"{float(pu):.15f}"]}
res["T8_ok"] = confere("T8", ok8)


# ---------------------------------------------------------------- T9: progressão de quadrados inscritos e circunscritos
def vertices(j):
    m = j // 2
    if j % 2 == 0:
        return [(2 ** m, 0), (0, 2 ** m), (-2 ** m, 0), (0, -2 ** m)]        # nível par: vértices nos eixos
    return [(2 ** m, 2 ** m), (-2 ** m, 2 ** m), (-2 ** m, -2 ** m), (2 ** m, -2 ** m)]   # ímpar: nas diagonais


def t9(jmax=60, erro=0):
    ok = True
    for j in range(0, jmax + 1):
        V = vertices(j)
        ok &= all(x * x + y * y == 2 ** j for x, y in V)                     # inscrito em C_j
        for (x1, y1), (x2, y2) in zip(V, V[1:] + V[:1]):
            q_aresta = (x2 - x1) ** 2 + (y2 - y1) ** 2
            ok &= q_aresta == 2 ** (j + 1)
            if j >= 1:
                cruz = x1 * y2 - x2 * y1
                ok &= F(cruz * cruz, q_aresta) == F(2 ** j, 2 + erro)       # distância² do centro à aresta = 2^(j−1)
                t = F(-(x1 * (x2 - x1) + y1 * (y2 - y1)), q_aresta)          # pé da perpendicular a partir do centro
                pe = (x1 + t * (x2 - x1), y1 + t * (y2 - y1))
                ok &= pe in [(F(a), F(b)) for a, b in vertices(j - 1)]       # tangente nos vértices de S_(j−1)
                ok &= q_aresta // 2 == 2 ** j and (2 ** j) == sum(c * c for c in vertices(j)[0])
        if j >= 1:                                                            # raio de nível j = aresta de S_(j−1)
            (a1, b1), (a2, b2) = vertices(j - 1)[:2]
            ok &= (a2 - a1) ** 2 + (b2 - b1) ** 2 == 2 ** j
    ok &= vertices(0)[0] == (1, 0) and vertices(1)[0] == (1, 1)              # v_1 e v_2 da espiral de Teodoro
    return ok


res["T9_progressao_de_quadrados_ate_j60"] = confere("T9", t9())
res["T9_niveis_pares_sao_quadrados_perfeitos"] = all(math.isqrt(2 ** j) ** 2 == 2 ** j for j in range(0, 61, 2)) and \
    not any(math.isqrt(2 ** j) ** 2 == 2 ** j for j in range(1, 61, 2))


# ---------------------------------------------------------------- T10: elevação ao paraboloide
def t10(v=V_EXATO, nmax=NEXATO):
    ok = True
    for N in range(1, nmax):
        u = menos(v[N + 1], v[N])
        q_h = quad(u)                                   # deslocamento horizontal, calculado com as coordenadas exatas
        q_v = racional(((N + 1) - N) ** 2)              # a altura é a quadrância: sobe exatamente 1
        q = soma(q_h, q_v)
        ok &= q_h == racional(1) and q_v == racional(1) and q == racional(2) and F(1, 2) == q_v[1] / q[1]   # 45°
        ok &= quad(v[N]) == racional(N)                 # V_N = (v_N, N) está no paraboloide z = x² + y²
    return ok


res["T10_paraboloide_45_graus"] = confere("T10", t10())

# ---------------------------------------------------------------- sabotagens
sab = {
    "S1_produto_com_erro_de_um": not t1(1000, erro=1),
    "S2_porta_quadrado_no_3n_menos_1": not all(math.isqrt(x) ** 2 == x for n in range(3, 200) if not pot2(n)
                                               for tipo, x, _ in [destino(n, 3, -1, 10 ** 30)] if tipo == "porta"),
    "S3_portas_raras_formula_errada": not t5(portas, NMAX, range(3, 13, 3), erro=1)[0],
    "S4_teeteto_15_triangulos_passariam_da_volta": not t8(15, 16)[0],
    "S5_progressao_com_distancia_errada": not t9(10, erro=1),
    "S6_5n_mais_1_sem_ciclos": any(destino(n, 5, 1, 10 ** 40)[0] == "ciclo" for n in range(1, 100)),
    "S7_passo_com_raiz_errada": not t2(8, erro=1)[0],
}
res["sabotagens"] = sab
res["sabotagens_recusadas"] = f"{sum(sab.values())}/{len(sab)}"
if not all(sab.values()):
    falhas.append("sabotagem aceita")

res["tudo_confere"] = not falhas
res["falhas"] = falhas
json.dump(res, open("resultados_teodoro_collatz.json", "w"), ensure_ascii=False, indent=1)
print(json.dumps(res, ensure_ascii=False, indent=1))
sys.exit(0 if not falhas else 1)
