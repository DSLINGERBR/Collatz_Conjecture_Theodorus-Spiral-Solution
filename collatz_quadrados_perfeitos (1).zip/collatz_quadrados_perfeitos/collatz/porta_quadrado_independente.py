#!/usr/bin/env python3
"""Conferência independente (Python, inteiros): segue a trajetória inteira de cada n ≤ N até a primeira
potência de 2 e confere que ela é um quadrado perfeito 4^k, k ≥ 2, alcançada a partir do ímpar (4^k − 1)/3.
Na espiral de Teodoro, o ponto N está a distância √N do centro (N segmentos de lado 1): a porta 4^k fica
a distância inteira 2^k, e a descida 2^j percorre os comprimentos 2^(j/2) da Espiral de Cotα."""
import json, math, sys
from collections import Counter

N = int(sys.argv[1]) if len(sys.argv) > 1 else 1_000_000
portas, falhas = Counter(), 0
for n in range(1, N + 1):
    if n & (n - 1) == 0:
        continue
    x = n
    while True:
        ant = x
        x = x // 2 if x % 2 == 0 else 3 * x + 1
        if x & (x - 1) == 0:
            break
    k = math.isqrt(x)
    quadrado = k * k == x and (k & (k - 1)) == 0 and k >= 4
    if not (quadrado and ant % 2 == 1 and 3 * ant + 1 == x and ant == (x - 1) // 3):
        falhas += 1
    portas[x] += 1
print(json.dumps({"N": N, "falhas": falhas,
                  "portas": {f"{p} = {math.isqrt(p)}^2": c for p, c in sorted(portas.items())}}, ensure_ascii=False))
