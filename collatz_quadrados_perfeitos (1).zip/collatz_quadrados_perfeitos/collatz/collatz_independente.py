#!/usr/bin/env python3
"""Conferência independente do 3n+1 em Python (inteiros exatos): para cada n ≤ N, segue a trajetória
completa até entrar no loop 1 → 4 → 2 → 1, guarda o tempo de parada total e confere que o loop
alcançado é sempre o mesmo. Também mostra a elevação 3D Z = número do passo."""
import json, sys
N = int(sys.argv[1]) if len(sys.argv) > 1 else 1_000_000
tempo = {1: 0}
loops = set()
for n in range(2, N + 1):
    x, caminho = n, []
    while x not in tempo:
        caminho.append(x)
        x = x // 2 if x % 2 == 0 else 3 * x + 1
        if len(caminho) > 10 ** 6:
            raise SystemExit(f"candidato a sair do loop: {n}")
    t = tempo[x]
    for y in reversed(caminho):
        t += 1
        if y <= N:
            tempo[y] = t
        else:
            tempo.setdefault(y, t)
# o loop final: a partir de 1
x, ciclo = 1, []
while True:
    ciclo.append(x); x = x // 2 if x % 2 == 0 else 3 * x + 1
    if x == 1: break
recorde = max(range(1, N + 1), key=lambda k: tempo[k])
def traj(n):
    out = [n]
    while n != 1:
        n = n // 2 if n % 2 == 0 else 3 * n + 1; out.append(n)
    return out
res = {"N": N, "todos_chegam_a_1": all(k in tempo for k in range(1, N + 1)), "loop_final": ciclo,
       "recorde_tempo_total": {"n": recorde, "passos": tempo[recorde]},
       "trajetoria_7": traj(7), "trajetoria_14": traj(14), "tempo_27": len(traj(27)) - 1,
       "elevacao_3D_do_loop": "pontos (passo, valor): o valor repete 4,2,1 e o passo cresce sem repetir"}
print(json.dumps(res, ensure_ascii=False))
