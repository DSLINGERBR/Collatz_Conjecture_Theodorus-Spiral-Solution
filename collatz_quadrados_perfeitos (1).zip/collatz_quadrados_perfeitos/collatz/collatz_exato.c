/*
 * collatz_exato.c — teste exato do 3n+1 com inteiros (sem ponto flutuante).
 * Para cada n de 2 a N, itera x ← x/2 (par) ou x ← 3x+1 (ímpar) até x < n. Como todo m < n já foi
 * conferido, n chega ao loop 4 → 2 → 1. Um ciclo novo ou uma trajetória divergente faria a iteração
 * passar do limite de passos e seria registrado. Inteiros de 128 bits com detecção de estouro.
 * Compilar: gcc -O2 -std=gnu11 -o collatz_exato collatz_exato.c     Executar: ./collatz_exato [N]
 */
#include <stdio.h>
#include <stdlib.h>
typedef unsigned __int128 u128;
#define LIMITE_PASSOS 100000

static void imprime(u128 x) {
    char b[64]; int i = 63; b[i] = 0;
    do { b[--i] = '0' + (int)(x % 10); x /= 10; } while (x);
    fputs(b + i, stdout);
}

int main(int argc, char **argv) {
    unsigned long long N = argc > 1 ? strtoull(argv[1], 0, 10) : 1000000000ULL;
    const u128 TETO = ((u128)-1 - 1) / 3;
    unsigned long long saem = 0, estouros = 0, n_recorde_passos = 0, n_recorde_pico = 0;
    unsigned long passos_recorde = 0;
    u128 pico_recorde = 0;
    for (unsigned long long n = 2; n <= N; n++) {
        u128 x = n, pico = n;
        unsigned long passos = 0;
        while (x >= n) {
            if (x & 1) {
                if (x > TETO) { estouros++; break; }
                x = 3 * x + 1;
                if (x > pico) pico = x;
            } else x >>= 1;
            if (++passos > LIMITE_PASSOS) { saem++; printf("candidato a sair do loop: %llu\n", n); break; }
        }
        if (passos > passos_recorde) { passos_recorde = passos; n_recorde_passos = n; }
        if (pico > pico_recorde) { pico_recorde = pico; n_recorde_pico = n; }
    }
    printf("{\"N\": %llu, \"saem_do_loop\": %llu, \"estouros\": %llu, ", N, saem, estouros);
    printf("\"maior_tempo_ate_cair_abaixo_de_n\": {\"n\": %llu, \"passos\": %lu}, ", n_recorde_passos, passos_recorde);
    printf("\"maior_pico\": {\"n\": %llu, \"pico\": ", n_recorde_pico); imprime(pico_recorde); printf("}}\n");
    return saem || estouros;
}
