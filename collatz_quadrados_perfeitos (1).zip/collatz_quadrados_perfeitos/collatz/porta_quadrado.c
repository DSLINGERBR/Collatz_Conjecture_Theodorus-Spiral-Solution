/*
 * porta_quadrado.c — por onde as trajetórias do 3n+1 entram na descida final.
 * Para cada n ≤ N que não é potência de 2, acha a primeira potência de 2 da trajetória (a "porta"),
 * confere que ela é um quadrado perfeito 4^k (k ≥ 2) e que o número anterior é o ímpar (4^k − 1)/3.
 * Usa memória: se a trajetória cai abaixo de n antes de achar potência de 2, a porta é a do valor menor.
 * Só inteiros (128 bits, com detecção de estouro). Compilar: gcc -O2 -o porta_quadrado porta_quadrado.c
 */
#include <stdio.h>
#include <stdlib.h>
typedef unsigned __int128 u128;

static int eh_pot2(u128 x) { return x && !(x & (x - 1)); }
static int expoente(u128 x) { int e = 0; while (x > 1) { x >>= 1; e++; } return e; }

int main(int argc, char **argv) {
    unsigned long long N = argc > 1 ? strtoull(argv[1], 0, 10) : 100000000ULL;
    unsigned char *porta = calloc(N + 1, 1);          /* expoente j da porta 2^j */
    unsigned long long cont[128] = {0}, falhas = 0, estouros = 0;
    const u128 TETO = ((u128)-1 - 1) / 3;
    for (unsigned long long n = 1; n <= N; n++) {
        if (eh_pot2(n)) { porta[n] = (unsigned char)expoente(n); continue; }
        u128 x = n, ant = 0;
        int j = -1;
        while (1) {
            ant = x;
            if (x & 1) { if (x > TETO) { estouros++; break; } x = 3 * x + 1; }
            else x >>= 1;
            if (eh_pot2(x)) {                          /* primeira potência de 2 desta trajetória */
                j = expoente(x);
                if (!((ant & 1) && 3 * ant + 1 == x)) falhas++;   /* o anterior tem de ser ímpar */
                break;
            }
            if (x < n) { j = porta[(unsigned long long)x]; break; }
        }
        if (j < 0) continue;
        porta[n] = (unsigned char)j;
        if (j % 2 != 0 || j < 4) falhas++;             /* porta = 4^k com k ≥ 2: 16, 64, 256, ... */
        cont[j]++;
    }
    printf("{\"N\": %llu, \"falhas\": %llu, \"estouros\": %llu, \"portas\": {", N, falhas, estouros);
    int primeiro = 1;
    for (int j = 0; j < 128; j++)
        if (cont[j]) { printf("%s\"2^%d\": %llu", primeiro ? "" : ", ", j, cont[j]); primeiro = 0; }
    printf("}}\n");
    free(porta);
    return falhas || estouros;
}
