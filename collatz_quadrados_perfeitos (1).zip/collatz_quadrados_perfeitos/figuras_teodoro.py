#!/usr/bin/env python3
"""Figuras do artigo sobre a espiral de Teodoro e o problema 3n+1 (fig14 a fig17), em português ou inglês.
Os desenhos usam ponto flutuante; os valores exatos estão em collatz/confere_teodoro_collatz.py.
Uso, dentro de fig/:  python3 ../figuras_teodoro.py pt   (ou en)"""
import sys
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon, Rectangle

plt.rcParams.update({"font.family": "DejaVu Serif", "font.size": 9, "axes.linewidth": 0.6,
                     "savefig.bbox": "tight", "savefig.pad_inches": 0.04})
LANG = sys.argv[1] if len(sys.argv) > 1 else "pt"
AZUL, VERM, VERDE, OURO, CINZA, ROXO = "#1f4e9c", "#b22222", "#2e7d32", "#c08a00", "#888888", "#6a3d9a"


def L(pt, en):
    return en if LANG == "en" else pt


def arquivo(base):
    return f"{base}_{LANG}.pdf"


def teodoro(nmax):
    """v[n] = ponto depois de n segmentos de lado 1 (v[1] = (1, 0)); |v[n]|² = n."""
    v = np.zeros((nmax + 1, 2))
    v[1] = (1.0, 0.0)
    for n in range(1, nmax):
        x, y = v[n]
        s = np.sqrt(n)
        v[n + 1] = (x - y / s, y + x / s)
    return v


def circulo(ax, q, **kw):
    u = np.linspace(0, 2 * np.pi, 400)
    r = np.sqrt(q)
    ax.plot(r * np.cos(u), r * np.sin(u), **kw)


def eh_quadrado(n):
    return int(round(np.sqrt(n))) ** 2 == n


# ------------------------------------------------------------------------------------------------ fig14
def fig14():
    v = teodoro(18)
    fig = plt.figure(figsize=(11.2, 4.3))
    gs = fig.add_gridspec(1, 3, width_ratios=[1.25, 1.0, 0.8], wspace=0.12)

    ax = fig.add_subplot(gs[0])
    for n in range(1, 18):
        circulo(ax, n, color=OURO if eh_quadrado(n) else "#cfcfcf", lw=0.9 if eh_quadrado(n) else 0.5,
                ls="-" if eh_quadrado(n) else (0, (2, 2)), zorder=1)
    for n in range(1, 17):
        cor = "#e3d7ef" if n == 13 else "#eef2f8"
        ax.add_patch(Polygon([(0, 0), v[n], v[n + 1]], closed=True, fc=cor, ec="none", zorder=2))
        ax.plot([0, v[n + 1][0]], [0, v[n + 1][1]], color=CINZA, lw=0.45, zorder=3)
        ax.plot([v[n][0], v[n + 1][0]], [v[n][1], v[n + 1][1]], color=AZUL, lw=1.4, zorder=4)
    ax.plot([0, 1], [0, 0], color=AZUL, lw=1.4, zorder=4)
    ax.plot([v[17][0], v[18][0]], [v[17][1], v[18][1]], color=VERM, lw=1.1, ls="--", zorder=4)
    ax.plot([0, v[18][0]], [0, v[18][1]], color=VERM, lw=0.6, ls="--", zorder=4)
    for n in range(1, 18):
        d = v[n] / np.linalg.norm(v[n])
        ax.text(*(v[n] + 0.32 * d), str(n), fontsize=6.5, ha="center", va="center",
                color=OURO if eh_quadrado(n) else "k", fontweight="bold" if eh_quadrado(n) else "normal")
    ax.plot(1, 0, "s", color=VERM, ms=6, zorder=6)
    ax.plot(0, 0, "o", color="k", ms=2.5, zorder=6)
    c13 = (v[13] + v[14]) / 3
    ax.annotate(L("triângulo 13: quadrâncias 13, 1, 14\nspread no centro 1/14\ncossecante $\\sqrt{14}$",
                  "triangle 13: quadrances 13, 1, 14\nspread at the centre 1/14\ncosecant $\\sqrt{14}$"),
                xy=c13, xytext=(-5.0, -5.25), fontsize=7, color=ROXO, va="top",
                arrowprops=dict(arrowstyle="-|>", color=ROXO, lw=0.7))
    ax.text(v[18][0] + 0.15, v[18][1] - 0.55, L("17º triângulo:\n364,78° > 360°", "17th triangle:\n364.78° > 360°"),
            fontsize=6.5, color=VERM)
    ax.set_title(L("(a) 16 triângulos de lado 1 até $\\sqrt{17}$ (351,15°)\n"
                   "círculos $x^2+y^2=n$; dourado: quadrados perfeitos",
                   "(a) 16 triangles of side 1 up to $\\sqrt{17}$ (351.15°)\n"
                   "circles $x^2+y^2=n$; gold: perfect squares"), fontsize=8)
    ax.set_aspect("equal"); ax.axis("off")
    ax.set_xlim(-5.0, 4.6); ax.set_ylim(-6.6, 4.6)

    ax = fig.add_subplot(gs[1])
    r3 = np.sqrt(3)
    O, A, B = np.array([0, 0]), np.array([r3, 0]), np.array([r3, 1.0])
    u = np.linspace(-0.25, 0.95, 200)
    ax.plot(r3 * np.cos(u), r3 * np.sin(u), color="#9a9a9a", lw=0.8, ls=(0, (2, 2)))
    ax.plot(2 * np.cos(u), 2 * np.sin(u), color=OURO, lw=1.0)
    ax.add_patch(Polygon([O, A, B], closed=True, fc="#eef2f8", ec="none"))
    ax.plot(*zip(O, A), color=CINZA, lw=1.0)
    ax.plot(*zip(O, B), color=CINZA, lw=1.0)
    ax.plot(*zip(A, B), color=AZUL, lw=2.0)
    ax.plot([r3, r3], [-0.3, 1.3], color=AZUL, lw=0.6, ls=":")
    s = 0.09
    ax.plot([r3 - s, r3 - s, r3], [0, s, s], color="k", lw=0.6)
    ax.text(0.83, -0.16, L("quadrância 3", "quadrance 3"), fontsize=7.5, ha="center")
    ax.text(r3 + 0.07, 0.5, "1", fontsize=9, color=AZUL, va="center")
    ax.text(0.72, 0.55, L("quadrância 4", "quadrance 4"), fontsize=7.5, rotation=30, ha="center")
    ax.text(0.38, 0.07, L("spread 1/4", "spread 1/4"), fontsize=6.5, color=ROXO)
    ax.text(1.79, -0.62, "$x^2+y^2=3$", fontsize=7, color="#777777")
    ax.text(2 * np.cos(0.93) + 0.05, 2 * np.sin(0.93) + 0.05, L("$x^2+y^2=4$ (raio inteiro 2)", "$x^2+y^2=4$ (integer radius 2)"),
            fontsize=7, color=OURO)
    ax.text(-0.05, -0.95, L("o passo de lado 1 é tangente ao círculo 3 em $v_3$\n"
                            "e termina no círculo 4: potência de $v_4$ em relação\n"
                            "ao círculo 3 = 4 − 3 = 1 = (lado 1)²\n"
                            "planificação: (1,1,1,0) → (1,1,1,1), a diagonal do\n"
                            "cubo de dimensão 3 mais uma aresta perpendicular",
                            "the side-1 step is tangent to circle 3 at $v_3$\n"
                            "and ends on circle 4: power of $v_4$ with respect\n"
                            "to circle 3 = 4 − 3 = 1 = (side 1)²\n"
                            "development: (1,1,1,0) → (1,1,1,1), the diagonal of\n"
                            "the 3-dimensional cube plus one perpendicular edge"), fontsize=6.6, va="top")
    ax.plot(*A, "o", color="k", ms=3); ax.plot(*B, "o", color=OURO, ms=4, mec="k", mew=0.4); ax.plot(0, 0, "o", color="k", ms=2.5)
    ax.text(A[0] + 0.05, A[1] - 0.14, "$v_3$", fontsize=8); ax.text(B[0] + 0.06, B[1] + 0.03, "$v_4$", fontsize=8)
    ax.set_title(L("(b) um passo: tangente ao círculo $n$,\nchega ao círculo $n+1$", "(b) one step: tangent to circle $n$,\nlands on circle $n+1$"), fontsize=8)
    ax.set_aspect("equal"); ax.axis("off")
    ax.set_xlim(-0.1, 2.75); ax.set_ylim(-2.25, 1.85)

    ax = fig.add_subplot(gs[2])
    for linha, n in enumerate(range(1, 5)):
        y0 = -1.6 * linha
        for i in range(n):
            ax.add_patch(Rectangle((i, y0), 1, 1, fc="#f6efd9", ec="none"))
        segs = [((i, y0), (i + 1, y0)) for i in range(n)] + [((i, y0 + 1), (i + 1, y0 + 1)) for i in range(n)] + \
               [((i, y0), (i, y0 + 1)) for i in range(n + 1)]
        for a, b in segs:
            ax.plot(*zip(a, b), color=AZUL, lw=1.8, solid_capstyle="round")
        ax.text(n + 0.3, y0 + 0.5, f"n = {n}:  3·{n}+1 = {3 * n + 1}", fontsize=8, va="center")
    ax.set_title(L("(c) fileira de $n$ quadrados:\n$3n+1$ segmentos de lado 1", "(c) a row of $n$ squares:\n$3n+1$ segments of side 1"), fontsize=8)
    ax.set_aspect("equal"); ax.axis("off")
    ax.set_xlim(-0.2, 8.6); ax.set_ylim(-5.2, 1.3)
    fig.savefig(arquivo("fig14_teodoro_circulos")); plt.close(fig)


# ------------------------------------------------------------------------------------------------ fig15
def vertices(j):
    m = j // 2
    if j % 2 == 0:
        return np.array([(2 ** m, 0), (0, 2 ** m), (-2 ** m, 0), (0, -2 ** m)], float)
    return np.array([(2 ** m, 2 ** m), (-2 ** m, 2 ** m), (-2 ** m, -2 ** m), (2 ** m, -2 ** m)], float)


def fig15():
    v = teodoro(64)
    fig = plt.figure(figsize=(11.2, 4.6))
    gs = fig.add_gridspec(1, 3, width_ratios=[1.3, 0.95, 0.95], wspace=0.1)

    ax = fig.add_subplot(gs[0])
    ax.plot(v[1:, 0], v[1:, 1], color="#c9c9c9", lw=0.7, zorder=1)
    for j in range(0, 7):
        par = j % 2 == 0
        circulo(ax, 2 ** j, color=OURO if par else ROXO, lw=1.0, zorder=2)
        V = vertices(j)
        ax.add_patch(Polygon(V, closed=True, fill=False, ec="#333333", lw=0.7, zorder=3))
        ax.plot(V[:, 0], V[:, 1], "o", color=OURO if par else ROXO, ms=3, mec="k", mew=0.3, zorder=4)
    for j in range(0, 7):
        p = v[2 ** j]
        ax.plot(*p, "o", color="k", ms=3.2, zorder=5)
        d = p / np.linalg.norm(p)
        ax.text(*(p + 0.55 * d), str(2 ** j), fontsize=7, ha="center", va="center", zorder=6,
                bbox=dict(boxstyle="round,pad=0.12", fc="white", ec="none", alpha=0.8))
    ax.plot(1, 0, "s", color=VERM, ms=7, zorder=7)
    ax.set_title(L("(a) progressão de quadrados inscritos e circunscritos\n"
                   "nos círculos $x^2+y^2=2^j$\ndourado: $4^m$ (raio inteiro); roxo: $2\\cdot4^m$",
                   "(a) progression of inscribed and circumscribed squares\n"
                   "in the circles $x^2+y^2=2^j$\ngold: $4^m$ (integer radius); purple: $2\\cdot4^m$"), fontsize=8)
    ax.text(-8.4, -9.6, L("pontos pretos: $v_{2^j}$ da espiral de Teodoro (cinza); quadrado vermelho: ponto inicial (1, 0)\n"
                          "descida final do 3n+1: 64 → 32 → 16 → 8 → 4 → 2 → 1",
                          "black dots: $v_{2^j}$ of the Theodorus spiral (grey); red square: initial point (1, 0)\n"
                          "final descent of 3n+1: 64 → 32 → 16 → 8 → 4 → 2 → 1"), fontsize=6.8, va="top")
    ax.set_aspect("equal"); ax.axis("off")
    ax.set_xlim(-8.6, 8.6); ax.set_ylim(-8.6, 8.6)

    ax = fig.add_subplot(gs[1])
    ax.add_patch(Rectangle((0, 0), 1, 1, fc="#f6efd9", ec="none", zorder=1))
    ax.add_patch(Polygon([(0, 0), (1, 0), (1, 1)], closed=True, fc="#dfe8f5", ec="none", zorder=2))
    circulo(ax, 0.5, color=ROXO, lw=0.8, ls=(0, (2, 2)), zorder=2)
    circulo(ax, 1, color=OURO, lw=1.1, zorder=2)
    circulo(ax, 2, color=ROXO, lw=1.1, zorder=2)
    for j in (0, 1):
        ax.add_patch(Polygon(vertices(j), closed=True, fill=False, ec="#333333", lw=0.8, zorder=3))
    ax.plot([0, 1], [0, 0], color=AZUL, lw=1.6, zorder=4)
    ax.plot([1, 1], [0, 1], color=AZUL, lw=2.2, zorder=4)
    ax.plot([0, 1], [0, 1], color=VERM, lw=1.3, zorder=4)
    ax.plot(1, 0, "s", color=VERM, ms=7, zorder=6)
    ax.plot(1, 1, "o", color=ROXO, ms=4, mec="k", mew=0.4, zorder=6)
    ax.plot(0, 0, "o", color="k", ms=2.5, zorder=6)
    ax.text(1.04, -0.13, "$v_1=(1,0)$", fontsize=7.5)
    ax.text(1.04, 1.05, "$v_2=(1,1)$", fontsize=7.5)
    ax.text(-1.55, -1.75, L("1º passo: meia aresta do quadrado $S_1$,\n"
                            "tangente ao círculo 1 no ponto inicial;\n"
                            "1ª hipotenusa $\\sqrt{2}$: diagonal do quadrado\n"
                            "unitário e meia diagonal de $S_1$. Mênon: o\n"
                            "quadrado sobre a diagonal tem o dobro da área.\n"
                            "Tracejado: a progressão segue para dentro\n"
                            "(quadrância 1/2, 1/4, …) e para fora (2, 4, 8, …)",
                            "1st step: half an edge of the square $S_1$,\n"
                            "tangent to circle 1 at the initial point;\n"
                            "1st hypotenuse $\\sqrt{2}$: diagonal of the unit\n"
                            "square and half-diagonal of $S_1$. Meno: the\n"
                            "square on the diagonal has twice the area.\n"
                            "Dashed: the progression goes on inwards\n"
                            "(quadrance 1/2, 1/4, …) and outwards (2, 4, 8, …)"), fontsize=6.6, va="top")
    ax.text(-0.5, 0.15, "$S_0$", fontsize=8); ax.text(-0.95, 0.75, "$S_1$", fontsize=8)
    ax.set_title(L("(b) o início da espiral\né o início da progressão", "(b) the start of the spiral\nis the start of the progression"), fontsize=8)
    ax.set_aspect("equal"); ax.axis("off")
    ax.set_xlim(-1.6, 1.75); ax.set_ylim(-3.3, 1.6)

    ax = fig.add_subplot(gs[2])
    v10 = teodoro(10)
    p = v10[10]
    rot = np.array([[0, -1], [1, 0]])
    Q = np.array([p, rot @ p, -p, -(rot @ p)])
    circulo(ax, 10, color="#555555", lw=1.0)
    circulo(ax, 5, color=VERDE, lw=1.0)
    ax.add_patch(Polygon(Q, closed=True, fill=False, ec="#333333", lw=0.9))
    meios = (Q + np.roll(Q, -1, axis=0)) / 2
    ax.plot(meios[:, 0], meios[:, 1], "o", color=VERDE, ms=3.5, mec="k", mew=0.3)
    ax.plot(*p, "o", color="k", ms=3.5)
    ax.plot(*v10[5], "o", color="k", ms=3.5)
    ax.text(p[0] - 0.95, p[1] + 0.3, "$v_{10}$", fontsize=8)
    ax.text(v10[5][0] + 0.12, v10[5][1] + 0.12, "$v_5$", fontsize=8)
    ax.plot([0, p[0]], [0, p[1]], color=CINZA, lw=0.7)
    ax.plot([0, meios[0, 0]], [0, meios[0, 1]], color=VERDE, lw=0.7)
    ax.plot(0, 0, "o", color="k", ms=2.5)
    ax.text(-3.4, -3.75, L("passo par 10 → 5: do círculo $x^2+y^2=10$ ao círculo\n"
                           "inscrito no seu quadrado inscrito, $x^2+y^2=5$.\n"
                           "Lado do quadrado inscrito: quadrância $2n$; apótema: $n/2$",
                           "even step 10 → 5: from the circle $x^2+y^2=10$ to the circle\n"
                           "inscribed in its inscribed square, $x^2+y^2=5$.\n"
                           "Side of the inscribed square: quadrance $2n$; apothem: $n/2$"), fontsize=6.6, va="top")
    ax.set_title(L("(c) o passo par $n\\to n/2$\né o Mênon ao contrário", "(c) the even step $n\\to n/2$\nis the Meno backwards"), fontsize=8)
    ax.set_aspect("equal"); ax.axis("off")
    ax.set_xlim(-3.5, 3.5); ax.set_ylim(-5.1, 3.4)
    fig.savefig(arquivo("fig15_progressao_quadrados")); plt.close(fig)


# ------------------------------------------------------------------------------------------------ fig16
def cruzamentos(nmax):
    """Raios em que a espiral (poligonal) cruza a semirreta do ponto inicial (eixo x positivo), volta após volta."""
    raios = []
    x, y = 1.0, 0.0
    for n in range(1, nmax):
        s = np.sqrt(n)
        x2, y2 = x - y / s, y + x / s
        if y < 0 <= y2 and x > 0:
            t = -y / (y2 - y)
            raios.append(x + t * (x2 - x))
        x, y = x2, y2
    return np.array(raios)


def fig16():
    fig = plt.figure(figsize=(11.4, 4.2))
    gs = fig.add_gridspec(1, 3, width_ratios=[1.15, 1.0, 1.0], wspace=0.18)
    ax = fig.add_subplot(gs[0], projection="3d")
    nmax = 25
    v = teodoro(nmax)
    rr = np.linspace(0, 5.1, 14)
    uu = np.linspace(0, 2 * np.pi, 49)
    Rm, Um = np.meshgrid(rr, uu)
    ax.plot_wireframe(Rm * np.cos(Um), Rm * np.sin(Um), Rm ** 2, color="#c8c8c8", lw=0.3, rstride=2, cstride=1)
    u = np.linspace(0, 2 * np.pi, 200)
    for n in (1, 4, 9, 16, 25):
        r = np.sqrt(n)
        ax.plot(r * np.cos(u), r * np.sin(u), n * np.ones_like(u), color=OURO, lw=0.9)
        ax.plot(r * np.cos(u), r * np.sin(u), 0 * u, color=OURO, lw=0.5, alpha=0.6)
    ax.plot(v[1:, 0], v[1:, 1], np.zeros(nmax), color=CINZA, lw=0.9)
    ax.plot(v[1:, 0], v[1:, 1], np.arange(1, nmax + 1), color=AZUL, lw=1.6)
    ax.scatter(v[1:, 0], v[1:, 1], np.arange(1, nmax + 1), color=AZUL, s=6, depthshade=False)
    for n in (1, 4, 9, 16, 25):
        ax.plot([v[n][0]] * 2, [v[n][1]] * 2, [0, n], color=OURO, lw=0.6, ls=":")
    ax.set_xlim(-5, 5); ax.set_ylim(-5, 5); ax.set_zlim(0, 26)
    ax.set_box_aspect((1, 1, 1.15))
    ax.view_init(elev=20, azim=-62)
    ax.set_xticks([-4, 0, 4]); ax.set_yticks([-4, 0, 4]); ax.set_zticks([0, 4, 9, 16, 25])
    ax.tick_params(labelsize=6, pad=0)
    ax.set_zlabel(L("z = quadrância", "z = quadrance"), fontsize=7, labelpad=-2)
    ax.set_title(L("(a) elevação $(v_n, n)$ no paraboloide $z=x^2+y^2$:\ncada passo sobe 1 e anda 1 (45°); a sombra é a espiral",
                   "(a) lift $(v_n, n)$ on the paraboloid $z=x^2+y^2$:\neach step rises 1 and moves 1 (45°); the shadow is the spiral"),
                 fontsize=8)

    ax = fig.add_subplot(gs[1])
    v = teodoro(1000)
    ax.plot(v[1:, 0], v[1:, 1], color=AZUL, lw=0.5)
    cr = cruzamentos(1000)
    ax.plot(cr, 0 * cr, "o", color=VERM, ms=2.8)
    ax.plot([0, 34], [0, 0], color=VERM, lw=0.5)
    ax.plot(0, 0, "o", color="k", ms=2)
    ax.set_title(L("(b) 1000 segmentos de lado 1: a espiral não fecha;\nvermelho: onde cada volta cruza a semirreta de (1, 0)",
                   "(b) 1000 segments of side 1: the spiral does not close;\nred: where each turn crosses the ray of (1, 0)"), fontsize=8)
    ax.set_aspect("equal"); ax.axis("off")

    ax = fig.add_subplot(gs[2])
    cr = cruzamentos(4_000_000)
    gaps = np.diff(cr)
    m = np.arange(1, len(gaps) + 1)
    ax.semilogx(m, gaps, "o-", color=AZUL, ms=1.8, lw=0.7)
    ax.axhline(np.pi, color=VERM, lw=0.8, ls="--")
    ax.text(1.3, np.pi + 0.0035, "π", color=VERM, fontsize=10)
    ax.set_xlabel(L("volta $m$", "turn $m$"), fontsize=8)
    ax.set_ylabel(L("afastamento entre as voltas $m$ e $m+1$", "gap between turns $m$ and $m+1$"), fontsize=8)
    ax.set_ylim(3.13, 3.18)
    if LANG == "pt":
        from matplotlib.ticker import FuncFormatter
        ax.yaxis.set_major_formatter(FuncFormatter(lambda y, _: f"{y:.3f}".replace(".", ",")))
    ax.tick_params(labelsize=7)
    ax.grid(alpha=0.25, lw=0.4)
    ax.set_title(L("(c) o afastamento tende a π (numérico, $4\\cdot10^6$ segmentos):\n"
                   "π não entra na construção; ele mede o quanto a volta não fecha",
                   "(c) the gap tends to π (numerical, $4\\cdot10^6$ segments):\n"
                   "π does not enter the construction; it measures how far the turn fails to close"), fontsize=8)
    fig.savefig(arquivo("fig16_teodoro_paraboloide")); plt.close(fig)
    return cr


# ------------------------------------------------------------------------------------------------ fig17
def trajetoria(n, a=3, b=1, parar=None, passos=400):
    t, vistos = [n], {n}
    while len(t) < passos:
        n = n // 2 if n % 2 == 0 else a * n + b
        t.append(n)
        if n == 1 or (parar and n in vistos):
            break
        vistos.add(n)
    return t


def perfil(ax, t, titulo, raios_porta, cor_porta, nota, log=False):
    """Trajetória como perfil: no eixo horizontal o passo, no vertical a distância √N do ponto v_N ao centro da espiral.
    As linhas tracejadas são os círculos das portas. Sem cordas entre pontos, para não formar polígonos estrelados."""
    x = np.arange(len(t))
    y = np.sqrt(np.array(t, float))
    for r in raios_porta:
        ax.axhline(r, color=cor_porta, lw=0.9, ls=(0, (4, 3)), zorder=1)
    ax.plot(x, y, color=AZUL, lw=1.0, zorder=2)
    for xi, N in zip(x, t):
        if eh_quadrado(N):
            ax.plot(xi, np.sqrt(N), "s", color=OURO, mec="k", mew=0.4, ms=4.5, zorder=4)
        else:
            ax.plot(xi, np.sqrt(N), "o", color="k", ms=2.2, zorder=3)
    if log:
        ax.set_yscale("log")
    ax.set_title(titulo, fontsize=7.6)
    ax.set_xlabel(L("passo", "step"), fontsize=7)
    ax.set_ylabel(L("distância ao centro, $\\sqrt{N}$", "distance to the centre, $\\sqrt{N}$"), fontsize=7)
    ax.tick_params(labelsize=6.5)
    from matplotlib.ticker import MaxNLocator
    ax.xaxis.set_major_locator(MaxNLocator(integer=True))
    ax.grid(alpha=0.2, lw=0.4)
    ax.text(0.5, -0.27, nota, transform=ax.transAxes, fontsize=6.6, ha="center", va="top", color=cor_porta)


def ciclo_repetido(n, a, b, voltas=2):
    c = [n]
    while True:
        x = c[-1]
        x = x // 2 if x % 2 == 0 else a * x + b
        if x == n:
            break
        c.append(x)
    return c * voltas + [n]


def fig17():
    fig, axs = plt.subplots(2, 3, figsize=(11.2, 6.6))
    portas_mais = [2 ** k for k in range(2, 8)]                       # raios 2^k: portas 4^k
    portas_menos = [2 ** k * np.sqrt(2) for k in range(1, 5)]          # raios 2^k·√2: portas 2·4^k
    portas_5 = [4 ** k for k in range(1, 3)]                           # raios 4^k: portas 16^k
    perfil(axs[0, 0], trajetoria(3), "3n+1:  3 → 10 → 5 → 16 → 8 → 4 → 2 → 1", [r for r in portas_mais if r <= 5], OURO,
           L("porta 16 = 4²: círculo de raio inteiro 4", "door 16 = 4²: circle of integer radius 4"))
    perfil(axs[0, 1], trajetoria(7), L("3n+1: trajetória de 7 (máximo 52)", "3n+1: trajectory of 7 (maximum 52)"),
           [r for r in portas_mais if r <= 8], OURO, L("porta 16 = 4², vinda do ímpar 5", "door 16 = 4², coming from the odd number 5"))
    perfil(axs[0, 2], trajetoria(27), L("3n+1: trajetória de 27 (111 passos, máximo 9232)", "3n+1: trajectory of 27 (111 steps, maximum 9232)"),
           portas_mais, OURO, L("porta 16 = 4²; tracejado: círculos das portas $4^k$", "door 16 = 4²; dashed: circles of the doors $4^k$"), log=True)
    perfil(axs[1, 0], ciclo_repetido(5, 3, -1), L("3n−1: ciclo 5 → 14 → 7 → 20 → 10 → 5 (duas voltas)", "3n−1: cycle 5 → 14 → 7 → 20 → 10 → 5 (two rounds)"),
           [r for r in portas_menos if r <= 6], ROXO, L("portas do 3n−1: $2\\cdot4^k$; o ciclo não pousa em nenhuma", "doors of 3n−1: $2\\cdot4^k$; the cycle lands on none"))
    perfil(axs[1, 1], ciclo_repetido(17, 3, -1), L("3n−1: ciclo de 17 (18 termos, duas voltas)", "3n−1: cycle of 17 (18 terms, two rounds)"),
           [r for r in portas_menos if r <= 17], ROXO, L("o ciclo de 17 não passa por nenhuma porta", "the cycle of 17 passes through no door"))
    perfil(axs[1, 2], ciclo_repetido(13, 5, 1), L("5n+1: ciclo de 13 (10 termos, duas voltas)", "5n+1: cycle of 13 (10 terms, two rounds)"),
           portas_5, OURO, L("portas do 5n+1: $16^k$, quadrados perfeitos; o ciclo não pousa em nenhuma",
                             "doors of 5n+1: $16^k$, perfect squares; the cycle lands on none"))
    fig.text(0.5, -0.035, L("cada valor $N$ é o ponto $v_N$ da espiral de Teodoro, à distância $\\sqrt{N}$ do centro; quadrados dourados: quadrados perfeitos (raio inteiro)",
                           "each value $N$ is the point $v_N$ of the spiral of Theodorus, at distance $\\sqrt{N}$ from the centre; gold squares: perfect squares (integer radius)"),
             ha="center", va="top", fontsize=7.4)
    fig.subplots_adjust(hspace=0.75, wspace=0.28)
    fig.savefig(arquivo("fig17_teodoro_collatz")); plt.close(fig)


if __name__ == "__main__":
    fig14()
    fig15()
    cr = fig16()
    fig17()
    g = np.diff(cr)
    print("voltas:", len(cr), "primeiros afastamentos:", np.round(g[:6], 5), "últimos:", np.round(g[-3:], 6))
    print("afastamento médio das voltas 2 a 5 (raio na volta m+1 menos o da volta 1, dividido por m):",
          [round((cr[m] - cr[0]) / m, 6) for m in range(1, 6)])
