#!/usr/bin/env python3
"""
loop_csc14.py — Teorema do loop da cossecante √14. Implementação A.

Python 3, só biblioteca padrão. Todos os certificados usam inteiros e frações exatas;
ponto flutuante aparece só na ilustração final de densidade, rotulada como numérica.

Pré-registro (previsões fixadas antes da primeira execução):
  P1  No triângulo da caixa 1×2×3 com vértices −P, P', P (P = (1/2,1,3/2), P' = (−1/2,1,3/2)),
      as quadrâncias são 1, 13, 14, o ângulo reto está em P', e o ângulo θ em −P, oposto ao
      cateto 1, tem spread 1/14: sen²θ = 1/14, csc²θ = 14.
  P2  O quatérnio q = 13 + 2j + 3k (norma 182 = 13·14) tem meio-ângulo θ e dá a rotação exata
      R = R(q)/182 = M/91 de ângulo 2θ em torno de a = (0,2,3): RᵀR = I, det R = 1, Ra = a,
      tr R = 19/7, cos 2θ = 6/7.
  P3  Para 1 ≤ n ≤ N: Rⁿ ≠ I; tr Rⁿ = 1 + 2·Tₙ(6/7); Tₙ(6/7) = Cₙ/7ⁿ com 7 ∤ Cₙ.
  P4  Pₙ = RⁿP está em 𝒮 (|X|² = 7/2) e no círculo C (X·a = 13/2, centro a/2, raio 1/2,
      diâmetro PP'); Pₙ = (Cₙ/(2·7ⁿ), 1 + 3Dₙ₋₁/(2·7ⁿ), 3/2 − Dₙ₋₁/7ⁿ), Dₖ = 7ᵏ·Uₖ(6/7);
      denominador comum exatamente 2·7ⁿ; Pₙ ∉ {P, P'}; 2Pₙ nunca é inteiro.
  P5  b = 1 + 2j + 3k (norma 14): q·b = 14(2j + 3k); R_q·R_b = H = (2aaᵀ − 13I)/13;
      HP = P'; (R_q·R_b)² = I: o loop fecha em quatro passos, pela meia-volta.
  P6  Passos de Teodoro n → n+1 (csc √(n+1), cos 2θₙ = (n−1)/(n+1)), 1 ≤ n ≤ 2000, busca de
      Tₖ = 1 até k = 60: fechamento só em n = 1 (k = 4) e n = 3 (k = 6).
  P7  Em seno zero a cossecante não existe: 1/0 não é número; K(1)² = 14;
      K(10⁻ᵏ)² = 13·10²ᵏ + 1, sem cota.
  P8  Critério: rotação racional fecha ⇔ tr ∈ {3, 2, 1, 0, −1}. Na auditoria só a meia-volta
      M7/7 fecha (ordem 2); T₋₁,₃, T₁,₁, M3/3, R_q, R_b e a rotação da Cotα não fecham.
  P9  As dezesseis sabotagens são acusadas.
  P10 Teodoro e o tetraedro regular de aresta √7: arestas de quadrância 7;
      a altura da face é o triângulo de Teodoro 1, √3, 2 (passo 3 → 4, csc 2), e seis faces fecham
      em 60°; o diedro tem cos δ = 1/3, Tₖ(1/3) tem denominador 3ᵏ e nunca vale 1 (cinco tetraedros
      deixam a fenda 241/243); os quatro tetraedros K do octaedro 𝒪7 em torno do eixo √14
      (dobra 7 + 7 = 14, passo 1 → 2, csc √2) fecham em 4.

  P13 O círculo plano como projeção: octaedro de altura √14, quadrados inscrito e
      circunscrito a 45°, tetraedro T+ como quadrado com diagonais, tetraedro regular de aresta 7.
  P14 As quatro arestas laterais cruzam o plano do círculo no perímetro, ⟂ ao raio e a 45°
      do plano; o círculo pelos vértices projetados não é tocado.

Uso:   python3 loop_csc14.py [N]        (N padrão: 2000)
Saída: resumo na tela e resultados_loop_csc14_A.json; código de saída 0 se tudo confere.
"""

import json
import math
import sys
import time
from fractions import Fraction as F

# ---------------------------------------------------------------- álgebra exata


def dot(u, v):
    return sum(x * y for x, y in zip(u, v))


def sub(u, v):
    return tuple(x - y for x, y in zip(u, v))


def add(u, v):
    return tuple(x + y for x, y in zip(u, v))


def scal(k, u):
    return tuple(k * x for x in u)


def cross(u, v):
    return (u[1] * v[2] - u[2] * v[1], u[2] * v[0] - u[0] * v[2], u[0] * v[1] - u[1] * v[0])


def mat_mul(A, B):
    return tuple(tuple(sum(A[i][k] * B[k][j] for k in range(3)) for j in range(3)) for i in range(3))


def mat_vec(A, v):
    return tuple(sum(A[i][k] * v[k] for k in range(3)) for i in range(3))


def transpose(A):
    return tuple(tuple(A[j][i] for j in range(3)) for i in range(3))


def mat_scale(k, A):
    return tuple(tuple(k * x for x in row) for row in A)


def mat_add(A, B):
    return tuple(tuple(x + y for x, y in zip(r, s)) for r, s in zip(A, B))


def ident(k=1):
    return tuple(tuple(k if i == j else 0 for j in range(3)) for i in range(3))


def outer(u, v):
    return tuple(tuple(x * y for y in v) for x in u)


def trace(A):
    return A[0][0] + A[1][1] + A[2][2]


def det3(A):
    return (A[0][0] * (A[1][1] * A[2][2] - A[1][2] * A[2][1])
            - A[0][1] * (A[1][0] * A[2][2] - A[1][2] * A[2][0])
            + A[0][2] * (A[1][0] * A[2][1] - A[1][1] * A[2][0]))


def quat_mul(p, q):
    a1, b1, c1, d1 = p
    a2, b2, c2, d2 = q
    return (a1 * a2 - b1 * b2 - c1 * c2 - d1 * d2,
            a1 * b2 + b1 * a2 + c1 * d2 - d1 * c2,
            a1 * c2 - b1 * d2 + c1 * a2 + d1 * b2,
            a1 * d2 + b1 * c2 - c1 * b2 + d1 * a2)


def quat_norm2(q):
    return sum(x * x for x in q)


def rodrigues(q):
    """Matriz inteira de Euler–Rodrigues: R(q)/|q|² é a rotação X ↦ qXq⁻¹."""
    a, b, c, d = q
    return ((a * a + b * b - c * c - d * d, 2 * (b * c - a * d), 2 * (b * d + a * c)),
            (2 * (b * c + a * d), a * a - b * b + c * c - d * d, 2 * (c * d - a * b)),
            (2 * (b * d - a * c), 2 * (c * d + a * b), a * a - b * b - c * c + d * d))


def spread(u, v):
    """Quadrado do seno do ângulo entre u e v, sem raízes."""
    return F(1) - F(dot(u, v) ** 2, dot(u, u) * dot(v, v))


def val(x, p):
    """Valuação p-ádica de um racional não nulo."""
    x = F(x)
    if x == 0:
        raise ValueError("valuação de zero")
    n, d, k = x.numerator, x.denominator, 0
    while n % p == 0:
        n //= p
        k += 1
    while d % p == 0:
        d //= p
        k -= 1
    return k


def common_den(vec):
    out = 1
    for x in vec:
        out = math.lcm(out, F(x).denominator)
    return out


def cheb_T(c, nmax):
    """[T₀(c), …, T_nmax(c)] exatos."""
    T = [F(1), F(c)]
    for _ in range(1, nmax):
        T.append(2 * c * T[-1] - T[-2])
    return T[:nmax + 1]


def cheb_U(c, nmax):
    """[U₀(c), …, U_nmax(c)] exatos."""
    U = [F(1), 2 * F(c)]
    for _ in range(1, nmax):
        U.append(2 * c * U[-1] - U[-2])
    return U[:nmax + 1]


# ---------------------------------------------------------------- registro

class Registro:
    def __init__(self):
        self.verificacoes = 0
        self.falhas = []

    def conta(self, ok, onde):
        self.verificacoes += 1
        if not ok:
            self.falhas.append(onde)
        return bool(ok)


REG = Registro()

# ---------------------------------------------------------------- objetos do artigo

P = (F(1, 2), F(1), F(3, 2))           # polo da esfera 𝒮, vértice da caixa
PL = (F(-1, 2), F(1), F(3, 2))         # P': outra ponta da aresta 1
D_DIAG = (1, 2, 3)                     # diagonal da caixa, quadrância 14
A_FACE = (0, 2, 3)                     # diagonal da face 2×3, quadrância 13
Q_CSC = (13, 0, 2, 3)                  # quatérnio da cossecante √14
B_CAIXA = (1, 0, 2, 3)                 # quatérnio da caixa, norma 14
RHO = F(7, 2)                          # raio ao quadrado de 𝒮


# ---------------------------------------------------------------- certificados (parametrizados para as sabotagens)

def cert_triangulo(P, PL, reg):
    mP = scal(-1, P)
    q_cateto = dot(sub(P, PL), sub(P, PL))
    q_face = dot(sub(PL, mP), sub(PL, mP))
    q_diag = dot(sub(P, mP), sub(P, mP))
    reto = dot(sub(P, PL), sub(mP, PL)) == 0
    s = spread(sub(P, mP), sub(PL, mP))
    ok = all([reg.conta(q_cateto == 1, "P1 cateto"), reg.conta(q_face == 13, "P1 face"),
              reg.conta(q_diag == 14, "P1 diagonal"), reg.conta(reto, "P1 ângulo reto"),
              reg.conta(s == F(1, 14), "P1 spread")])
    return ok, {"quadrancias": [str(q_cateto), str(q_face), str(q_diag)], "spread_theta": str(s),
                "csc2_theta": str(1 / s)}


def cert_quaternio(q, eixo, reg):
    v = q[1:]
    paralelo = cross(v, eixo) == (0, 0, 0) and dot(v, eixo) > 0
    sen2_meio = F(dot(v, v), quat_norm2(q))
    ok = all([reg.conta(paralelo, "P2 eixo do quatérnio"), reg.conta(sen2_meio == F(1, 14), "P2 meio-ângulo θ")])
    return ok, {"norma": quat_norm2(q), "sen2_meio_angulo": str(sen2_meio)}


def cert_rotacao(M, s, eixo, reg):
    ok = all([reg.conta(mat_mul(transpose(M), M) == ident(s * s), "P2 ortogonal"),
              reg.conta(det3(M) == s ** 3, "P2 det"),
              reg.conta(mat_vec(M, eixo) == scal(s, eixo), "P2 eixo fixo")])
    tr = F(trace(M), s)
    return ok, {"traco": str(tr), "cos": str((tr - 1) / 2)}


def cert_laco_aberto(M, s, c, N, reg, sete_adico=False):
    """Mⁿ ≠ sⁿI e tr(Mⁿ)/sⁿ = 1 + 2Tₙ(c) para 1 ≤ n ≤ N; opcionalmente 7 ∤ Cₙ e den Tₙ = 7ⁿ."""
    T = cheb_T(F(c), N)
    Mn, sn, ok, primeiro_fecho = ident(1), 1, True, None
    for n in range(1, N + 1):
        Mn, sn = mat_mul(Mn, M), sn * s
        aberto = Mn != ident(sn)
        if not aberto and primeiro_fecho is None:
            primeiro_fecho = n
        ok &= reg.conta(aberto, f"P3 loop aberto n={n}")
        ok &= reg.conta(F(trace(Mn), sn) == 1 + 2 * T[n], f"P3 traço n={n}")
        if sete_adico:
            ok &= reg.conta(T[n].denominator == 7 ** n and T[n].numerator % 7 != 0, f"P3 7-ádico n={n}")
    return ok, {"N": N, "primeiro_fechamento": primeiro_fecho}


def cert_orbita(M, s, P, PL, a, N, reg, den_esperado=lambda n: 2 * 7 ** n):
    """Órbita Pₙ = (M/s)ⁿP: esfera, círculo, forma fechada, denominadores, não retorno."""
    c = F(6, 7)
    T, U = cheb_T(c, N), cheb_U(c, N)
    W = tuple(2 * x for x in P)                       # 2P inteiro
    centro, raio2 = scal(F(1, 2), a), F(1, 4)
    ok, sn, pontos = True, 1, set()
    amostra = {}
    for n in range(1, N + 1):
        W, sn = mat_vec(M, W), sn * s
        Pn = tuple(F(x, 2 * sn) for x in W)
        ok &= reg.conta(dot(Pn, Pn) == RHO, f"P4 esfera n={n}")
        ok &= reg.conta(dot(Pn, a) == F(13, 2), f"P4 plano n={n}")
        ok &= reg.conta(dot(sub(Pn, centro), sub(Pn, centro)) == raio2, f"P4 raio n={n}")
        forma = (T[n] / 2, 1 + F(3, 2) * U[n - 1] / 7, F(3, 2) - U[n - 1] / 7)
        ok &= reg.conta(Pn == forma, f"P4 forma fechada n={n}")
        ok &= reg.conta(common_den(Pn) == den_esperado(n), f"P4 denominador n={n}")
        ok &= reg.conta(Pn != P and Pn != PL, f"P4 não volta a P nem chega a P' n={n}")
        ok &= reg.conta(any(F(2 * x).denominator != 1 for x in Pn), f"P4 fora do reticulado n={n}")
        ok &= reg.conta(Pn not in pontos, f"P4 ponto novo n={n}")
        pontos.add(Pn)
        if n <= 3:
            amostra[n] = [str(x) for x in Pn]
    return ok, {"N": N, "pontos_distintos": len(pontos), "primeiros": amostra}


def cert_meia_volta(q, b, eixo_ponte, a, P, PL, reg):
    qb = quat_mul(q, b)
    puro = qb[0] == 0
    Rq, Rb = rodrigues(q), rodrigues(b)
    nq, nb = quat_norm2(q), quat_norm2(b)
    prod = mat_mul(Rq, Rb)
    a2 = dot(a, a)
    H_num = mat_add(mat_scale(2, outer(a, a)), ident(-a2))          # 13·H
    k = F(nq * nb, a2)
    igual_H = k.denominator == 1 and prod == mat_scale(k.numerator, H_num)
    u2 = dot(eixo_ponte, eixo_ponte)
    H_ponte = mat_add(mat_scale(2, outer(eixo_ponte, eixo_ponte)), ident(-u2))
    ponte = mat_vec(H_ponte, P) == scal(u2, PL)
    fecha = mat_mul(prod, prod) == ident((nq * nb) ** 2)
    ok = all([reg.conta(puro, "P5 produto puro"), reg.conta(igual_H, "P5 R_q R_b = H"),
              reg.conta(ponte, "P5 HP = P'"), reg.conta(fecha, "P5 (R_q R_b)² = I")])
    return ok, {"q_vezes_b": list(qb), "13H": [list(r) for r in H_num]}


def fechamento_teodoro(nmax, kmax):
    """Para cada passo n → n+1, menor k ≤ kmax com Tₖ((n−1)/(n+1)) = 1, por busca direta."""
    achados = {}
    for n in range(1, nmax + 1):
        c = F(n - 1, n + 1)
        t_prev, t = F(1), c
        for k in range(1, kmax + 1):
            if k > 1:
                t_prev, t = t, 2 * c * t - t_prev
            if t == 1:
                achados[n] = k
                break
    return achados


def cert_seno_zero(reg, csc2_alegado=None):
    try:
        F(1) / F(0)
        existe = True
    except ZeroDivisionError:
        existe = False
    ok = reg.conta(not existe, "P7 1/0 não existe")
    ok &= reg.conta(F(13 + 1, 1) == 14, "P7 K(1)² = 14")
    for k in range(1, 21):
        t = F(1, 10 ** k)
        K2 = (13 + t * t) / (t * t)
        ok &= reg.conta(K2 == 13 * 10 ** (2 * k) + 1, f"P7 K² em t=10^-{k}")
    if csc2_alegado is not None:                       # sen²·csc² = 1 em seno zero?
        ok &= reg.conta(F(0) * csc2_alegado == 1, "P7 identidade sen²·csc² = 1 em seno zero")
    return ok


# ---------------------------------------------------------------- Teodoro e o tetraedro regular de aresta √7

def cert_tetraedro(N, reg, cos_diedro_alegado=None, fecha_em_5=False):
    """Canto da estrela octangular (21.4): referencial próprio com Gram ρI, ρ = 7/2.
    Quadrância real = ρ·|x|². Ângulos são invariantes de escala."""
    v = [(1, 1, 1), (1, 0, 0), (0, 1, 0), (0, 0, 1)]
    q = lambda x, y: RHO * dot(sub(x, y), sub(x, y))
    arestas = [q(v[i], v[j]) for i in range(4) for j in range(i + 1, 4)]
    ok = reg.conta(all(x == 7 for x in arestas), "P10 seis arestas de quadrância 7")
    # face: ângulo de 60° no vértice; altura da face dá o triângulo de Teodoro do passo 3 → 4
    a, b, c = v[1], v[2], v[3]
    s_face = spread(sub(b, a), sub(c, a))
    m = scal(F(1, 2), add(b, c))                                    # pé da altura da face
    meia, alt = q(b, m), q(a, m)
    s_teo3 = spread(sub(a, b), sub(a, m))                           # ângulo no vértice entre aresta e altura
    ok &= reg.conta(s_face == F(3, 4) and dot(sub(b, a), sub(c, a)) * 2 == dot(sub(b, a), sub(b, a)), "P10 face 60°")
    ok &= reg.conta(meia == F(7, 4) and alt == F(21, 4) and meia + alt == 7 and s_teo3 == F(1, 4),
                    "P10 altura da face = triângulo de Teodoro 1, √3, 2 (csc 2)")
    # diedro: cos δ = 1/3 entre as faces que partilham a aresta bc
    n1 = cross(sub(b, a), sub(c, a))
    n2 = cross(sub(c, v[0]), sub(b, v[0]))
    cos_d = F(-dot(n1, n2)) / F(dot(n1, n1)) if dot(n1, n1) == dot(n2, n2) else None
    cos_d = cos_diedro_alegado if cos_diedro_alegado is not None else cos_d
    ok &= reg.conta(cos_d == F(1, 3), "P10 diedro cos δ = 1/3")
    T = cheb_T(F(1, 3), N)
    for k in range(1, N + 1):
        ok &= reg.conta(T[k] != 1 and T[k].denominator == 3 ** k, f"P10 tetraedros em torno da aresta, k={k}")
    ok &= reg.conta(T[5] == F(241, 243), "P10 cinco tetraedros: fenda 241/243")
    if fecha_em_5:
        ok &= reg.conta(T[5] == 1, "P10 alegação: cinco tetraedros fecham")
    # octaedro 𝒪7: os quatro tetraedros K em torno do eixo √14 (dobra 7 + 7 = 14, Teodoro 1 → 2)
    s_dobra = spread((2, 0, 0), (1, 1, 0))                           # em −P: eixo −P→P e aresta −P→u₂ (ref. próprio)
    G = ((1, 0, 0), (0, 0, -1), (0, 1, 0))                          # (α,β,γ) ↦ (α,−γ,β): giro de 90° em torno do eixo
    ok &= reg.conta(s_dobra == F(1, 2), "P10 dobra 7+7=14: csc √2")
    ok &= reg.conta(ordem_direta(G, 1, 12) == 4 and mat_vec(G, (1, 0, 0)) == (1, 0, 0), "P10 quatro tetraedros K fecham em 4")
    return ok, {"arestas_quadrancia": [str(x) for x in arestas], "spread_face": str(s_face),
                "altura_face": {"meia_aresta2": str(meia), "altura2": str(alt), "csc2": str(1 / s_teo3)},
                "cos_diedro": str(cos_d), "T5_um_terco": str(T[5]), "csc2_dobra_octaedro": str(1 / s_dobra)}


# ---------------------------------------------------------------- tangentes externas, internas, projeção e hélice

def cert_tangentes(reg, X=(2, 3, 6), T=(F(1), F(3, 2), F(-1, 2))):
    """Cone tangente a 𝒮 a partir de X (|X| = 7): cossecante √14 das tangentes externas com o eixo,
    ponto interno X' = ρX/|X|² (inversão), círculo de contato, projeção ao longo do eixo e seno zero do eixo."""
    O = (0, 0, 0)
    ok = reg.conta(dot(X, X) == 49 and dot(T, T) == RHO, "P11 |X|² = 49 e T ∈ 𝒮")
    ok &= reg.conta(dot(T, sub(X, T)) == 0, "P11 raio ⟂ tangente em T (csc 1)")
    s_ext = spread(sub(O, X), sub(T, X))
    ok &= reg.conta(s_ext == F(1, 14), "P11 tangente externa com o eixo: csc² = 14")
    Xi = scal(RHO / dot(X, X), X)                                  # inversão em 𝒮
    ok &= reg.conta(dot(Xi, Xi) == F(1, 4) and dot(Xi, Xi) * dot(X, X) == RHO ** 2, "P11 |OX'|·|OX| = R²")
    ok &= reg.conta(dot(T, X) == RHO and dot(sub(T, Xi), X) == 0, "P11 T no plano polar por X', ⟂ ao eixo")
    r2_contato = dot(sub(T, Xi), sub(T, Xi))
    ok &= reg.conta(r2_contato == F(13, 4), "P11 raio² do círculo de contato = 13/4")
    # projeção ao longo do eixo: X, X' e O caem no centro; XT vira um raio
    comp_eixo2 = F(dot(sub(T, X), X) ** 2, dot(X, X))               # quadrado da componente axial de XT
    proj2 = dot(sub(T, X), sub(T, X)) - comp_eixo2
    ok &= reg.conta(proj2 == r2_contato and comp_eixo2 == F(169, 4), "P11 projeção de XT = raio; avanço axial 13/2")
    ok &= reg.conta(F(dot(sub(T, X), sub(T, X))) / proj2 == 14, "P11 csc √14 = comprimento/projeção")
    ok &= reg.conta(spread(X, scal(3, X)) == 0, "P11 eixo pelo centro: seno zero")
    # triângulo O, T, X semelhante a 1, √13, √14
    lados = sorted([dot(T, T), dot(sub(X, T), sub(X, T)), F(dot(X, X))])
    ok &= reg.conta([x / lados[0] for x in lados] == [1, 13, 14], "P11 triângulo O,T,X ~ 1, √13, √14")
    # dualidade com o círculo do loop C (eixo a): centro² 13/4, raio² 1/4
    ok &= reg.conta(dot(scal(F(1, 2), A_FACE), scal(F(1, 2), A_FACE)) == F(13, 4), "P11 C: centro² 13/4, raio² 1/4")
    return ok, {"X": list(X), "T": [str(x) for x in T], "X_interno": [str(x) for x in Xi],
                "raio2_contato": str(r2_contato), "lados_OTX": [str(x) for x in lados]}


def cert_helice(N, reg):
    """Yₙ = RⁿP + n·a: projeta-se na órbita do círculo C, sobe 13 por passo no eixo, nunca fecha."""
    M = rodrigues(Q_CSC)
    ok, Pn, prev = True, P, None
    for n in range(0, N + 1):
        if n:
            Pn = tuple(F(x, 182) for x in mat_vec(M, Pn))
        Y = add(Pn, scal(n, A_FACE))
        ok &= reg.conta(dot(Y, A_FACE) == F(13, 2) + 13 * n, f"P12 altura axial n={n}")
        if prev is not None:
            corda = sub(Pn, prev[0])
            ok &= reg.conta(dot(corda, corda) == F(1, 14) and dot(corda, A_FACE) == 0, f"P12 corda² 1/14 n={n}")
            passo = sub(Y, prev[1])
            ok &= reg.conta(dot(passo, passo) == F(183, 14), f"P12 passo² 183/14 n={n}")
        prev = (Pn, Y)
    return ok, {"N": N, "corda2": "1/14", "passo2": "183/14"}



def cert_projecao(reg, s2_tetra=F(49, 8)):
    """O círculo plano como projeção. Referencial próprio de 𝒪7 (Gram ρI, ρ = 7/2); vista ao longo de e₁ (eixo z).
    Quadrância real = ρ·|x|² nesse referencial. Para o tetraedro de aresta 7 usa-se a escala s² = 49/8."""
    e = [(1, 0, 0), (0, 1, 0), (0, 0, 1)]
    octa = [scal(sg, v) for v in e for sg in (1, -1)]
    Tmais = [(1, 1, 1), (1, -1, -1), (-1, 1, -1), (-1, -1, 1)]
    q = lambda x, y: RHO * dot(sub(x, y), sub(x, y))
    proj = lambda x: (x[1], x[2])
    q2 = lambda x, y: RHO * ((x[0] - y[0]) ** 2 + (x[1] - y[1]) ** 2)
    ok = reg.conta(q((1, 0, 0), (-1, 0, 0)) == 14, "P13 altura central do octaedro = √14")
    ok &= reg.conta(all(q(x, y) == 7 for x in octa for y in octa if dot(x, y) == 0), "P13 doze arestas √7")
    meios = {scal(F(1, 2), add(Tmais[i], Tmais[j])) for i in range(4) for j in range(i + 1, 4)}
    ok &= reg.conta(meios == {tuple(F(c) for c in v) for v in octa}, "P13 pontos médios das arestas de T+ = vértices de 𝒪7")
    ok &= reg.conta(all(q(Tmais[i], Tmais[j]) == 28 for i in range(4) for j in range(i + 1, 4)), "P13 T+ regular, aresta √28")
    # vista de cima
    ok &= reg.conta(proj(octa[0]) == (0, 0) and proj(octa[1]) == (0, 0), "P13 os dois vértices do eixo caem no centro")
    insc = [proj(v) for v in octa[2:]]
    ok &= reg.conta(all(RHO * dot(p, p) == RHO for p in insc), "P13 quadrado inscrito no círculo de raio² 7/2")
    ok &= reg.conta(q2((1, 0), (0, 1)) == 7 and q2((1, 0), (-1, 0)) == 14, "P13 inscrito: lado² 7, diagonal² 14")
    circ = [proj(v) for v in Tmais]
    ok &= reg.conta(sorted(circ) == sorted([(1, 1), (-1, -1), (1, -1), (-1, 1)]), "P13 T+ projeta-se no quadrado circunscrito")
    ok &= reg.conta(q2((1, 1), (1, -1)) == 14, "P13 circunscrito: lado² 14 = diâmetro²")
    lados_meio = [(1, 0), (-1, 0), (0, 1), (0, -1)]
    ok &= reg.conta(sorted(lados_meio) == sorted(insc), "P13 inscrito e circunscrito a 45°: vértices = pontos médios dos lados")
    diag = [(Tmais[0], Tmais[1]), (Tmais[2], Tmais[3])]
    profund = [Tmais[0][0], Tmais[1][0], Tmais[2][0], Tmais[3][0]]
    ok &= reg.conta(profund == [1, 1, -1, -1], "P13 as diagonais são arestas opostas em profundidades +R e −R")
    perp = sub(scal(F(1, 2), add(*diag[0])), scal(F(1, 2), add(*diag[1])))
    ok &= reg.conta(RHO * dot(perp, perp) == 14 and all(dot(perp, sub(a_, b_)) == 0 for a_, b_ in diag),
                    "P13 perpendicular comum das diagonais = diâmetro √14 pelo centro")
    # tetraedro regular de aresta 7 na escala s
    edges = [s2_tetra * dot(sub(Tmais[i], Tmais[j]), sub(Tmais[i], Tmais[j])) for i in range(4) for j in range(i + 1, 4)]
    ok &= reg.conta(all(x == 49 for x in edges), "P13 tetraedro de aresta 7")
    ok &= reg.conta(s2_tetra * 4 == F(49, 2) and s2_tetra * 8 == 49 and s2_tetra * 2 == F(49, 4),
                    "P13 aresta 7: vista quadrada de lado² 49/2, diagonal 7, raio 7/2; diagonais separadas por 7/√2")
    # vista pelo eixo vértice→face: triângulo inscrito com o quarto vértice no centro, em profundidade
    apice, base = Tmais[0], Tmais[1:]
    centro_base = scal(F(1, 3), add(add(base[0], base[1]), base[2]))
    alt2 = s2_tetra * dot(sub(apice, centro_base), sub(apice, centro_base))
    raio_tri2 = s2_tetra * dot(sub(base[0], centro_base), sub(base[0], centro_base))
    eixo3 = sub(apice, centro_base)
    ok &= reg.conta(all(dot(sub(b_, centro_base), eixo3) == 0 for b_ in base), "P13 base ⟂ eixo vértice–face")
    ok &= reg.conta(alt2 == F(98, 3) and raio_tri2 == F(49, 3), "P13 aresta 7: altura² 98/3, triângulo de raio² 49/3")
    return ok, {"altura_octaedro2": 14, "aresta_octaedro2": 7, "aresta_Tmais2": 28, "lado_inscrito2": 7,
                "lado_circunscrito2": 14, "perpendicular_comum2": 14, "tetra7": {"lado_vista2": "49/2",
                "diagonal": 7, "raio_circulo": "7/2", "separacao_diagonais2": "49/2"}}


def cert_cruzamento(reg, s2=F(49, 8), V=((1, 1, 1), (-1, -1, 1), (1, -1, -1), (-1, 1, -1))):
    """Como o tetraedro de vértices s·(±1,±1,±1) (sinais com produto 1, eixo de vista z) encontra o plano
    z = 0 do círculo. s² = 7/2: T+ na esfera 𝒮 (aresta √28); s² = 49/8: aresta 7."""
    laterais = [(i, j) for i in range(4) for j in range(i + 1, 4) if V[i][2] != V[j][2]]
    ok = reg.conta(len(laterais) == 4, "P14 quatro arestas laterais")
    r2_meio = s2                                   # quadrância do círculo tangente aos lados (esfera média)
    r2_vert = 2 * s2                               # quadrância do círculo pelos vértices projetados
    pontos = []
    for i, j in laterais:
        A, B = V[i], V[j]
        t = F(A[2], A[2] - B[2])                   # parâmetro em que z = 0
        X = tuple(a_ + t * (b_ - a_) for a_, b_ in zip(A, B))
        d = sub(B, A)
        raio, tang, eixo = (X[0], X[1], 0), (-X[1], X[0], 0), (0, 0, 1)
        pontos.append(X)
        ok &= reg.conta(t == F(1, 2) and X[2] == 0, "P14 cruza z = 0 no ponto médio")
        ok &= reg.conta(s2 * (X[0] ** 2 + X[1] ** 2) == r2_meio, "P14 o ponto de cruzamento está no perímetro do círculo")
        ok &= reg.conta(spread(d, raio) == 1, "P14 aresta ⟂ raio no cruzamento")
        ok &= reg.conta(spread(d, tang) == F(1, 2) and spread(d, eixo) == F(1, 2), "P14 45° com a tangente e com o eixo z")
        # a reta da aresta fica fora da bola de raio² r2_meio, tocando-a só em X (tangente à esfera média)
        Pm = tuple(F(x) for x in X)
        ok &= reg.conta(dot(Pm, d) == 0, "P14 o ponto médio é o pé da perpendicular do centro à aresta")
    ok &= reg.conta(sorted(pontos) == sorted([(1, 0, 0), (-1, 0, 0), (0, 1, 0), (0, -1, 0)]), "P14 os cruzamentos são os vértices do quadrado inscrito")
    # círculo pelos vértices projetados: o tetraedro não o toca; seção z = 0 tem raio² máximo s² < 2s²
    ok &= reg.conta(r2_meio < r2_vert and all(s2 * (v[0] ** 2 + v[1] ** 2) == r2_vert and v[2] != 0 for v in V),
                    "P14 vértices no cilindro sobre o círculo maior, fora do plano")
    return ok, {"s2": str(s2), "raio2_circulo_tangente": str(r2_meio), "raio2_circulo_pelos_vertices": str(r2_vert),
                "spread_com_raio": "1", "spread_com_tangente": "1/2", "spread_com_eixo_z": "1/2"}

# ---------------------------------------------------------------- critério e auditoria

ORDEM_POR_2COS = {2: 1, 1: 6, 0: 4, -1: 3, -2: 2}


def ordem_prevista(tr):
    duas_cos = tr - 1
    if duas_cos.denominator == 1 and -2 <= duas_cos <= 2:
        return ORDEM_POR_2COS[int(duas_cos)]
    return None


def ordem_direta(M, s, kmax):
    Mk, sk = ident(1), 1
    for k in range(1, kmax + 1):
        Mk, sk = mat_mul(Mk, M), sk * s
        if Mk == ident(sk):
            return k
    return None


def T_doc(p, q):
    """T_{p,q} da seção 15.4: numerador inteiro e denominador q² + 14p²."""
    d = D_DIAG
    K = ((0, -d[2], d[1]), (d[2], 0, -d[0]), (-d[1], d[0], 0))
    num = mat_add(mat_add(ident(q * q - 14 * p * p), mat_scale(2 * p * q, K)), mat_scale(2 * p * p, outer(d, d)))
    return num, q * q + 14 * p * p


# aritmética em Q(√2): par (r, s) = r + s√2
def r2_mul(x, y):
    return (x[0] * y[0] + 2 * x[1] * y[1], x[0] * y[1] + x[1] * y[0])


def r2_add(x, y):
    return (x[0] + y[0], x[1] + y[1])


def r2_mat_mul(A, B):
    out = []
    for i in range(3):
        row = []
        for j in range(3):
            acc = (F(0), F(0))
            for k in range(3):
                acc = r2_add(acc, r2_mul(A[i][k], B[k][j]))
            row.append(acc)
        out.append(tuple(row))
    return tuple(out)


def auditoria(reg, kmax=60):
    linhas = []
    casos = [("T_-1_3", "T₋₁,₃ (seção 15.4)", *T_doc(-1, 3)),
             ("T_1_1", "T₁,₁ (seção 15.4)", *T_doc(1, 1)),
             ("M3", "M3/3, primeiro cubo pitagórico (25.2)", rodrigues((1, 1, 1, 0)), 3),
             ("M7", "M7/7, meia-volta da diagonal (25.6)", mat_add(outer(D_DIAG, D_DIAG), ident(-7)), 7),
             ("Rq", "R_q, cossecante √14", rodrigues(Q_CSC), quat_norm2(Q_CSC)),
             ("Rb", "R_b, quatérnio da caixa 1 + 2j + 3k", rodrigues(B_CAIXA), quat_norm2(B_CAIXA))]
    for ident_curto, nome, M, s in casos:
        ok_rot = reg.conta(mat_mul(transpose(M), M) == ident(s * s) and det3(M) == s ** 3, f"P8 rotação {nome}")
        tr = F(trace(M), s)
        prev = ordem_prevista(tr)
        direta = ordem_direta(M, s, kmax)
        reg.conta(ok_rot and prev == direta, f"P8 critério {nome}")
        linhas.append({"id": ident_curto, "rotacao": nome, "traco": str(tr), "dois_cos": str(tr - 1),
                       "ordem_prevista": prev, "ordem_direta_ate_60": direta})
    # Espiral de Cotα (7.5): entradas em Q(√2)
    h = (F(0), F(1, 2))
    z, um, menos_h = (F(0), F(0)), (F(1), F(0)), (F(0), F(-1, 2))
    M = ((h, z, h), (h, z, menos_h), (z, um, z))
    Mt = tuple(tuple(M[j][i] for j in range(3)) for i in range(3))
    I2 = tuple(tuple(um if i == j else z for j in range(3)) for i in range(3))
    reg.conta(r2_mat_mul(Mt, M) == I2, "P8 Cotα ortogonal")
    tr = r2_add(r2_add(M[0][0], M[1][1]), M[2][2])
    dois_cos = (tr[0] - 1, tr[1])                               # r + s√2
    # polinômio mínimo de r + s√2 (s ≠ 0): X² − 2rX + (r² − 2s²)
    coef = (-2 * dois_cos[0], dois_cos[0] ** 2 - 2 * dois_cos[1] ** 2)
    inteiro_algebrico = dois_cos[1] == 0 or all(c.denominator == 1 for c in coef)
    Mk, fecha = I2, None
    for k in range(1, kmax + 1):
        Mk = r2_mat_mul(Mk, M)
        if Mk == I2:
            fecha = k
            break
    reg.conta(not inteiro_algebrico and fecha is None, "P8 critério Cotα")
    linhas.append({"id": "Cota", "rotacao": "Cotα, rotação fixa M (7.5)", "traco": "√2/2",
                   "dois_cos": "−1 + √2/2", "polinomio_minimo_de_2cos": f"X² + {coef[0]}X + {coef[1]}",
                   "ordem_prevista": None, "ordem_direta_ate_60": fecha})
    ok = all(l["ordem_prevista"] == l["ordem_direta_ate_60"] for l in linhas)
    return ok, linhas


# ---------------------------------------------------------------- ilustração numérica (fora dos certificados)

def ilustracao(N):
    c = F(6, 7)
    T, U = cheb_T(c, N), cheb_U(c, N)
    angulos = [0.0]
    quase = []
    melhor = None
    for n in range(1, N + 1):
        cosn = float(T[n])
        senn = math.sqrt(13) / 7 * float(U[n - 1])          # sen nφ = sen φ · Uₙ₋₁(cos φ), sen φ = √13/7
        ang = math.atan2(senn, cosn) % (2 * math.pi)
        angulos.append(ang)
        dist = min(ang, 2 * math.pi - ang)
        if melhor is None or dist < melhor:
            melhor = dist
            quase.append({"n": n, "falta_graus": round(math.degrees(dist), 6),
                          "um_menos_cos_exato_positivo": (1 - T[n]) > 0})
    lacunas = {}
    for m in (12, 100, 1000, N):
        if m <= N:
            a = sorted(angulos[:m + 1])
            gaps = [a[i + 1] - a[i] for i in range(len(a) - 1)] + [2 * math.pi - a[-1] + a[0]]
            lacunas[m] = round(math.degrees(max(gaps)), 6)
    return {"angulo_por_passo_graus": round(math.degrees(2 * math.asin(1 / math.sqrt(14))), 9),
            "aproximacoes_recorde_do_fechamento": quase, "maior_arco_vazio_graus": lacunas}


# ---------------------------------------------------------------- sabotagens

def sabotagens(N_curto=40):
    """Cada sabotagem introduz um erro de propósito; acusada = o certificado correspondente falha."""
    M = rodrigues(Q_CSC)
    s = quat_norm2(Q_CSC)
    lista = []

    def roda(nome, f):
        lixo = Registro()
        try:
            ok = f(lixo)
        except Exception as e:                                 # erro também é acusação
            ok = False
            nome += f" [exceção: {type(e).__name__}]"
        lista.append({"sabotagem": nome, "acusada": not ok})

    roda("S1 quatérnio 12 + 2j + 3k no lugar de 13 + 2j + 3k",
         lambda r: cert_quaternio((12, 0, 2, 3), A_FACE, r)[0])
    roda("S2 vetor do quatérnio na diagonal (1,2,3) e não na face (0,2,3)",
         lambda r: cert_quaternio((13, 1, 2, 3), A_FACE, r)[0])
    Msab = tuple(tuple(-x if (i, j) == (0, 1) else x for j, x in enumerate(row)) for i, row in enumerate(M))
    roda("S3 sinal trocado numa entrada da matriz", lambda r: cert_rotacao(Msab, s, A_FACE, r)[0])
    roda("S4 passo de Teodoro 3 → 4 (csc 2) no lugar de 13 → 14",
         lambda r: cert_laco_aberto(rodrigues((3, 1, 1, 1)), 12, F(1, 2), N_curto, r)[0])
    roda("S5 passo de Teodoro 1 → 2 (csc √2) no lugar de 13 → 14",
         lambda r: cert_laco_aberto(rodrigues((1, 1, 0, 0)), 2, F(0), N_curto, r)[0])
    roda("S6 parceiro errado 2 + 2j + 3k na meia-volta",
         lambda r: cert_meia_volta(Q_CSC, (2, 0, 2, 3), A_FACE, A_FACE, P, PL, r)[0])
    roda("S7 ponte pelo eixo P − P' no lugar de P + P'",
         lambda r: cert_meia_volta(Q_CSC, B_CAIXA, sub(P, PL), A_FACE, P, PL, r)[0])
    roda("S8 cossecante √14 atribuída ao seno zero", lambda r: cert_seno_zero(r, csc2_alegado=14))
    roda("S9 denominadores 2·7ⁿ⁻¹ no lugar de 2·7ⁿ",
         lambda r: cert_orbita(rodrigues(Q_CSC), s, P, PL, A_FACE, 5, r, den_esperado=lambda n: 2 * 7 ** (n - 1))[0])

    def fecha_em_12(r):
        M12 = ident(1)
        for _ in range(12):
            M12 = mat_mul(M12, M)
        return r.conta(M12 == ident(s ** 12), "fecha em 12 passos")
    roda("S10 alegação de que o loop fecha em 12 passos", fecha_em_12)
    roda("S11 diedro do tetraedro com cos 1/2 no lugar de 1/3",
         lambda r: cert_tetraedro(10, r, cos_diedro_alegado=F(1, 2))[0])
    roda("S12 alegação de que cinco tetraedros em torno da aresta fecham",
         lambda r: cert_tetraedro(10, r, fecha_em_5=True)[0])
    roda("S13 ponto externo (2,3,5) no lugar de (2,3,6)",
         lambda r: cert_tangentes(r, X=(2, 3, 5))[0])
    roda("S15 tetraedro de aresta 7 com escala s² = 49/4",
         lambda r: cert_projecao(r, s2_tetra=F(49, 4))[0])
    roda("S16 tetraedro com um vértice deslocado (1,1,1) → (1,1,0)",
         lambda r: cert_cruzamento(r, F(49, 8), V=((1, 1, 0), (-1, -1, 1), (1, -1, -1), (-1, 1, -1)))[0])
    roda("S14 ponto de contato (1/2, 1, 3/2) que não está no cone",
         lambda r: cert_tangentes(r, T=P)[0])
    return lista


# ---------------------------------------------------------------- principal

def main():
    N = int(sys.argv[1]) if len(sys.argv) > 1 else 2000
    t0 = time.time()
    res = {}

    ok1, info1 = cert_triangulo(P, PL, REG)
    res["P1_triangulo"] = {"ok": ok1, **info1}

    ok2a, info2a = cert_quaternio(Q_CSC, A_FACE, REG)
    M = rodrigues(Q_CSC)
    s = quat_norm2(Q_CSC)
    ok2b, info2b = cert_rotacao(M, s, A_FACE, REG)
    Mred = mat_scale(F(1, 2), M)                       # R(q)/182 = M'/91
    Mred = tuple(tuple(int(x) for x in row) for row in Mred)
    ok2c = REG.conta(all(2 * x == y for r1, r2 in zip(Mred, M) for x, y in zip(r1, r2)), "P2 M' inteira")
    ok2d = REG.conta(F(info2b["cos"]) == F(6, 7) and F(info2b["traco"]) == F(19, 7), "P2 cos 2θ = 6/7")
    res["P2_rotacao"] = {"ok": ok2a and ok2b and ok2c and ok2d, **info2a, **info2b,
                         "M_linha_sobre_91": [list(r) for r in Mred]}

    ok3, info3 = cert_laco_aberto(Mred, 91, F(6, 7), N, REG, sete_adico=True)
    res["P3_laco_aberto"] = {"ok": ok3, **info3}

    ok4, info4 = cert_orbita(Mred, 91, P, PL, A_FACE, N, REG)
    res["P4_orbita"] = {"ok": ok4, **info4}

    ok5, info5 = cert_meia_volta(Q_CSC, B_CAIXA, add(P, PL), A_FACE, P, PL, REG)
    res["P5_meia_volta"] = {"ok": ok5, **info5}

    teo = fechamento_teodoro(2000, 60)
    ok6 = REG.conta(teo == {1: 4, 3: 6}, "P6 classificação de Teodoro")
    res["P6_teodoro"] = {"ok": ok6, "fecham": {str(k): v for k, v in teo.items()}, "n_ate": 2000, "k_ate": 60}

    ok7 = cert_seno_zero(REG)
    res["P7_seno_zero"] = {"ok": ok7}

    ok8, linhas = auditoria(REG)
    res["P8_auditoria"] = {"ok": ok8, "linhas": linhas}

    ok10, info10 = cert_tetraedro(N, REG)
    res["P10_teodoro_tetraedro"] = {"ok": ok10, **info10}

    ok11, info11 = cert_tangentes(REG)
    res["P11_tangentes"] = {"ok": ok11, **info11}
    ok12, info12 = cert_helice(min(N, 300), REG)
    res["P12_helice"] = {"ok": ok12, **info12}
    ok13, info13 = cert_projecao(REG)
    res["P13_projecao"] = {"ok": ok13, **info13}
    ok14a, info14a = cert_cruzamento(REG, F(7, 2))
    ok14b, info14b = cert_cruzamento(REG, F(49, 8))
    res["P14_cruzamento"] = {"ok": ok14a and ok14b, "T_mais_em_S": info14a, "aresta_7": info14b}

    sab = sabotagens()
    ok9 = all(x["acusada"] for x in sab)
    REG.conta(ok9, "P9 sabotagens")
    res["P9_sabotagens"] = {"ok": ok9, "acusadas": sum(x["acusada"] for x in sab), "total": len(sab), "lista": sab}

    res["ilustracao_numerica"] = ilustracao(N)

    # chaves comuns com a implementação B (comparadas por compara.py)
    C = [F(7) ** n * t for n, t in enumerate(cheb_T(F(6, 7), 20))]
    Dk = [F(7) ** k * u for k, u in enumerate(cheb_U(F(6, 7), 19))]
    W, Wn = (1, 2, 3), {}
    for n in range(1, 10):
        W = mat_vec(Mred, W)
        Wn[str(n)] = list(W)
    res["chaves_comuns"] = {
        "M_linha": [list(r) for r in Mred],
        "traco_M_linha": trace(Mred),
        "cos2theta": [6, 7],
        "C": [int(x) for x in C[1:]],
        "D": [int(x) for x in Dk],
        "W": Wn,
        "q_vezes_b": list(quat_mul(Q_CSC, B_CAIXA)),
        "treze_H": [list(r) for r in mat_add(mat_scale(2, outer(A_FACE, A_FACE)), ident(-13))],
        "teodoro_fecham": {str(k): v for k, v in teo.items()},
        "auditoria_ordens": {l["id"]: l["ordem_prevista"] for l in linhas if l["id"] != "Cota"},
    }

    tudo = all(res[k]["ok"] for k in res if k.startswith("P")) and not REG.falhas
    res["resumo"] = {"tudo_confere": tudo, "verificacoes": REG.verificacoes, "falhas": REG.falhas[:20],
                     "N": N, "tempo_s": round(time.time() - t0, 2)}

    with open("resultados_loop_csc14_A.json", "w", encoding="utf-8") as fh:
        json.dump(res, fh, ensure_ascii=False, indent=1)

    print(f"Implementação A — N = {N}")
    for k in sorted(x for x in res if x.startswith("P")):
        print(f"  {k:<18} {'confere' if res[k]['ok'] else 'FALHA'}")
    il = res["ilustracao_numerica"]
    print(f"  passo: 2θ = {il['angulo_por_passo_graus']}°; maior arco vazio: {il['maior_arco_vazio_graus']}")
    print(f"  sabotagens acusadas: {res['P9_sabotagens']['acusadas']}/{res['P9_sabotagens']['total']}")
    print(f"  verificações exatas: {REG.verificacoes}, falhas: {len(REG.falhas)}, tempo: {res['resumo']['tempo_s']} s")
    print("TUDO CONFERE" if tudo else "HÁ FALHAS")
    return 0 if tudo else 1


if __name__ == "__main__":
    sys.exit(main())
