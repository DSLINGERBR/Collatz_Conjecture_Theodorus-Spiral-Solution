<p align="center"><i>Jesus Cristo é O SENHOR.</i><br>
<i>A pedra que os construtores rejeitaram tornou-se a pedra fundamental.</i></p>

<h1 align="center">Proposta de solução da Conjectura de Collatz pela via dos quadrados perfeitos e a matemática da exatidão</h1>

<p align="center">Davi Cançado Dutra Cota — Brasil — 21 de outubro de 2026</p>

## Artigo principal

| Arquivo | Conteúdo | Páginas |
|---|---|---|
| `artigo_collatz.pdf` | **Proposta de solução da Conjectura de Collatz pela via dos quadrados perfeitos e a matemática da exatidão.** O círculo plano é uma projeção: o tetraedro, o octaedro e a cossecante √14 como saída pelo centro, e a espiral de Teodoro de lado 1 | 32 |
| `article_collatz.pdf` | Versão em inglês: *Proposed solution of the Collatz Conjecture through perfect squares and the mathematics of exactness* | 32 |

O artigo reúne numa só construção o arcabouço teórico e a sua aplicação ao problema 3n+1. A seção 3 mostra a construção da demonstração passo a passo. As seções 4 a 8 demonstram que o círculo plano é uma projeção: a caixa 1×2×3 e a esfera de diâmetro √14; o tetraedro regular, cuja sombra é o quadrado com as duas diagonais, e o octaedro dos pontos médios; o octaedro de altura √14, o cubo e o tetraedro na esfera; o giro da cossecante √14, que não fecha; e a saída pelo centro. As seções 9 e 10 tratam da espiral de Teodoro de lado 1; as seções 11 a 14, do problema 3n+1; a seção 13 traz a proposta de solução do autor, e a seção 17, os seus princípios e argumentos.

## Artigos complementares

| Arquivo | Conteúdo | Páginas |
|---|---|---|
| `artigo_pt.pdf` | O círculo plano é uma projeção: o loop da cossecante √14, o octaedro de altura √14 e o tetraedro regular | 16 |
| `article_en.pdf` | Versão em inglês do artigo anterior | 16 |
| `artigo_tetraedro.pdf` | O tetraedro regular e o círculo: o quadrado com as duas diagonais é a projeção de um sólido | 9 |

O conteúdo dos artigos complementares está integrado ao artigo principal. Os arquivos `.tex` ao lado de cada PDF são a fonte. As figuras estão em `fig/` (PDF) e `fig_png/` (PNG, 200 dpi).

## Versões editáveis

`editaveis/<artigo>/` tem, para cada artigo, o `.md` e o `.docx` (página A4, equações editáveis do Word, figuras na largura do texto, título e epígrafe centralizados). Os cinco `.docx` passam na validação de esquema do formato Office. Para gerar de novo a partir do LaTeX: `cd editaveis && OOXML_XSD=<pasta dos esquemas> bash gerar_editaveis.sh`, com os esquemas XSD do ISO/IEC 29500-4 (ECMA-376, parte 4).

## Suíte interativa

`suite3d/tetraedro_circulo_3d.html` — um único arquivo, abre no navegador sem internet. Mostra o tetraedro, o octaedro, o círculo e a esfera de diâmetro √14 em qualquer ângulo e recalcula os certificados com inteiros exatos.

## Programas e conferências (todos com inteiros e frações exatas)

| Programa | O que confere | Resultado nesta versão |
|---|---|---|
| `collatz/confere_teodoro_collatz.py portas_1e9.json` | certificados T1 a T10 (Tabela 5 do artigo principal), com as coordenadas exatas da espiral até v₂₅, e sete sabotagens | tudo confere; 7/7 sabotagens recusadas (1 min 28 s) |
| `collatz/porta_quadrado.c` (`gcc -O2 -o porta_quadrado porta_quadrado.c && ./porta_quadrado 1000000000`) | porta de todo n ≤ 10⁹ | todas as portas são 4^k com k ≥ 2; portas raras 26, 20, 14, 8, 2 = previsão; 0 falhas, 0 estouros (28 s) |
| `collatz/porta_quadrado_independente.py 1000000` | mesma contagem por trajetórias completas | igual ao programa em C até 10⁶ |
| `collatz/collatz_exato.c` (`./collatz_exato 10000000000`) | todo n ≤ 10¹⁰ chega a 1 | nenhum sai do loop; 0 estouros (2 min 44 s) |
| `loop_csc14.py` | arcabouço: projeções, tetraedro, octaedro, loop da cossecante √14, tangentes e hélice | 25 035 verificações exatas, 16/16 sabotagens acusadas |
| `confere_loop_csc14.c` + `compara.py` | implementação independente em C | 35 verificações, 10/10 sabotagens; A e B concordam |
| `deriva_float.py` | erro do ponto flutuante na mesma rotação | exato: 0 em todos os passos; double: cresce até 2,4·10⁻¹⁰ em 10⁶ passos |
| `figuras.py`, `figuras_tetra.py`, `figuras_teodoro.py` | figuras (ponto flutuante só para desenhar) | — |

Os resultados ficam em `resultados_loop_csc14_A.json`, `resultados_loop_csc14_B.json`, `deriva_float.json`, `collatz/resultados_teodoro_collatz.json`, `collatz/portas_1e9.json` e `collatz/resultado_ate_1e10.txt`.

## O que está demonstrado e o que foi testado

Demonstrado, com prova completa, no artigo principal: o tetraedro regular de aresta 7 visto de cima é o quadrado com as duas diagonais; as diagonais são arestas que não se cortam, o centro é um segmento do eixo z, as arestas laterais atravessam o perímetro do círculo perpendiculares ao raio e a 45° do plano, e os pontos médios das arestas formam um octaedro regular (seção 5); na esfera de diâmetro √14, o círculo com os quadrados inscrito e circunscrito e as diagonais é a sombra do octaedro de altura √14, do cubo e do tetraedro (seção 6); o giro da cossecante √14 nunca fecha, com denominador exato 2·7ⁿ, e fecha pela meia-volta que passa pelo centro; as tangentes externas e a inversão (seções 7 e 8); a espiral de Teodoro pela quadrância (lado sempre 1, quadrância N, tangentes, spreads 1/(N+1)), a planificação das diagonais dos cubos, a progressão de quadrados inscritos e circunscritos que começa no ponto inicial (observação do autor, Teorema 25), a rampa de 45° no paraboloide e o afastamento π entre as voltas (seções 9 e 10); o teorema da porta (toda trajetória que chega a 1, partindo de um número que não é potência de 2, entra na descida final pelo quadrado perfeito 4^k = (2^k)², vinda de (4^k − 1)/3), a contagem exata das portas raras e a reformulação equivalente da conjectura na linguagem de Teodoro (seções 11 e 12); as portas e os ciclos dos mapas vizinhos 3n − 1 e 5n + 1 (seção 14).

Testado com inteiros exatos: as identidades do arcabouço, com sabotagens; as coordenadas da espiral até v₂₅; as portas de todo n ≤ 10⁹; as trajetórias de todo n ≤ 10¹⁰, todas chegando a 1.

A proposta de solução do autor está na seção 13 do artigo principal, e os seus princípios e argumentos, na seção 17.

## Requisitos

Python 3 (só biblioteca padrão para as conferências; matplotlib para as figuras), gcc, xelatex (para recompilar os PDFs), pandoc 3, lxml e os esquemas XSD do ISO/IEC 29500-4 (para as versões editáveis).

## Licença

O conteúdo deste repositório é regido pela licença de verificação do arquivo `LICENSE`: é permitido ler, baixar e executar o material para verificar, reproduzir ou avaliar os resultados dos artigos; os demais materiais didáticos do autor sobre a via matemática dos quadrados perfeitos podem ser lidos e baixados para estudo e conhecimento, sem fins lucrativos; outros usos dependem de autorização prévia e por escrito do autor.

## English

The main article is `article_collatz.pdf`, *Proposed solution of the Collatz Conjecture through perfect squares and the mathematics of exactness* (Portuguese original: `artigo_collatz.pdf`). Section 3 shows the construction of the proof step by step; Sections 4 to 8 prove that the plane circle is a projection (the tetrahedron, the octahedron and the cosecant √14 as the exit through the centre); Sections 9 to 14 cover the spiral of Theodorus and the 3n+1 problem; Section 13 states the author's proposed solution. The verification programs, their results and the interactive suite are listed above. Use is governed by the verification license in `LICENSE`; the author's teaching materials on the route of perfect squares may be read for study, not used for profit.

<p align="center"><i>Jesus Cristo é O SENHOR.</i><br>
<i>A pedra que os construtores rejeitaram tornou-se a pedra fundamental.</i></p>
