#!/usr/bin/env python3
"""Erro sistemático da rotação em ponto flutuante (IEEE 754, double) contra a rotação exata.

Mesma rotação da cossecante √14 (ângulo 2θ em torno de a = (0,2,3)), aplicada n vezes ao vértice P.
Exato: a quadrância |X|² − 7/2 e a altura X·a − 13/2 são zero em todo passo (certificado em loop_csc14.py).
Mede-se a deriva das duas formas em ponto flutuante: (i) matriz racional M'/91 convertida em double;
(ii) matriz montada com seno e cosseno de 2·asen(1/√14), como no cálculo usual com o círculo.
Uso: python3 deriva_float.py [n]   (padrão 1 000 000)
"""
import json, math, sys
n_max = int(sys.argv[1]) if len(sys.argv) > 1 else 1_000_000
M1 = [[78/91, -39/91, 26/91], [39/91, 82/91, 6/91], [-26/91, 6/91, 87/91]]
phi = 2 * math.asin(1 / math.sqrt(14))
c, s = math.cos(phi), math.sin(phi)
u = (0.0, 2 / math.sqrt(13), 3 / math.sqrt(13))
K = [[0, -u[2], u[1]], [u[2], 0, -u[0]], [-u[1], u[0], 0]]
M2 = [[c * (i == j) + (1 - c) * u[i] * u[j] + s * K[i][j] for j in range(3)] for i in range(3)]

def roda(M):
    x = [0.5, 1.0, 1.5]
    pior_esf = pior_alt = 0.0
    marcos = {}
    for n in range(1, n_max + 1):
        x = [M[0][0]*x[0]+M[0][1]*x[1]+M[0][2]*x[2], M[1][0]*x[0]+M[1][1]*x[1]+M[1][2]*x[2],
             M[2][0]*x[0]+M[2][1]*x[1]+M[2][2]*x[2]]
        e = abs(x[0]*x[0]+x[1]*x[1]+x[2]*x[2] - 3.5)
        h = abs(2*x[1]+3*x[2] - 6.5)
        pior_esf, pior_alt = max(pior_esf, e), max(pior_alt, h)
        if n in (10, 1000, 100000, 1000000) or n == n_max:
            marcos[n] = {"desvio_esfera": e, "desvio_plano": h}
    return {"pior_desvio_esfera": pior_esf, "pior_desvio_plano": pior_alt, "marcos": marcos}

res = {"n": n_max, "matriz_racional_em_double": roda(M1), "matriz_por_seno_cosseno": roda(M2),
       "exato": "desvio 0 em todo passo (frações exatas)"}
json.dump(res, open("deriva_float.json", "w"), indent=1)
print(json.dumps(res, indent=1))
