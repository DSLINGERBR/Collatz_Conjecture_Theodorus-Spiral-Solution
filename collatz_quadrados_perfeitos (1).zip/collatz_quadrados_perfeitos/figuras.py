#!/usr/bin/env python3
"""Figuras do artigo. Os desenhos usam ponto flutuante; os valores exatos estão nos certificados."""
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.art3d import Poly3DCollection

plt.rcParams.update({"font.family": "DejaVu Serif", "font.size": 9, "axes.linewidth": 0.6,
                     "savefig.bbox": "tight", "savefig.pad_inches": 0.04})
import sys
LANG = sys.argv[1] if len(sys.argv) > 1 else "pt"


def L(pt, en):
    return en if LANG == "en" else pt


def arquivo(base):
    return f"{base}_{LANG}.pdf"


AZUL, VERM, VERDE, OURO, CINZA, ROXO = "#1f4e9c", "#b22222", "#2e7d32", "#c08a00", "#888888", "#6a3d9a"

RHO = 3.5
R = np.sqrt(RHO)
P = np.array([0.5, 1.0, 1.5])
PL = np.array([-0.5, 1.0, 1.5])
A = np.array([0.0, 2.0, 3.0])
AH = A / np.linalg.norm(A)
C0 = A / 2
E1 = np.array([1.0, 0.0, 0.0])
E2 = np.array([0.0, 3.0, -2.0]) / np.sqrt(13)
MR = np.array([[78, -39, 26], [39, 82, 6], [-26, 6, 87]]) / 91.0
THETA = np.arcsin(1 / np.sqrt(14))
PHI = 2 * THETA


def esfera(ax, r=R, cor=CINZA, alpha=0.25):
    u = np.linspace(0, 2 * np.pi, 37)
    for lat in np.linspace(-np.pi / 2, np.pi / 2, 9)[1:-1]:
        ax.plot(r * np.cos(lat) * np.cos(u), r * np.cos(lat) * np.sin(u), r * np.sin(lat) * np.ones_like(u),
                color=cor, lw=0.35, alpha=alpha)
    for lon in np.linspace(0, np.pi, 7)[:-1]:
        ax.plot(r * np.cos(u) * np.cos(lon), r * np.cos(u) * np.sin(lon), r * np.sin(u), color=cor, lw=0.35, alpha=alpha)


def caixa(ax):
    s = np.array([0.5, 1.0, 1.5])
    V = np.array([[i, j, k] for i in (-1, 1) for j in (-1, 1) for k in (-1, 1)]) * s
    for i in range(8):
        for j in range(i + 1, 8):
            if np.sum(np.abs(V[i] - V[j]) > 1e-9) == 1:
                ax.plot(*zip(V[i], V[j]), color="#555555", lw=0.7)


def fixa3d(ax, lim, elev=18, azim=-58):
    ax.set_xlim(-lim, lim); ax.set_ylim(-lim, lim); ax.set_zlim(-lim, lim)
    ax.set_box_aspect((1, 1, 1))
    ax.view_init(elev=elev, azim=azim)
    ax.set_xlabel("x", labelpad=-8); ax.set_ylabel("y", labelpad=-8); ax.set_zlabel("z", labelpad=-8)
    ax.tick_params(labelsize=6, pad=-2)


def orbita(n):
    pts, x = [P.copy()], P.copy()
    for _ in range(n):
        x = MR @ x
        pts.append(x)
    return np.array(pts)


def plano(X):
    """Coordenadas no plano do círculo C (perpendicular ao eixo a), centradas em a/2."""
    d = X - C0
    return np.array([d @ E1, d @ E2])


# ------------------------------------------------------------- Figura 1: a caixa, o triângulo e o laço em 3D
def fig1():
    fig = plt.figure(figsize=(7.4, 5.0))
    ax = fig.add_subplot(111, projection="3d")
    esfera(ax); caixa(ax)
    tri = np.array([-P, PL, P])
    ax.add_collection3d(Poly3DCollection([tri], facecolor=OURO, alpha=0.25, edgecolor=OURO, lw=1.2))
    t = np.linspace(-1.25, 1.25, 2)
    ax.plot(*(np.outer(t, A / np.linalg.norm(A) * R)).T, color=VERDE, lw=1.4, ls="--")
    ax.plot(*zip(-P, P), color=VERM, lw=1.6)
    u = np.linspace(0, 2 * np.pi, 200)
    circ = C0 + 0.5 * (np.outer(np.cos(u), E1) + np.outer(np.sin(u), E2))
    ax.plot(*circ.T, color=AZUL, lw=1.4)
    pts = orbita(24)
    ax.scatter(*pts.T, s=9, color=AZUL, depthshade=False, zorder=5)
    for i in (0, 1, 2, 3):
        ax.text(*(pts[i] + np.array([0.05, 0.05, 0.12])), f"$P_{i}$", fontsize=7, color=AZUL)
    ax.text(*(PL + [-0.35, 0, 0.12]), "$P'$", fontsize=8)
    ax.text(*(-P + [0.05, 0, -0.35]), "$-P$", fontsize=8)
    ax.text(*(0.62 * R * AH + [0.0, 0.05, 0.2]), L("eixo $a=(0,2,3)$", "axis $a=(0,2,3)$"), fontsize=7, color=VERDE)
    ax.text(0.15, -0.2, -0.2, r"$\sqrt{14}$", color=VERM, fontsize=8)
    fixa3d(ax, 2.0, elev=14, azim=-35)
    ax2 = fig.add_axes([0.70, 0.50, 0.34, 0.46], projection="3d")
    ax2.plot(*circ.T, color=AZUL, lw=1.2)
    p12 = orbita(12)
    ax2.plot(*p12.T, color=AZUL, lw=0.7, marker="o", ms=2.5)
    ax2.plot(*zip(P, PL), color=OURO, lw=1.4)
    ax2.plot(*zip(C0 - 0.35 * AH, C0 + 0.35 * AH), color=VERDE, lw=1.0, ls="--")
    for i in (0, 1, 2, 12):
        ax2.text(*(p12[i] + np.array([0.04, 0.0, 0.06])), str(i), fontsize=6.5, color=AZUL)
    ax2.text(*(PL + [-0.12, 0, 0.06]), "$P'$", fontsize=7)
    ax2.set_xlim(C0[0] - .55, C0[0] + .55); ax2.set_ylim(C0[1] - .55, C0[1] + .55); ax2.set_zlim(C0[2] - .55, C0[2] + .55)
    ax2.set_box_aspect((1, 1, 1)); ax2.view_init(elev=48, azim=70)
    ax2.set_xticks([]); ax2.set_yticks([]); ax2.set_zticks([])
    ax2.set_title(L("zoom: círculo $C$, diâmetro $PP'=1$", "zoom: circle $C$, diameter $PP'=1$"), fontsize=7)
    fig.savefig(arquivo("fig1_caixa_loop_3d")); plt.close(fig)


# ------------------------------------------------------------- Figura 2: o laço no plano do círculo
def fig2():
    fig, axs = plt.subplots(1, 3, figsize=(7.2, 2.6))
    u = np.linspace(0, 2 * np.pi, 300)
    for ax in axs:
        ax.plot(0.5 * np.cos(u), 0.5 * np.sin(u), color=CINZA, lw=0.8)
        ax.set_aspect("equal"); ax.axis("off")
        ax.plot([-0.5, 0.5], [0, 0], color=OURO, lw=0.8)
        ax.plot(0, 0, "k.", ms=3)
    q = np.array([plano(x) for x in orbita(12)])
    axs[0].plot(q[:, 0], q[:, 1], color=AZUL, lw=0.9, marker="o", ms=2.5)
    for i in (0, 1, 2, 11, 12):
        off = 1.17
        axs[0].text(off * q[i, 0], off * q[i, 1], str(i), fontsize=7, ha="center", va="center", color=AZUL)
    axs[0].set_title(L("12 passos de $2\\theta$: não fecha\n(faltam $12{,}03^\\circ$)", "12 steps of $2\\theta$: does not close\n($12.03^\\circ$ missing)"), fontsize=8)
    q = np.array([plano(x) for x in orbita(2000)])
    axs[1].scatter(q[:, 0], q[:, 1], s=0.6, color=AZUL)
    axs[1].set_title(L("2000 passos: pontos distintos\nque enchem o círculo", "2000 steps: distinct points\nfilling the circle"), fontsize=8)
    ax = axs[2]
    a1 = np.linspace(0, PHI, 40); a2 = np.linspace(PHI, np.pi, 80)
    ax.plot(0.5 * np.cos(a1), 0.5 * np.sin(a1), color=AZUL, lw=2.2)
    ax.plot(0.5 * np.cos(a2), 0.5 * np.sin(a2), color=VERM, lw=2.2)
    ax.annotate("", xy=(-0.5, 0), xytext=(0.5, 0), arrowprops=dict(arrowstyle="->", color="k", lw=0.8))
    ax.text(0.53, 0.0, "$P$", fontsize=8, va="center"); ax.text(-0.66, 0.0, "$P'$", fontsize=8, va="center")
    ax.text(0.47, 0.22, "$2\\theta$", color=AZUL, fontsize=8)
    ax.text(-0.42, 0.40, "$\\pi-2\\theta$", color=VERM, fontsize=8)
    ax.set_title(L("$R_q R_b$ = meia-volta:\n$P\\to P'$ pelo centro", "$R_q R_b$ = half-turn:\n$P\\to P'$ through the centre"), fontsize=8)
    fig.savefig(arquivo("fig2_loop_plano")); plt.close(fig)


# ------------------------------------------------------------- Figura 3: cone das tangentes externas em 3D
def fig3():
    X = np.array([2.0, 3.0, 6.0]); Xh = X / 7
    Xi = X / 14
    b1 = np.cross(Xh, [1, 0, 0]); b1 /= np.linalg.norm(b1); b2 = np.cross(Xh, b1)
    rc = np.sqrt(13) / 2
    fig = plt.figure(figsize=(6.0, 5.4))
    ax = fig.add_subplot(111, projection="3d")
    esfera(ax, alpha=0.3)
    u = np.linspace(0, 2 * np.pi, 200)
    circ = Xi + rc * (np.outer(np.cos(u), b1) + np.outer(np.sin(u), b2))
    ax.plot(*circ.T, color=AZUL, lw=1.4)
    for w in np.linspace(0, 2 * np.pi, 13)[:-1]:
        Tw = Xi + rc * (np.cos(w) * b1 + np.sin(w) * b2)
        ax.plot(*zip(X, Tw), color=VERM, lw=0.6, alpha=0.8)
    T = np.array([1.0, 1.5, -0.5])
    ax.plot(*zip(X, T), color=VERM, lw=1.8)
    ax.plot(*zip(np.zeros(3), T), color=OURO, lw=1.6)
    ax.plot(*zip(1.05 * X, -1.05 * X), color=VERDE, lw=1.0, ls="--")
    for pnt, nome, cor in [(X, "$X=(2,3,6)$", "k"), (Xi, "$X'$", AZUL), (np.zeros(3), "$O$", "k"),
                           (T, "$T=(1,3/2,-1/2)$", OURO), (-X, "$-X$", "k"), (-Xi, "$-X'$", AZUL)]:
        ax.scatter(*pnt, s=12, color=cor, depthshade=False)
        ax.text(*(pnt + np.array([0.2, 0.1, 0.2])), nome, fontsize=7, color=cor)
    fixa3d(ax, 5.2, elev=12, azim=-50)
    fig.savefig(arquivo("fig3_cone_tangentes_3d")); plt.close(fig)


# ------------------------------------------------------------- Figura 4: seção pelo eixo e projeção ao longo do eixo
def fig4():
    fig, axs = plt.subplots(1, 2, figsize=(7.2, 3.3), gridspec_kw={"width_ratios": [2.3, 1]})
    ax = axs[0]
    u = np.linspace(0, 2 * np.pi, 300)
    ax.plot(R * np.cos(u), R * np.sin(u), color=CINZA, lw=1)
    xt, yt = 0.5, np.sqrt(13) / 2
    for s in (1, -1):
        ax.plot([7, xt], [0, s * yt], color=VERM, lw=1.3)
        ax.plot([-7, -xt], [0, s * yt], color=VERM, lw=0.8, ls=":")
        ax.plot([xt, xt], [0, s * yt], color=AZUL, lw=0.9)
    ax.plot([0, xt], [0, yt], color=OURO, lw=1.4)
    ax.plot([-7.4, 7.4], [0, 0], color=VERDE, lw=0.9, ls="--")
    v = np.array([7 - xt, -yt]); v /= np.linalg.norm(v); w = np.array([-xt, -yt]); w /= np.linalg.norm(w)
    q = np.array([xt, yt]); s = 0.28
    ax.plot(*np.array([q + s * v, q + s * (v + w), q + s * w]).T, color="k", lw=0.6)
    ang = np.linspace(np.pi - THETA, np.pi, 30)
    ax.plot(7 + 1.6 * np.cos(ang), 1.6 * np.sin(ang), color=VERM, lw=0.8)
    ax.text(4.9, 0.18, "$\\theta$", color=VERM, fontsize=9)
    for x, nome, dy in [(7, "$X$", -0.42), (0.5, "$X'$", 0.18), (0, "$O$", -0.42), (-0.5, "$-X'$", 0.18), (-7, "$-X$", -0.42)]:
        ax.plot(x, 0, "k.", ms=4); ax.text(x + (0.25 if x == 0.5 else -0.3 if x == -0.5 else 0), dy, nome, fontsize=7.5, ha="center")
    ax.text(xt + 0.1, yt + 0.12, "$T$", fontsize=8)
    ax.text(2.6, 1.55, L("tangente externa: $\\csc\\theta=\\sqrt{14}$", "external tangent: $\\csc\\theta=\\sqrt{14}$"), color=VERM, fontsize=7.5)
    ax.text(-6.9, 2.15, "$|OX'|\\cdot|OX| = (1/2)\\cdot 7 = 7/2 = R^2$", fontsize=7.5)
    ax.text(-6.9, -2.35, L("raio $OT \\perp$ tangente $XT$: $\\csc 90^\\circ = 1$", "radius $OT \\perp$ tangent $XT$: $\\csc 90^\\circ = 1$"), color=OURO, fontsize=7.5)
    ax.set_aspect("equal"); ax.axis("off"); ax.set_ylim(-2.6, 2.6)
    ax.set_title(L("Seção pelo eixo: as tangentes externas e o ponto interno $X'$", "Section through the axis: external tangents and the inner point $X'$"), fontsize=8)
    ax = axs[1]
    rc = np.sqrt(13) / 2
    ax.plot(rc * np.cos(u), rc * np.sin(u), color=AZUL, lw=1.2)
    for w_ in np.linspace(0, 2 * np.pi, 13)[:-1] + np.pi / 12:          # nenhum raio na vertical nem na horizontal
        ax.plot([0, rc * np.cos(w_)], [0, rc * np.sin(w_)], color=VERM, lw=0.7)
    ax.plot(0, 0, "o", color=VERDE, ms=4)
    ax.text(0.08, -0.25, "$X, X', O$", fontsize=7)
    ax.set_aspect("equal"); ax.axis("off")
    ax.set_title(L("Vista ao longo do eixo:\no eixo vira um ponto (seno zero),\ncada tangente vira um raio", "View along the axis:\nthe axis becomes a point (sine zero),\neach tangent becomes a radius"), fontsize=8)
    fig.savefig(arquivo("fig4_secao_projecao")); plt.close(fig)


# ------------------------------------------------------------- Figura 5: hélice e sua projeção
def fig5():
    fig = plt.figure(figsize=(5.4, 5.0))
    ax = fig.add_subplot(111, projection="3d")
    esc = 0.12                                   # compressão vertical do desenho (o passo real é √13)
    t = np.linspace(0, 14, 600)
    ax.plot(0.5 * np.cos(PHI * t), 0.5 * np.sin(PHI * t), esc * np.sqrt(13) * t, color=AZUL, lw=1)
    n = np.arange(0, 15)
    ax.scatter(0.5 * np.cos(PHI * n), 0.5 * np.sin(PHI * n), esc * np.sqrt(13) * n, s=10, color=AZUL, depthshade=False)
    ax.plot(0.5 * np.cos(u := np.linspace(0, 2 * np.pi, 200)), 0.5 * np.sin(u), 0 * u, color=CINZA, lw=0.8)
    ax.scatter(0.5 * np.cos(PHI * n), 0.5 * np.sin(PHI * n), 0 * n, s=7, color=VERM, depthshade=False)
    for k in n[::2]:
        ax.plot([0.5 * np.cos(PHI * k)] * 2, [0.5 * np.sin(PHI * k)] * 2, [0, esc * np.sqrt(13) * k],
                color=VERM, lw=0.3, ls=":")
    ax.plot([0, 0], [0, 0], [0, esc * np.sqrt(13) * 14], color=VERDE, lw=1.2, ls="--")
    ax.text(0.05, 0.05, esc * np.sqrt(13) * 14.3, L("eixo $z$ = eixo $a$ (seno zero)", "$z$ axis = axis $a$ (sine zero)"), fontsize=7, color=VERDE)
    ax.text(0.55, 0, -0.35, L("projeção: o círculo $C$", "projection: the circle $C$"), fontsize=7, color=VERM)
    ax.set_xlim(-0.6, 0.6); ax.set_ylim(-0.6, 0.6); ax.set_zlim(0, esc * np.sqrt(13) * 14.5)
    ax.set_box_aspect((1, 1, 1.5)); ax.view_init(elev=16, azim=-60)
    ax.set_xticks([]); ax.set_yticks([]); ax.set_zticks([])
    fig.savefig(arquivo("fig5_helice")); plt.close(fig)


# ------------------------------------------------------------- Figura 6: passos de Teodoro que fecham e o que não fecha
def fig6():
    fig, axs = plt.subplots(1, 3, figsize=(7.2, 2.6))
    u = np.linspace(0, 2 * np.pi, 300)
    casos = [(1, 4, L("$n=1$: $\\csc\\sqrt{2}$, giro $90^\\circ$\nfecha em 4", "$n=1$: $\\csc\\sqrt{2}$, turn $90^\\circ$\ncloses in 4")),
             (3, 6, L("$n=3$: $\\csc 2$, giro $60^\\circ$\nfecha em 6", "$n=3$: $\\csc 2$, turn $60^\\circ$\ncloses in 6")),
             (13, 12, L("$n=13$: $\\csc\\sqrt{14}$, giro $31{,}00^\\circ$\nnunca fecha", "$n=13$: $\\csc\\sqrt{14}$, turn $31.00^\\circ$\nnever closes"))]
    for ax, (n, k, tit) in zip(axs, casos):
        ang = 2 * np.arcsin(1 / np.sqrt(n + 1))
        pts = np.array([[np.cos(i * ang), np.sin(i * ang)] for i in range(k + 1)])
        ax.plot(np.cos(u), np.sin(u), color=CINZA, lw=0.7)
        ax.plot(pts[:, 0], pts[:, 1], color=AZUL if n != 13 else VERM, lw=1.1, marker="o", ms=2.5)
        ax.set_aspect("equal"); ax.axis("off"); ax.set_title(tit, fontsize=8)
    fig.savefig(arquivo("fig6_teodoro_fecha")); plt.close(fig)


# ------------------------------------------------------------- Figura 7: octaedro de aresta √7, tetraedros e o diedro
def fig7():
    fig = plt.figure(figsize=(7.2, 3.3))
    ax = fig.add_subplot(121, projection="3d")
    U = [np.array([1.0, 0, 0]), np.array([0, 1.0, 0]), np.array([0, 0, 1.0])]   # referencial próprio
    cores = [AZUL, VERM, VERDE, OURO]
    k = 0
    for e2 in (1, -1):
        for e3 in (1, -1):
            T = [U[0], -U[0], e2 * U[1], e3 * U[2]]
            faces = [[T[i] for i in f] for f in ((0, 1, 2), (0, 1, 3), (0, 2, 3), (1, 2, 3))]
            ax.add_collection3d(Poly3DCollection(faces, facecolor=cores[k], alpha=0.22, edgecolor="#333333", lw=0.5))
            k += 1
    ax.plot([-1.25, 1.25], [0, 0], [0, 0], color="k", lw=1.8)
    ax.text(1.05, 0, 0.12, "$P$", fontsize=8); ax.text(-1.35, 0, 0.12, "$-P$", fontsize=8)
    ax.text(0, 0.05, -0.32, L("eixo $\\sqrt{14}$", "axis $\\sqrt{14}$"), fontsize=7)
    Tc = [np.array([1.0, 1, 1]), U[0], U[1], U[2]]
    faces = [[Tc[i] for i in f] for f in ((0, 1, 2), (0, 1, 3), (0, 2, 3), (1, 2, 3))]
    ax.add_collection3d(Poly3DCollection(faces, facecolor=ROXO, alpha=0.35, edgecolor=ROXO, lw=0.8))
    ax.text(1.0, 1.0, 1.1, L("tetraedro regular\naresta $\\sqrt{7}$", "regular tetrahedron\nedge $\\sqrt{7}$"), fontsize=6.5, color=ROXO)
    ax.set_xlim(-1.2, 1.2); ax.set_ylim(-1.2, 1.2); ax.set_zlim(-1.2, 1.2); ax.set_box_aspect((1, 1, 1))
    ax.view_init(elev=20, azim=-60); ax.set_xticks([]); ax.set_yticks([]); ax.set_zticks([])
    ax.set_title(L("Octaedro $\\mathcal{O}_7$: quatro tetraedros $K$\nem torno do eixo (diedro reto)", "Octahedron $\\mathcal{O}_7$: four tetrahedra $K$\naround the axis (right dihedral)"), fontsize=8)
    ax = fig.add_subplot(122)
    d = np.arccos(1 / 3)
    for i in range(5):
        a0, a1 = i * d, (i + 1) * d
        w = np.linspace(a0, a1, 40)
        ax.fill(np.r_[0, np.cos(w), 0], np.r_[0, np.sin(w), 0], color=[AZUL, VERM, VERDE, OURO, ROXO][i], alpha=0.3)
        ax.plot([0, np.cos(a0)], [0, np.sin(a0)], color="#333333", lw=0.6)
    w = np.linspace(5 * d, 2 * np.pi, 20)
    ax.plot(np.cos(w), np.sin(w), color="k", lw=2)
    ax.text(1.05, -0.12, L("fenda $7{,}36^\\circ$\n$\\cos 5\\delta = 241/243$", "gap $7.36^\\circ$\n$\\cos 5\\delta = 241/243$"), fontsize=7)
    ax.set_aspect("equal"); ax.axis("off"); ax.set_xlim(-1.1, 1.9)
    ax.set_title(L("Cinco tetraedros regulares\nem torno de uma aresta:\n$\\cos\\delta = 1/3$, não fecha", "Five regular tetrahedra\naround an edge:\n$\\cos\\delta = 1/3$, does not close"), fontsize=8)
    fig.savefig(arquivo("fig7_tetraedros")); plt.close(fig)


# ------------------------------------------------------------- Figura 8: o círculo plano como projeção do octaedro, do cubo e de T+
OCT = [R * np.array(v) for v in ((1, 0, 0), (-1, 0, 0), (0, 1, 0), (0, -1, 0), (0, 0, 1), (0, 0, -1))]
TM = [R * np.array(v) for v in ((1, 1, 1), (-1, -1, 1), (1, -1, -1), (-1, 1, -1))]   # z = eixo de vista


def solidos(ax, cubo=True, tmais=True, octa=True, esf=True):
    if esf:
        esfera(ax, alpha=0.18)
    if cubo:
        V = [R * np.array([i, j, k]) for i in (-1, 1) for j in (-1, 1) for k in (-1, 1)]
        for i in range(8):
            for j in range(i + 1, 8):
                if np.sum(np.abs(V[i] - V[j]) > 1e-9) == 1:
                    ax.plot(*zip(V[i], V[j]), color=CINZA, lw=0.5, ls=":")
    if tmais:
        for i in range(4):
            for j in range(i + 1, 4):
                ax.plot(*zip(TM[i], TM[j]), color=VERM, lw=1.1)
    if octa:
        Z, Zm = OCT[4], OCT[5]
        eq = [OCT[0], OCT[2], OCT[1], OCT[3]]
        faces = [[Z, eq[i], eq[(i + 1) % 4]] for i in range(4)] + [[Zm, eq[i], eq[(i + 1) % 4]] for i in range(4)]
        ax.add_collection3d(Poly3DCollection(faces, facecolor=AZUL, alpha=0.18, edgecolor=AZUL, lw=0.9))
        ax.plot(*zip(Z, Zm), color=VERDE, lw=1.8)


def fig8():
    fig = plt.figure(figsize=(7.4, 7.0))
    vistas = [(22, -55), (55, -40), (90, -90)]
    titulos = [L("vista oblíqua", "oblique view"), L("vista elevada", "raised view"), L("vista de cima (plano $xy$)", "top view ($xy$ plane)")]
    for k, (el, az) in enumerate(vistas):
        ax = fig.add_subplot(2, 3, k + 1, projection="3d")
        solidos(ax)
        ax.set_xlim(-2, 2); ax.set_ylim(-2, 2); ax.set_zlim(-2, 2); ax.set_box_aspect((1, 1, 1))
        ax.view_init(elev=el, azim=az); ax.set_xticks([]); ax.set_yticks([]); ax.set_zticks([])
        if el == 90:
            ax.set_proj_type("ortho"); ax.set_axis_off()             # vista de cima exata: a projeção pr(x,y,z)=(x,y)
        ax.set_title(titulos[k], fontsize=8)
    ax = fig.add_subplot(2, 2, 3)
    u = np.linspace(0, 2 * np.pi, 300)
    ax.plot(R * np.cos(u), R * np.sin(u), color=CINZA, lw=1.2)
    ax.plot([R, R, -R, -R, R], [R, -R, -R, R, R], color=CINZA, lw=1.0)
    ax.plot([R, 0, -R, 0, R], [0, R, 0, -R, 0], color=AZUL, lw=1.4)
    ax.plot([-R, R], [0, 0], color=AZUL, lw=0.6); ax.plot([0, 0], [-R, R], color=AZUL, lw=0.6)
    ax.plot([R, -R], [R, -R], color=VERM, lw=1.2); ax.plot([R, -R], [-R, R], color=VERM, lw=1.2, ls="--")
    ax.plot(0, 0, "o", color=VERDE, ms=5)
    ax.text(0.12, 0.12, L("$\\pm u_1$: dois vértices\nem $z=\\pm\\sqrt{14}/2$", "$\\pm u_1$: two vertices\nat $z=\\pm\\sqrt{14}/2$"), fontsize=7, color=VERDE, bbox=dict(fc="white", ec="none", alpha=0.85, pad=1))
    ax.text(-R, -R - 0.42, L("quadrado circunscrito (cubo, $T^+$), lado $\\sqrt{14}$", "circumscribed square (cube, $T^+$), side $\\sqrt{14}$"), fontsize=6.5)
    ax.text(-R, R + 0.18, L("quadrado inscrito a $45^\\circ$ (equador do octaedro), lado $\\sqrt{7}$", "inscribed square at $45^\\circ$ (octahedron equator), side $\\sqrt{7}$"), fontsize=6.5, color=AZUL)
    ax.set_aspect("equal"); ax.axis("off"); ax.set_xlim(-2.3, 2.3); ax.set_ylim(-2.4, 2.4)
    ax.set_title(L("Projeção no plano $xy$", "Projection on the $xy$ plane"), fontsize=8)
    ax = fig.add_subplot(2, 2, 4)
    ax.plot(R * np.cos(u), R * np.sin(u), color=CINZA, lw=1.0)
    ax.plot([R, 0, -R, 0, R], [0, R, 0, -R, 0], color=AZUL, lw=1.4)
    ax.plot([0, 0], [-R, R], color=VERDE, lw=2.2)
    ax.plot([-R, R], [R, R], color=VERM, lw=1.4); ax.plot([-R, R], [-R, -R], color=VERM, lw=1.4, ls="--")
    for y_, t_ in ((R, "$u_1=P$"), (-R, "$-u_1=-P$")):
        ax.plot(0, y_, "o", color=VERDE, ms=4); ax.text(0.12, y_ - 0.28 if y_ > 0 else y_ + 0.12, t_, fontsize=7, color=VERDE)
    ax.text(0.1, 0.0, L("altura central $\\sqrt{14}$\n= diâmetro = perpendicular\ncomum das arestas opostas", "central height $\\sqrt{14}$\n= diameter = common\nperpendicular of opposite edges"), fontsize=6.5, color=VERDE, bbox=dict(fc="white", ec="none", alpha=0.85, pad=1))
    ax.set_aspect("equal"); ax.axis("off"); ax.set_xlim(-2.3, 2.3); ax.set_ylim(-2.4, 2.4)
    ax.set_title(L("Vista lateral: o centro do círculo é o eixo $z$", "Side view: the centre of the circle is the $z$ axis"), fontsize=8)
    fig.savefig(arquivo("fig8_octaedro_projecao")); plt.close(fig)


# ------------------------------------------------------------- Figura 9: o tetraedro regular de aresta 7 em várias vistas
S7 = 7 / (2 * np.sqrt(2))
T7 = [S7 * np.array(v) for v in ((1, 1, 1), (-1, -1, 1), (1, -1, -1), (-1, 1, -1))]


def tetra7(ax, cores=True):
    pares = [(0, 1), (2, 3), (0, 2), (0, 3), (1, 2), (1, 3)]
    for i, j in pares:
        cor = VERM if (i, j) == (0, 1) else AZUL if (i, j) == (2, 3) else "#444444"
        ax.plot(*zip(T7[i], T7[j]), color=cor, lw=1.8 if cor != "#444444" else 0.9)
    faces = [[T7[a_] for a_ in f] for f in ((0, 1, 2), (0, 1, 3), (0, 2, 3), (1, 2, 3))]
    ax.add_collection3d(Poly3DCollection(faces, facecolor=OURO, alpha=0.12, edgecolor="none"))
    ax.plot([0, 0], [0, 0], [-S7, S7], color=VERDE, lw=1.2, ls="--")


def fig9():
    fig = plt.figure(figsize=(7.6, 7.4))
    vistas = [(90, -90), (55, -45), (25, -30), (0, -45)]
    tit = [L("de cima: quadrado\ncom diagonais", "from above: square\nwith diagonals"), L("elevação $55^\\circ$", "elevation $55^\\circ$"),
           L("elevação $25^\\circ$", "elevation $25^\\circ$"), L("de lado: as diagonais\nestão em alturas diferentes", "from the side: the diagonals\nare at different heights")]
    for k, (el, az) in enumerate(vistas):
        ax = fig.add_subplot(2, 4, k + 1, projection="3d")
        tetra7(ax)
        lim = 2.4
        ax.set_xlim(-lim, lim); ax.set_ylim(-lim, lim); ax.set_zlim(-lim, lim); ax.set_box_aspect((1, 1, 1))
        ax.view_init(elev=el, azim=az); ax.set_xticks([]); ax.set_yticks([]); ax.set_zticks([])
        if el in (0, 90):
            ax.set_proj_type("ortho")                                   # vistas exatas de cima e de lado
        if el == 90:
            ax.set_axis_off()
        ax.set_title(tit[k], fontsize=7)
    u = np.linspace(0, 2 * np.pi, 300)
    ax = fig.add_subplot(2, 3, 4)
    ax.plot(3.5 * np.cos(u), 3.5 * np.sin(u), color=CINZA, lw=1)
    sq = np.array([T7[0][:2], T7[2][:2], T7[1][:2], T7[3][:2], T7[0][:2]])
    ax.plot(sq[:, 0], sq[:, 1], color="#444444", lw=0.9)
    ax.plot(*zip(T7[0][:2], T7[1][:2]), color=VERM, lw=1.8); ax.plot(*zip(T7[2][:2], T7[3][:2]), color=AZUL, lw=1.8)
    ax.plot(0, 0, "o", color=VERDE, ms=4)
    ax.text(0.25, -0.75, L("centro: duas arestas\nem $z=\\pm 7/(2\\sqrt{2})$", "centre: two edges\nat $z=\\pm 7/(2\\sqrt{2})$"), fontsize=6.5, color=VERDE, bbox=dict(fc="white", ec="none", alpha=0.85, pad=1))
    ax.set_aspect("equal"); ax.axis("off")
    ax.set_title(L("Plano $xy$: quadrado inscrito,\ndiagonais = arestas 7", "$xy$ plane: inscribed square,\ndiagonals = edges 7"), fontsize=7.5)
    ax = fig.add_subplot(2, 3, 5)
    ax.plot([-S7, S7], [S7, S7], color=VERM, lw=1.8); ax.plot([-S7, S7], [-S7, -S7], color=AZUL, lw=1.8)
    for i in range(4):
        for j in range(i + 1, 4):
            if {i, j} not in ({0, 1}, {2, 3}):
                ax.plot([T7[i][0], T7[j][0]], [T7[i][2], T7[j][2]], color="#444444", lw=0.8)
    ax.plot([0, 0], [-S7, S7], color=VERDE, lw=2)
    ax.text(0.12, -0.3, "$7/\\sqrt{2}$", color=VERDE, fontsize=8)
    ax.set_aspect("equal"); ax.axis("off"); ax.set_xlim(-3, 3); ax.set_ylim(-3, 3)
    ax.set_title(L("Plano $xz$: o centro do quadrado\né o segmento vertical $7/\\sqrt{2}$", "$xz$ plane: the centre of the square\nis the vertical segment $7/\\sqrt{2}$"), fontsize=7.5)
    ax = fig.add_subplot(2, 3, 6)
    n3 = np.array([1, 1, 1]) / np.sqrt(3)
    b1 = np.array([1, -1, 0]) / np.sqrt(2); b2 = np.cross(n3, b1)
    giro = np.array([[0.0, -1.0], [1.0, 0.0]])                      # triângulo de lado: nenhuma aresta na vertical
    pr = [giro @ np.array([v @ b1, v @ b2]) for v in T7]
    rt = np.sqrt(49 / 3)
    ax.plot(rt * np.cos(u), rt * np.sin(u), color=CINZA, lw=1)
    tri = [pr[1], pr[2], pr[3], pr[1]]
    ax.plot(*np.array(tri).T, color="#444444", lw=1)
    for k in (1, 2, 3):
        ax.plot(*zip(pr[0], pr[k]), color=VERM, lw=1.2)
    ax.plot(*pr[0], "o", color=VERDE, ms=5)
    ax.text(0, -rt - 0.35, L("vértice no centro, profundidade $7\\sqrt{2/3}$", "vertex at the centre, depth $7\\sqrt{2/3}$"), fontsize=6.5, color=VERDE, ha="center", va="top")
    ax.set_aspect("equal"); ax.axis("off")
    ax.set_title(L("Vista pelo eixo vértice–face:\ntriângulo inscrito, vértice no centro", "View along the vertex–face axis:\ninscribed triangle, vertex at the centre"), fontsize=7.5)
    fig.savefig(arquivo("fig9_tetraedro7")); plt.close(fig)


# ------------------------------------------------------------- Figura 13: tetraedro T+, octaedro e círculo em vários ângulos
def cena13(ax):
    u_ = np.linspace(0, 2 * np.pi, 200)
    esfera(ax, alpha=0.14)
    ax.plot(R * np.cos(u_), R * np.sin(u_), 0 * u_, color=OURO, lw=2.0)
    Z, Zm = OCT[4], OCT[5]
    eq = [OCT[0], OCT[2], OCT[1], OCT[3]]
    faces = [[Z, eq[i], eq[(i + 1) % 4]] for i in range(4)] + [[Zm, eq[i], eq[(i + 1) % 4]] for i in range(4)]
    ax.add_collection3d(Poly3DCollection(faces, facecolor=AZUL, alpha=0.10, edgecolor=AZUL, lw=0.5))
    ax.plot(*np.array(eq + [eq[0]]).T, color=ROXO, lw=1.8)
    ax.plot(*zip(Z, Zm), color=VERDE, lw=2.0)
    for k, (i, j) in enumerate([(0, 1), (2, 3), (0, 2), (0, 3), (1, 2), (1, 3)]):
        cor = VERM if k == 0 else AZUL if k == 1 else "#333333"
        ax.plot(*zip(TM[i], TM[j]), color=cor, lw=2.2 if k < 2 else 1.1, ls="-" if k != 1 else "--")
    for v in eq:
        ax.scatter(*v, s=16, color=OURO, edgecolor="k", depthshade=False, zorder=6)
    for v in (Z, Zm):
        ax.scatter(*v, s=14, color=VERDE, depthshade=False, zorder=6)


def fig13():
    fig = plt.figure(figsize=(7.8, 7.0))
    gs = fig.add_gridspec(2, 30, height_ratios=[1.35, 1], hspace=0.12, wspace=0.0)
    vistas = [(90, -90), (62, -55), (35, -55), (12, -55), (0, -90)]
    for k, (el, az) in enumerate(vistas):
        ax = fig.add_subplot(gs[0, 6 * k:6 * k + 6], projection="3d")
        cena13(ax)
        ax.set_xlim(-2, 2); ax.set_ylim(-2, 2); ax.set_zlim(-2, 2); ax.set_box_aspect((1, 1, 1))
        ax.view_init(elev=el, azim=az); ax.set_xticks([]); ax.set_yticks([]); ax.set_zticks([])
        if el in (0, 90):
            ax.set_proj_type("ortho")                                   # vistas exatas de cima e de lado
        if el == 90:
            ax.set_axis_off()
        ax.set_title(L(f"elevação {el}°", f"elevation {el}°") if el not in (90, 0) else
                     (L("de cima (plano $xy$)", "from above ($xy$ plane)") if el == 90 else L("de lado", "from the side")), fontsize=7.5)
    u_ = np.linspace(0, 2 * np.pi, 300)
    ax = fig.add_subplot(gs[1, 0:10])
    ax.plot(R * np.cos(u_), R * np.sin(u_), color=OURO, lw=1.8)
    ax.plot([R, R, -R, -R, R], [R, -R, -R, R, R], color="#333333", lw=1.1)
    ax.plot([R, -R], [R, -R], color=VERM, lw=1.8); ax.plot([R, -R], [-R, R], color=AZUL, lw=1.8, ls="--")
    ax.plot([R, 0, -R, 0, R], [0, R, 0, -R, 0], color=ROXO, lw=1.6)
    for p in ((R, 0), (-R, 0), (0, R), (0, -R)):
        ax.plot(*p, "o", color=OURO, mec="k", ms=5)
    ax.plot(0, 0, "o", color=VERDE, ms=6)
    ax.text(0.1, -0.5, L("$\\pm P$: dois vértices,\na distância $\\sqrt{14}$", "$\\pm P$: two vertices,\n$\\sqrt{14}$ apart"), fontsize=7, color=VERDE,
            bbox=dict(fc="white", ec="none", alpha=0.85, pad=1))
    ax.set_aspect("equal"); ax.axis("off"); ax.set_xlim(-2.3, 2.3); ax.set_ylim(-2.3, 2.3)
    ax.set_title(L("Plano $xy$: quadrado com diagonais\nem volta do círculo, quadrado inscrito", "$xy$ plane: square with diagonals\naround the circle, inscribed square"), fontsize=7)
    ax = fig.add_subplot(gs[1, 10:20])
    ax.plot(R * np.cos(u_), R * np.sin(u_), color=CINZA, lw=1.0)
    ax.plot([-1.25 * R, 1.25 * R], [0, 0], color=OURO, lw=1.6)
    ax.plot([-R, R], [R, R], color=VERM, lw=1.8); ax.plot([-R, R], [-R, -R], color=AZUL, lw=1.8, ls="--")
    ax.plot([R, R], [-R, R], color="#333333", lw=1.4); ax.plot([-R, -R], [-R, R], color="#333333", lw=1.4)
    ax.plot([R, 0, -R, 0, R], [0, R, 0, -R, 0], color=ROXO, lw=1.2)
    ax.plot([0, 0], [-R, R], color=VERDE, lw=2.2)
    ax.plot([R, -R], [0, 0], "o", color=OURO, mec="k", ms=5)
    ax.text(0.1, 0.25, "$\\sqrt{14}$", color=VERDE, fontsize=9)
    ax.set_aspect("equal"); ax.axis("off"); ax.set_xlim(-2.3, 2.3); ax.set_ylim(-2.3, 2.3)
    ax.set_title(L("Plano $xz$: a aresta lateral toca\no círculo; o centro é o eixo $\\sqrt{14}$", "$xz$ plane: the lateral edge touches\nthe circle; centre = axis $\\sqrt{14}$"), fontsize=7)
    ax = fig.add_subplot(gs[1, 20:30])
    ax.plot([-R, R], [-R, R], color="#333333", lw=2.2)
    ax.plot([-1.3 * R, 1.3 * R], [0, 0], color=OURO, lw=1.0, ls=":")
    ax.plot([0, 0], [-1.3 * R, 1.3 * R], color=VERDE, lw=1.0, ls="--")
    ax.plot(0, 0, "o", color=OURO, mec="k", ms=6)
    a_ = np.linspace(0, np.pi / 4, 20)
    ax.plot(0.6 * np.cos(a_), 0.6 * np.sin(a_), color="k", lw=0.8)
    ax.text(0.65, 0.2, "$45^\\circ$", fontsize=8)
    ax.text(0.2, -1.1, L("ponto de contato:\n$\\perp$ ao raio, $45^\\circ$ do plano", "point of contact:\n$\\perp$ to the radius, $45^\\circ$ to the plane"), fontsize=7)
    ax.set_aspect("equal"); ax.axis("off"); ax.set_xlim(-2.3, 2.3); ax.set_ylim(-2.3, 2.3)
    ax.set_title(L("Plano vertical da aresta:\nela atravessa o perímetro", "Vertical plane of the edge:\nit crosses the perimeter"), fontsize=7.5)
    fig.savefig(arquivo("fig13_tetra_octa_circulo")); plt.close(fig)


if __name__ == "__main__":
    for f in (fig1, fig2, fig3, fig4, fig5, fig6, fig7, fig8, fig9, fig13):
        f()
    print("figuras geradas")
