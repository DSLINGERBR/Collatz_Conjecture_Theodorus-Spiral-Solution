#!/usr/bin/env python3
"""Figuras do tetraedro regular (fig10 a fig12), em português ou inglês. Desenho em ponto flutuante; valores exatos
nos certificados. Uso, dentro de fig/:  python3 ../figuras_tetra.py pt   (ou en)"""
import sys
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.art3d import Poly3DCollection

plt.rcParams.update({"font.family": "DejaVu Serif", "font.size": 9, "savefig.bbox": "tight", "savefig.pad_inches": 0.04})
AZUL, VERM, VERDE, OURO, CINZA, ROXO = "#1f4e9c", "#b22222", "#2e7d32", "#c08a00", "#888888", "#6a3d9a"
LANG = sys.argv[1] if len(sys.argv) > 1 else "pt"


def L(pt, en):
    return en if LANG == "en" else pt


def arquivo(base):
    return f"{base}_{LANG}.pdf"


S = 7 / (2 * np.sqrt(2))
SIN = np.array([(1, 1, 1), (-1, -1, 1), (1, -1, -1), (-1, 1, -1)], float)
V = S * SIN
ARESTAS = [(0, 1), (2, 3), (0, 2), (0, 3), (1, 2), (1, 3)]
FACES = [(0, 1, 2), (0, 3, 1), (0, 2, 3), (1, 3, 2)]
u = np.linspace(0, 2 * np.pi, 200)


def rot(ax_, ay_, az_):
    cx, sx, cy, sy, cz, sz = np.cos(ax_), np.sin(ax_), np.cos(ay_), np.sin(ay_), np.cos(az_), np.sin(az_)
    Rx = np.array([[1, 0, 0], [0, cx, -sx], [0, sx, cx]])
    Ry = np.array([[cy, 0, sy], [0, 1, 0], [-sy, 0, cy]])
    Rz = np.array([[cz, -sz, 0], [sz, cz, 0], [0, 0, 1]])
    return Rz @ Ry @ Rx


def tetra(ax, W, faces=True):
    for k, (i, j) in enumerate(ARESTAS):
        cor = VERM if k == 0 else AZUL if k == 1 else "#444444"
        ax.plot(*zip(W[i], W[j]), color=cor, lw=2.0 if k < 2 else 1.0)
    if faces:
        ax.add_collection3d(Poly3DCollection([[W[a] for a in f] for f in FACES], facecolor=OURO, alpha=0.12, edgecolor="none"))


def eixos3d(ax, lim=3.0, el=22, az=-55):
    ax.set_xlim(-lim, lim); ax.set_ylim(-lim, lim); ax.set_zlim(-lim, lim); ax.set_box_aspect((1, 1, 1))
    ax.view_init(elev=el, azim=az); ax.set_xticks([]); ax.set_yticks([]); ax.set_zticks([])


# ------------------------------------------------------------- Figura 10: o cruzamento com o círculo
def fig10():
    fig = plt.figure(figsize=(7.4, 3.6))
    ax = fig.add_subplot(1, 3, 1, projection="3d")
    tetra(ax, V)
    ax.plot(S * np.cos(u), S * np.sin(u), 0 * u, color=OURO, lw=1.8)
    ax.plot(np.sqrt(2) * S * np.cos(u), np.sqrt(2) * S * np.sin(u), 0 * u, color=OURO, lw=0.9, ls="--")
    ax.plot([0, 0], [0, 0], [-1.6 * S, 1.6 * S], color=VERDE, lw=1.2, ls="--")
    M = [(S, 0, 0), (-S, 0, 0), (0, S, 0), (0, -S, 0)]
    for m in M:
        ax.scatter(*m, s=18, color=OURO, edgecolor="k", depthshade=False, zorder=6)
    ax.plot(*zip(V[0], V[2]), color=ROXO, lw=2.6)
    eixos3d(ax, 3.0, 20, -60)
    ax.set_title(L("As arestas laterais cruzam\no plano $z=0$ no círculo", "The lateral edges cross\nthe plane $z=0$ on the circle"), fontsize=8)
    ax = fig.add_subplot(1, 3, 2)
    ax.plot(S * np.cos(u), S * np.sin(u), color=OURO, lw=1.8)
    ax.plot(np.sqrt(2) * S * np.cos(u), np.sqrt(2) * S * np.sin(u), color=OURO, lw=0.9, ls="--")
    sq = V[[0, 2, 1, 3, 0], :2]
    ax.plot(sq[:, 0], sq[:, 1], color="#444444", lw=1)
    ax.plot(*zip(V[0][:2], V[2][:2]), color=ROXO, lw=2.6)
    ax.plot(*zip(V[0][:2], V[1][:2]), color=VERM, lw=1.8); ax.plot(*zip(V[2][:2], V[3][:2]), color=AZUL, lw=1.8)
    ax.plot([S, S + 0.9], [0, 0], color="k", lw=0.6)
    ax.plot(S, 0, "o", color=OURO, mec="k", ms=5)
    ax.text(S + 0.15, 0.2, "$(s,0,0)$", fontsize=7.5)
    ax.text(0, -3.55, L("o lado parece tangente ao círculo", "the side looks tangent to the circle"), fontsize=7.5, ha="center")
    ax.set_aspect("equal"); ax.axis("off"); ax.set_xlim(-3.6, 3.6); ax.set_ylim(-3.6, 3.6)
    ax.set_title(L("Vista de cima", "Top view"), fontsize=8)
    ax = fig.add_subplot(1, 3, 3)
    ax.plot([-S, S], [-S, S], color=ROXO, lw=2.6)             # no plano x = s: (y, z) vai de (s, s) a (−s, −s)
    ax.axhline(0, color=OURO, lw=1.0, ls=":")
    ax.plot([0, 0], [-1.3 * S, 1.3 * S], color=VERDE, lw=1, ls="--")
    ax.plot(0, 0, "o", color=OURO, mec="k", ms=6)
    a = np.linspace(0, np.pi / 4, 20)
    ax.plot(0.8 * np.cos(a), 0.8 * np.sin(a), color="k", lw=0.8)
    ax.text(0.85, 0.25, "$45^\\circ$", fontsize=8)
    ax.text(0.35, -1.5, L("único ponto do círculo\nneste plano", "the only point of the circle\nin this plane"), fontsize=7)
    ax.text(-3.1, 1.6, L("aresta lateral\n(plano $x=s$)", "lateral edge\n(plane $x=s$)"), color=ROXO, fontsize=7.5)
    ax.text(0.12, 1.2 * S, "$z$", color=VERDE, fontsize=8)
    ax.text(1.05 * S, -0.45, L("$y$ (tangente)", "$y$ (tangent)"), color=OURO, fontsize=7)
    ax.set_aspect("equal"); ax.axis("off"); ax.set_xlim(-3.2, 3.6); ax.set_ylim(-3.2, 3.2)
    ax.set_title(L("Corte no plano $x=s$: a aresta\natravessa o círculo a $45^\\circ$", "Section by the plane $x=s$: the edge\ncrosses the circle at $45^\\circ$"), fontsize=8)
    fig.savefig(arquivo("fig10_cruzamento")); plt.close(fig)


# ------------------------------------------------------------- Figura 11: girar o sólido muda a sombra, não o sólido
def fig11():
    b = -np.arctan(1 / np.sqrt(2))
    ts = [0, 0.25, 0.5, 0.75, 1.0]
    fig = plt.figure(figsize=(7.6, 3.6))
    for k, t in enumerate(ts):
        W = (rot(np.pi / 4 * t, b * t, 0) @ V.T).T
        ax = fig.add_subplot(2, 5, k + 1, projection="3d")
        tetra(ax, W)
        ax.plot([0, 0], [0, 0], [-1.6 * S, 1.6 * S], color=VERDE, lw=1, ls="--")
        eixos3d(ax, 3.0, 18, -60)
        ax.set_title(L(f"giro {int(round(100 * t))}%", f"turn {int(round(100 * t))}%"), fontsize=7.5)
        ax = fig.add_subplot(2, 5, k + 6)
        for kk, (i, j) in enumerate(ARESTAS):
            cor = VERM if kk == 0 else AZUL if kk == 1 else "#444444"
            ax.plot(*zip(W[i][:2], W[j][:2]), color=cor, lw=1.6 if kk < 2 else 0.9)
        ax.plot(S * np.cos(u), S * np.sin(u), color=OURO, lw=0.6)
        ax.set_aspect("equal"); ax.axis("off"); ax.set_xlim(-4.3, 4.3); ax.set_ylim(-4.3, 4.3)
    fig.text(0.5, 0.01, L("acima: o mesmo tetraedro de aresta 7 girando; abaixo: a sua sombra no plano $xy$, de quadrado com diagonais a triângulo com o vértice no centro",
                          "top: the same tetrahedron of edge 7 turning; bottom: its shadow on the $xy$ plane, from square with diagonals to triangle with the vertex at the centre"),
             ha="center", fontsize=7.5)
    fig.savefig(arquivo("fig11_sombras")); plt.close(fig)


# ------------------------------------------------------------- Figura 12: o octaedro dos pontos médios
def fig12():
    fig = plt.figure(figsize=(7.2, 3.4))
    M = np.array([(V[i] + V[j]) / 2 for i, j in ARESTAS])
    for k, (el, az, tit) in enumerate([(22, -55, L("oblíqua", "oblique")), (90, -90, L("de cima", "from above"))]):
        ax = fig.add_subplot(1, 3, k + 1, projection="3d")
        tetra(ax, V, faces=False)
        for a in range(6):
            for b in range(a + 1, 6):
                if np.linalg.norm(M[a] + M[b]) > 1e-9:
                    ax.plot(*zip(M[a], M[b]), color=ROXO, lw=1.1)
        ax.plot(*zip(M[0], M[1]), color=VERDE, lw=2.2)
        ax.plot(S * np.cos(u), S * np.sin(u), 0 * u, color=OURO, lw=1.2)
        eixos3d(ax, 3.0, el, az)
        if el == 90:
            ax.set_proj_type("ortho"); ax.set_axis_off()             # vista de cima exata: a projeção pr(x,y,z)=(x,y)
        ax.set_title(tit, fontsize=8)
    ax = fig.add_subplot(1, 3, 3)
    ax.plot(S * np.cos(u), S * np.sin(u), color=OURO, lw=1.4)
    eq = np.array([(S, 0), (0, S), (-S, 0), (0, -S), (S, 0)])
    ax.plot(eq[:, 0], eq[:, 1], color=ROXO, lw=1.4)
    sq = V[[0, 2, 1, 3, 0], :2]
    ax.plot(sq[:, 0], sq[:, 1], color="#444444", lw=0.9)
    ax.plot(*zip(V[0][:2], V[1][:2]), color=VERM, lw=1.4); ax.plot(*zip(V[2][:2], V[3][:2]), color=AZUL, lw=1.4)
    ax.plot(0, 0, "o", color=VERDE, ms=5)
    ax.set_aspect("equal"); ax.axis("off")
    ax.set_title(L("plano $xy$: quadrado inscrito (octaedro)\ne circunscrito a $45^\\circ$ (tetraedro)",
                   "$xy$ plane: inscribed square (octahedron)\nand square circumscribed at $45^\\circ$ (tetrahedron)"), fontsize=8)
    fig.savefig(arquivo("fig12_octaedro_meios")); plt.close(fig)


if __name__ == "__main__":
    fig10(); fig11(); fig12()
    print("figuras do tetraedro geradas")
