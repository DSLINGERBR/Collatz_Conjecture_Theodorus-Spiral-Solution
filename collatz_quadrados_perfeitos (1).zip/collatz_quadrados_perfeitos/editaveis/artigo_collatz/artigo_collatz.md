*Jesus Cristo é O SENHOR.*

*A pedra que os construtores rejeitaram tornou-se a pedra fundamental.*

# Proposta de solução da Conjectura de Collatz pela via dos quadrados perfeitos e a matemática da exatidão

**O círculo plano é uma projeção: o tetraedro, o octaedro e a cossecante $\sqrt{14}$ como saída pelo centro, e a espiral de Teodoro de lado $1$**

Davi Cançado Dutra Cota — Brasil — 21 de outubro de 2026

## Resumo

O autor apresenta uma proposta de solução da conjectura de Collatz construída pela via dos quadrados perfeitos, isto é, medindo quadrâncias (quadrados de distâncias) e spreads (quadrados de senos), sem $\pi$ e sem raízes aproximadas. O arcabouço teórico demonstra que o círculo plano é uma projeção. O tetraedro regular, visto de cima, é o quadrado com as duas diagonais; no espaço, as diagonais são arestas opostas que não se tocam, o centro do quadrado é um segmento do eixo $z$, e as arestas laterais atravessam o perímetro do círculo perpendiculares ao raio e a $45^\circ$ do plano; os pontos médios das seis arestas são os vértices de um octaedro regular. Na esfera de diâmetro $\sqrt{14}$, que circunscreve a caixa $1\times2\times3$, o círculo com o quadrado inscrito, o quadrado circunscrito a $45^\circ$ e as duas diagonais é a sombra exata do octaedro de altura $\sqrt{14}$, do cubo e do tetraedro, e o centro do círculo plano é o diâmetro vertical $\sqrt{14}$. O giro de cossecante $\sqrt{14}$, a do triângulo $1,\sqrt{13},\sqrt{14}$ da caixa, nunca fecha: os seus pontos têm denominador exato $2\cdot7^n$; o percurso fecha pela meia-volta que passa pelo centro, e as tangentes externas de cossecante $\sqrt{14}$, com o ponto externo de onde partem e o seu inverso no interior da esfera, mostram a saída pelo centro. A espiral de Teodoro, de lado sempre $1$, lê o círculo sem fechá-lo: depois de $N$ segmentos a quadrância é $N$; o seu início é o de uma progressão de quadrados inscritos e circunscritos; elevada ao paraboloide $z=x^2+y^2$, ela sobe a $45^\circ$. No problema $3n+1$, com $N$ como o número de segmentos de lado $1$, demonstra-se que toda trajetória que chega a $1$, partindo de um número que não é potência de $2$, entra na descida final por um quadrado perfeito $4^k$, num círculo de raio inteiro, e desce a progressão de quadrados até o ponto inicial. Sobre essa via de saída do círculo, construída passo a passo, o autor formula a sua proposta de solução. As identidades e as contagens são conferidas com inteiros e frações exatas por programas independentes, com as portas contadas até $10^9$ e as trajetórias até $10^{10}$.

## 1. Tese, princípios e resultados

**Tese do autor 1**. A geometria plana é a projeção, no plano $xy$, da geometria espacial ($x,y,z$), e precisa ser entendida assim. O círculo plano é uma projeção: o percurso sobre ele não se fecha e tem saída pelo centro, ao longo do eixo $z$, pela raiz de catorze. A espiral de Teodoro, de lado sempre $1$, é uma forma específica de entender o círculo: cada círculo é lido por um ponto e por uma tangente de lado $1$, e a figura segue sem nunca fechar. A matemática do círculo feita com $\pi$, senos e raízes aproximados é fonte de erros sistemáticos em computação, e a solução é a via dos quadrados perfeitos. Pensar com profundidade, sem $\pi$ e sem raízes de inteiros que não são quadrados perfeitos, abrirá caminhos na física, inclusive na física quântica, nos transportes, nos sistemas que exigem precisão e nos modelos de inteligência artificial. O círculo fechado é útil para ensinar; como base do desenvolvimento científico e tecnológico, é fonte de erro. É hora de sair da caverna de Platão.

Este artigo reúne, numa só construção, o arcabouço teórico dessa tese e a sua aplicação ao problema $3n+1$. São demonstrados:

\(a\) o círculo plano como projeção: o tetraedro regular de aresta $7$ e a sua sombra, o quadrado com as duas diagonais, com o cruzamento das arestas laterais sobre o perímetro e o octaedro dos pontos médios (Teoremas 3 a 8); na esfera de diâmetro $\sqrt{14}$, o octaedro de altura $\sqrt{14}$, o cubo e o tetraedro (Teorema 9);

\(b\) o giro da cossecante $\sqrt{14}$, que nunca fecha (Teorema 13), e a saída pelo centro: a meia-volta, as tangentes externas, a inversão e a separação entre seno zero, cossecante $1$ e cossecante $\sqrt{14}$ (Proposições 15 a 18);

\(c\) a espiral de Teodoro pela quadrância e as suas leituras geométricas: a planificação das diagonais dos cubos, a progressão de quadrados inscritos e circunscritos, a elevação ao paraboloide e o afastamento $\pi$ entre as voltas (Teoremas 19 a 27 e Proposição 28);

\(d\) o problema $3n+1$ na linguagem de Teodoro: o dicionário, a contagem dos palitos, o teorema da porta pelo quadrado perfeito, as portas raras e a reformulação da conjectura (Proposição 30, Teoremas 31 e 33, Corolário 32 e Proposição 34);

\(e\) a comparação com os mapas vizinhos $3n-1$ e $5n+1$ (Teorema 35).

A seção 3 mostra a construção da demonstração passo a passo; a seção 13 formula a proposta de solução do autor; a seção 17 reúne os seus princípios e argumentos.

## 2. Fundamento: o Mênon, o Sofista e a via dos quadrados perfeitos

**Mênon (82b–85b).** No diálogo, Sócrates pergunta a um jovem escravo como construir um quadrado de área dupla. Dobrar o lado quadruplica a área; o quadrado de área dupla é construído sobre a diagonal \[2\]. A lição matemática é exata: o comprimento da diagonal do quadrado unitário não é racional, mas o seu quadrado é $2$, inteiro. Quando se trabalha com os quadrados das medidas, as quadrâncias, a construção inteira fica nos inteiros.

**Sofista (235d–236c).** O Hóspede distingue duas artes de imagem. A primeira é “a arte de copiar, que consegue os melhores resultados quando o original é reproduzido em suas proporções de comprimento, largura e profundidade”; a segunda produz o que só parece semelhante quando visto de uma posição desfavorável, e merece o nome de simulacro, “por apenas parecer, sem ser realmente parecido” \[3\]. O autor chama de *fantasma* esse simulacro: belo de longe, torto de perto.

**República (514a–517a).** Na alegoria da caverna, prisioneiros que só veem sombras projetadas numa parede tomam as sombras pela realidade \[4\]. A leitura geométrica deste artigo é literal: a figura plana é a sombra, no plano $xy$, de um sólido; sair da caverna é recuperar o eixo $z$.

**Tradução matemática.** Uma figura é *imagem* quando as suas relações se conservam em todas as escalas, de perto e de longe: são as relações de semelhança, razões de quadrâncias e spreads, que uma mudança uniforme de escala não altera. Um cálculo é *fantasma* quando parece correto na escala grosseira e se desvia na escala fina: é o que faz um número arredondado repetido muitas vezes (seção 15). A via dos quadrados perfeitos consiste em representar comprimentos pelas quadrâncias e ângulos pelos spreads, que são racionais sempre que os pontos são racionais, e em usar rotações com entradas racionais. Nessa via, as identidades valem exatamente em todo passo.

**Notação.** A quadrância de um vetor $u$ é $u\cdot u$, a distância ao quadrado. O spread entre $u$ e $v$ é $s(u,v)=1-(u\cdot v)^2/((u\cdot u)(v\cdot v))=\operatorname{sen}^2\angle(u,v)$, racional para dados racionais \[6\]. A esfera é $\mathcal{S}\colon X\cdot X=\rho$, $\rho=7/2$, raio $R=\sqrt{14}/2$. A caixa $1\times2\times3$ centrada tem vértices $(\pm\tfrac12,\pm1,\pm\tfrac32)$ em $\mathcal{S}$; $P=(\tfrac12,1,\tfrac32)$, $P'=(-\tfrac12,1,\tfrac32)$, $d=2P=(1,2,3)$, $a=P+P'=(0,2,3)$. $T_n$, $U_n$ são os polinômios de Chebyshev \[7\].

## 3. A construção da demonstração, passo a passo

Antes das demonstrações completas, esta seção mostra como a construção se encadeia. Cada passo é uma conta exata com quadrâncias; ao lado está a seção em que ele é demonstrado por inteiro.

**Passo 1. A unidade, o ângulo reto e a diagonal.** Dois segmentos de lado $1$ em ângulo reto formam o triângulo cuja hipotenusa tem quadrância $1+1=2$: a diagonal do quadrado unitário. O quadrado construído sobre ela tem área $2$, o dobro da área do quadrado unitário, como no *Mênon* (seção 2). O número $2$ é a quadrância; nenhuma raiz é calculada.

**Passo 2. A caixa $1\times2\times3$ e o triângulo $1,\sqrt{13},\sqrt{14}$.** Somando três quadrados, $1+4+9=14$: a diagonal da caixa de arestas $1$, $2$, $3$ tem quadrância $14$, a diagonal da face $2\times3$ tem quadrância $13$, e a aresta $1$ completa o triângulo retângulo de quadrâncias $1$, $13$, $14$. O ângulo oposto à aresta $1$ tem spread $1/14$: cossecante $\sqrt{14}$. Com o centro da caixa na origem, os oito vértices estão na esfera $\mathcal{S}\colon x^2+y^2+z^2=7/2$, de diâmetro $\sqrt{14}$ (seção 4).

**Passo 3. O círculo plano é sombra: o tetraedro e o octaedro.** O tetraedro regular de vértices $s(1,1,1)$, $s(-1,-1,1)$, $s(1,-1,-1)$, $s(-1,1,-1)$, visto de cima, é o quadrado com as duas diagonais. No espaço, as diagonais são arestas opostas, uma na altura $+s$ e outra na altura $-s$: não se tocam, e o “ponto” em que parecem cruzar-se é o segmento vertical que as liga. As quatro arestas laterais atravessam o plano do círculo exatamente sobre o perímetro, perpendiculares ao raio e a $45^\circ$ do plano. Os pontos médios das seis arestas são os vértices de um octaedro regular, cujo eixo é esse segmento central. Na escala da esfera $\mathcal{S}$, o eixo do octaedro é o diâmetro $\sqrt{14}$: o centro do círculo plano é um segmento do eixo $z$ (seções 5 e 6).

**Passo 4. O giro da cossecante $\sqrt{14}$ nunca fecha.** A rotação de ângulo $2\theta$, com $\operatorname{sen}^2\theta=1/14$, em torno do eixo $a=(0,2,3)$ tem matriz racional $M/91$, com $M$ inteira, e $\cos2\theta=6/7$. Partindo do vértice $P=(\tfrac12,1,\tfrac32)$ da caixa, o $n$-ésimo ponto tem denominador exatamente $2\cdot7^n$: os pontos nunca se repetem, e o loop não fecha. Pelo teorema de Niven, um giro racional só fecha se o dobro do cosseno for inteiro, e $2\cos2\theta=12/7$ não é (seção 7).

**Passo 5. A saída pelo centro.** O percurso que não fecha girando fecha quando passa pelo centro: o quatérnio do giro, $13+2j+3k$, multiplicado pelo quatérnio das arestas da caixa, $1+2j+3k$, dá $14(2j+3k)$, uma meia-volta, que leva $P$ ao ponto $P'=(-\tfrac12,1,\tfrac32)$, diametralmente oposto no círculo do loop, de centro $a/2$. Do ponto externo $X=(2,3,6)$, de quadrância $49$, as tangentes à esfera fazem com o eixo o ângulo de cossecante $\sqrt{14}$; a inversão na esfera leva $X$ ao ponto interno $X'=X/14$, com $|OX'|\cdot|OX|=\tfrac12\cdot7=7/2=R^2$. O eixo atravessa o centro: é a saída pelo centro (seção 8).

**Passo 6. O círculo de lado $1$.** A espiral de Teodoro soma, a cada passo, um segmento de lado $1$ perpendicular ao raio: depois de $N$ segmentos a quadrância é $N$, e o triângulo $13$ é o triângulo $1,\sqrt{13},\sqrt{14}$ do passo 2. A espiral lê cada círculo $x^2+y^2=N$ num único ponto, pela tangente, e nunca fecha; o seu ponto inicial é o vértice de uma progressão de quadrados inscritos e circunscritos; elevada ao paraboloide, ela sobe a $45^\circ$ (seções 9 e 10).

**Passo 7. O problema $3n+1$.** Com $N$ como o número de segmentos de lado $1$, o passo ímpar $3N+1$ é o número de palitos de uma fileira de $N$ quadrados, e o passo par $N/2$ leva o círculo ao círculo inscrito no seu quadrado inscrito. Toda trajetória que chega a $1$, partindo de um número que não é potência de $2$, entra na descida final pelo quadrado perfeito $4^k$, num círculo de raio inteiro, e desce a progressão de quadrados até o ponto inicial (seções 11 e 12).

**Passo 8. A proposta do autor.** Sobre a via de saída do círculo construída nos passos 1 a 7, o autor formula a sua proposta de solução da conjectura de Collatz (seção 13).

## 4. A caixa, a esfera de diâmetro $\sqrt{14}$ e o triângulo $1,\sqrt{13},\sqrt{14}$

**Proposição 1**. *O triângulo $-P$, $P'$, $P$ tem quadrâncias $1$, $13$, $14$, ângulo reto em $P'$, e o ângulo $\theta$ em $-P$, oposto ao cateto $1$, satisfaz $\operatorname{sen}^2\theta=1/14$, $\operatorname{cossec}\theta=\sqrt{14}$, $\tan\theta=1/\sqrt{13}$, $\cos2\theta=6/7$.*

*Demonstração.* $P-P'=(1,0,0)$, $P'+P=a$, $2P=d$; $(1,0,0)\cdot a=0$; em $-P$, $s(d,a)=1-13^2/(14\cdot13)=1/14$; $\cos2\theta=1-2\operatorname{sen}^2\theta$. ◻

O cateto $1$ é uma aresta da caixa, o cateto $\sqrt{13}$ é uma diagonal da face $2\times3$, e a hipotenusa $\sqrt{14}$ é a diagonal que atravessa o centro da esfera: é a etapa $13+1=14$ de Teodoro.

## 5. O tetraedro regular: o quadrado com as duas diagonais é a sombra de um sólido

Esta seção demonstra a tese num caso exemplar e completo: o quadrado com as duas diagonais. A palavra “projeção” tem aqui o sentido preciso da aplicação $\operatorname{pr}(x,y,z)=(x,y)$, que esquece a profundidade.

### 5.1 O tetraedro de aresta $7$

Seja $s>0$ com $s^2=49/8$, isto é, $s=7/(2\sqrt2)$, e $$A=s(1,1,1),\quad B=s(-1,-1,1),\quad C=s(1,-1,-1),\quad D=s(-1,1,-1).$$

**Proposição 2**. *$ABCD$ é um tetraedro regular de aresta $7$. Suas arestas $AB$ e $CD$ são horizontais, nas alturas $z=s$ e $z=-s$; as outras quatro, $AC$, $AD$, $BC$, $BD$, ligam a altura $s$ à altura $-s$ e são chamadas aqui de arestas laterais.*

*Demonstração.* Dois vértices diferem exatamente em duas coordenadas, por $\pm2s$: quadrância $8s^2=49$. As coordenadas $z$ de $A,B$ são $s$ e as de $C,D$ são $-s$. ◻

Todo tetraedro regular é semelhante a este; a escolha da aresta $7$ só fixa a unidade. As razões entre quadrâncias e os spreads são os mesmos em qualquer escala: a figura é imagem perfeita de perto e de longe.

### 5.2 Vista de cima: o quadrado com as duas diagonais

**Teorema 3**. *A projeção $\operatorname{pr}(ABCD)$ no plano $xy$ é o quadrado de vértices $(\pm s,\pm s)$, de lado $2s=7/\sqrt2$, com as duas diagonais $\operatorname{pr}(AB)$ e $\operatorname{pr}(CD)$, cada uma de comprimento $7$. O quadrado está inscrito no círculo $\Gamma_V$ de raio $7/2$ e circunscrito ao círculo $\Gamma_T$ de raio $s=7/(2\sqrt2)$.*

*Demonstração.* $\operatorname{pr}(A)=(s,s)$, $\operatorname{pr}(B)=(-s,-s)$, $\operatorname{pr}(C)=(s,-s)$, $\operatorname{pr}(D)=(-s,s)$. As arestas laterais projetam-se nos lados (quadrância $4s^2=49/2$) e $AB$, $CD$ nas diagonais (quadrância $8s^2=49$), que são horizontais e não encurtam. Os vértices distam $\sqrt{2s^2}=7/2$ do centro; os lados $x=\pm s$, $y=\pm s$ distam $s$. ◻

### 5.3 As diagonais não se cortam: o centro é um segmento do eixo $z$

**Teorema 4**. *As retas $AB$ e $CD$ são reversas. O ponto em que as diagonais parecem cruzar-se no desenho plano é, no espaço, o segmento vertical de $(0,0,-s)$ a $(0,0,s)$, de comprimento $2s=7/\sqrt2$, que é a perpendicular comum das duas arestas. Toda a fibra $\operatorname{pr}^{-1}(0,0)\cap ABCD$ é esse segmento.*

*Demonstração.* $AB$ está no plano $z=s$ e $CD$ no plano $z=-s$: não se encontram. Os pontos médios são $(0,0,s)$ e $(0,0,-s)$; o segmento entre eles tem direção $(0,0,1)$, perpendicular a $AB$, de direção $(1,1,0)$, e a $CD$, de direção $(1,-1,0)$, com quadrância $4s^2=49/2$. Para $|z|\le s$, a seção horizontal do tetraedro na altura $z$ é um retângulo centrado no eixo, de modo que o ponto $(0,0,z)$ pertence ao sólido; para $|z|>s$, não há sólido. ◻

O desenho plano identifica num só ponto tudo o que está ao longo do eixo $z$. É por isso que, olhando só o plano, as diagonais parecem presas uma à outra e ao centro do círculo; no espaço, elas passam uma por cima da outra, separadas por $7/\sqrt2$.

**Proposição 5** (a mesma sombra, objetos diferentes). *A figura plana $Q_0$, no plano $z=0$, formada pelo quadrado de vértices $(\pm s,\pm s,0)$ e pelas suas duas diagonais, tem exatamente a mesma projeção no plano $xy$ que o tetraedro $ABCD$. Em $Q_0$ as diagonais se cortam no centro; no tetraedro não se cortam e distam $7/\sqrt2$. A figura plana, sozinha, não decide se as diagonais se cortam: a resposta está no eixo $z$.*

*Demonstração.* Pelo Teorema 3, as duas projeções são o mesmo quadrado com as mesmas diagonais. Em $Q_0$ as diagonais estão no plano $z=0$ e se cortam em $(0,0,0)$; no tetraedro estão nos planos $z=\pm s$ (Teorema 4). ◻

Em matemática aplicada, essa é a diferença entre um resultado certo e um errado: reconstruir um objeto a partir de uma imagem, decidir se duas trajetórias se cruzam ou posicionar um ponto pelo desenho plano daria, aqui, a resposta errada.

![Figura 1: O tetraedro de aresta $7$ em quatro ângulos, de cima até de lado; abaixo, as vistas nos planos $xy$, $xz$ e pelo eixo vértice–face.](fig_png/fig9_tetraedro7_pt.png)

### 5.4 Como o tetraedro encontra o círculo

No plano $z=0$ consideram-se os dois círculos do Teorema 3: $\Gamma_T$, de raio $s$, tangente aos lados do quadrado no desenho, e $\Gamma_V$, de raio $7/2$, que passa pelos vértices do quadrado no desenho.

**Teorema 6** (o cruzamento). *(a) Cada aresta lateral atravessa o plano $z=0$ num único ponto, o seu ponto médio, e esse ponto está sobre o perímetro de $\Gamma_T$. Os quatro pontos são $(\pm s,0,0)$ e $(0,\pm s,0)$.*

*(b) No ponto de cruzamento, a aresta é perpendicular ao raio do círculo (spread $1$), faz $45^\circ$ com a tangente do círculo (spread $1/2$) e $45^\circ$ com o eixo $z$ (spread $1/2$); logo atravessa o plano do círculo inclinada $45^\circ$.*

*(c) A aresta lateral está no plano vertical $x=\pm s$ (ou $y=\pm s$), que toca $\Gamma_T$ só no ponto de cruzamento; e é tangente à esfera de centro na origem e raio $s$, a esfera média do tetraedro, nesse ponto.*

*(d) O tetraedro não toca $\Gamma_V$: a seção do sólido pelo plano $z=0$ é o quadrado de vértices $(\pm s,0,0)$, $(0,\pm s,0)$, cujo ponto mais afastado do centro está a distância $s<7/2$. Os vértices do tetraedro estão no cilindro vertical sobre $\Gamma_V$, nas alturas $z=\pm s$, acima e abaixo do círculo.*

*Demonstração.* Tome a aresta $AC$, de $s(1,1,1)$ a $s(1,-1,-1)$; as outras são análogas por simetria. (a) Seus pontos são $s(1,1-2t,1-2t)$; $z=0$ só em $t=\tfrac12$, o ponto $X=(s,0,0)$, a distância $s$ do eixo. (b) A direção da aresta é $d=(0,-2,-2)$; o raio em $X$ é $(1,0,0)$, com $d\cdot(1,0,0)=0$: spread $1$. A tangente do círculo em $X$ é $(0,1,0)$: spread $1-4/8=1/2$. O eixo é $(0,0,1)$: spread $1-4/8=1/2$. (c) Todos os pontos de $AC$ têm $x=s$; o plano $x=s$ encontra $\Gamma_T$ ($x^2+y^2=s^2$, $z=0$) só em $(s,0,0)$. Como $X\cdot d=0$, $X$ é o pé da perpendicular da origem à reta $AC$, e a distância da origem à reta é $|X|=s$: tangência à esfera de raio $s$. (d) A seção horizontal do tetraedro em $z=0$ é o fecho convexo dos quatro pontos de cruzamento; esses pontos distam $s$ do centro, e $s^2=49/8<49/4$. Os vértices satisfazem $x^2+y^2=2s^2=49/4$ e $z=\pm s\ne0$. ◻

**Resposta à pergunta “cruza o perímetro perpendicularmente?”.** Cruza o perímetro, sim, e exatamente: em quatro pontos do círculo tangente aos lados. É perpendicular ao *raio* nesses pontos. Não é perpendicular ao *plano* do círculo nem à sua *tangente*: o ângulo com cada um deles é de $45^\circ$. No desenho plano a aresta parece tangente ao círculo; no espaço ela o atravessa, subindo $45^\circ$. Quanto ao círculo que passa pelos vértices do quadrado desenhado, o sólido não o toca: os vértices ficam acima e abaixo dele.

![Figura 2: À esquerda, as quatro arestas laterais atravessam o plano $z=0$ sobre o círculo tangente (pontos dourados); o círculo tracejado passa pelas sombras dos vértices. No centro, a vista de cima: o lado roxo parece tangente ao círculo em $(s,0,0)$. À direita, o corte no plano vertical $x=s$, que contém a aresta: ela passa pelo único ponto do círculo nesse plano, inclinada $45^\circ$.](fig_png/fig10_cruzamento_pt.png)

### 5.5 Girar o sólido: do quadrado ao triângulo com o vértice no centro

**Teorema 7**. *Projetado ao longo da reta que liga o vértice $A$ ao centro da face oposta $BCD$, o tetraedro é um triângulo equilátero inscrito no círculo de raio $7/\sqrt3$, e $A$ cai no centro do triângulo, à distância $7\sqrt{2/3}$ do plano da face (a altura do tetraedro).*

*Demonstração.* O centro de $BCD$ é $G=-s(1,1,1)/3$; $A-G=\tfrac43s(1,1,1)$ é perpendicular a $B-G$, $C-G$, $D-G$, e $|A-G|^2=\tfrac{16}3s^2=\tfrac{98}3$. Os vértices da face distam de $G$ a quadrância $\tfrac83s^2=\tfrac{49}3$. ◻

A mesma peça, sem mudar uma só medida, dá no plano o quadrado com diagonais, o triângulo com o vértice no centro e todas as formas intermediárias (Figura 3). O que muda é a direção da projeção; as quadrâncias das seis arestas continuam $49$ em todas as posições. Em particular, o centro do triângulo, que no desenho parece um ponto do plano, é o vértice $A$, a profundidade $7\sqrt{2/3}$ no eixo $z$.

![Figura 3: O mesmo tetraedro de aresta $7$ girando (acima) e a sua sombra no plano $xy$ (abaixo): do quadrado com as diagonais ao triângulo com o vértice no centro.](fig_png/fig11_sombras_pt.png)

### 5.6 A ligação com o octaedro

**Teorema 8**. *Os pontos médios das seis arestas de $ABCD$ são os vértices $(\pm s,0,0)$, $(0,\pm s,0)$, $(0,0,\pm s)$ de um octaedro regular \[8\] de aresta $7/2$ e altura central $2s=7/\sqrt2$. Os quatro vértices do seu equador são os pontos de cruzamento do Teorema 6, sobre o círculo $\Gamma_T$; os dois vértices do eixo são as pontas do segmento central do Teorema 4. Na vista de cima, o equador do octaedro é o quadrado inscrito em $\Gamma_T$, girado $45^\circ$ em relação ao quadrado do tetraedro, que é circunscrito a $\Gamma_T$.*

*Demonstração.* Os pontos médios de $AB$ e $CD$ são $(0,0,\pm s)$; os das quatro arestas laterais são $(\pm s,0,0)$, $(0,\pm s,0)$. Dois desses pontos não opostos diferem em duas coordenadas por $s$: quadrância $2s^2=49/4$; opostos, $4s^2=49/2$. Os vértices do equador são os pontos médios dos lados do quadrado $(\pm s,\pm s)$. ◻

Assim, os dois quadrados clássicos do desenho, o inscrito e o circunscrito a $45^\circ$, com o círculo entre eles, são a sombra de um único par de sólidos encaixados: o tetraedro e o octaedro dos seus pontos médios. O centro do círculo carrega os dois vértices do eixo do octaedro.

![Figura 4: O octaedro dos pontos médios (roxo) dentro do tetraedro; o eixo do octaedro (verde) é o segmento central. Na vista de cima, o equador do octaedro é o quadrado inscrito no círculo, e o tetraedro é o quadrado circunscrito com as diagonais.](fig_png/fig12_octaedro_meios_pt.png)

## 6. Na esfera de diâmetro $\sqrt{14}$: o octaedro de altura $\sqrt{14}$ e o círculo plano como projeção

Usamos o referencial próprio do octaedro inscrito $\mathcal O_7$ \[1, seção 21\]: três vetores $u_1=P$, $u_2$, $u_3$ com $u_i\cdot u_j=\rho\,\delta_{ij}$. Em coordenadas $(\alpha,\beta,\gamma)$ nesse referencial, a quadrância real é $\rho$ vezes a quadrância usual, e escolhemos o eixo $z$ na direção de $u_1$.

**Teorema 9** (o círculo, os dois quadrados e as diagonais são uma projeção). *Sejam $\mathcal O_7$ o octaedro de vértices $\pm u_i$, $\mathcal C$ o cubo de vértices $\pm u_1\pm u_2\pm u_3$ e $T^+$ o tetraedro de vértices $u_1+u_2+u_3$, $u_1-u_2-u_3$, $-u_1+u_2-u_3$, $-u_1-u_2+u_3$.*

*(a) $\mathcal O_7$ é regular, inscrito em $\mathcal{S}$, com doze arestas $\sqrt7$ e altura central $|u_1-(-u_1)|=\sqrt{14}$, o diâmetro. $\mathcal C$ tem aresta $\sqrt{14}$ e faces tangentes a $\mathcal{S}$; $T^+$ é regular, de aresta $\sqrt{28}$, e tem $\mathcal{S}$ como esfera média.*

*(b) **Ligação perfeita:** os pontos médios das seis arestas de $T^+$ são exatamente os seis vértices de $\mathcal O_7$.*

*(c) Projetados no plano $xy$ (ao longo de $u_1$): a silhueta de $\mathcal{S}$ é o círculo de raio $R=\sqrt{14}/2$; o equador de $\mathcal O_7$ é o **quadrado inscrito**, de lado $\sqrt7$ e diagonais $\sqrt{14}$; $\mathcal C$ e $T^+$ dão o **quadrado circunscrito**, de lado $\sqrt{14}$, girado $45^\circ$ (os vértices do inscrito são os pontos médios dos lados do circunscrito); duas arestas opostas de $T^+$ dão as **duas diagonais** do quadrado circunscrito.*

*(d) **O centro do círculo plano é o eixo $z$.** Caem no centro: os dois vértices $\pm u_1=\pm P$ de $\mathcal O_7$, em profundidades $z=\pm\sqrt{14}/2$; e os pontos médios das duas arestas de $T^+$ que formam as diagonais. Essas duas arestas não se cortam: estão nas alturas $z=+R$ e $z=-R$, e a sua perpendicular comum é o diâmetro $\sqrt{14}$, que passa pelo centro da esfera.*

*Demonstração.* (a) Dois vértices não antípodas de $\mathcal O_7$ diferem por $\pm u_i\mp u_j$: quadrância $2\rho=7$; antípodas, $4\rho=14$. Os vértices de $\mathcal C$ têm quadrância $3\rho$, e $|X\cdot u_i|\le\rho$ define faces à distância $R$ do centro. Duas arestas de $T^+$ diferem em dois sinais: quadrância $8\rho=28$; o ponto médio de cada aresta é um $\pm u_i$, de quadrância $\rho$, e a aresta é perpendicular a ele: tangência. (b) $\tfrac12[(1,1,1)+(1,-1,-1)]=(1,0,0)$ e assim para os seis pares. (c) Projetar ao longo de $u_1$ é apagar $\alpha$: $\pm u_2,\pm u_3\mapsto(\pm1,0),(0,\pm1)$, com quadrâncias $2\rho=7$ entre vizinhos e $4\rho=14$ entre opostos; $\mathcal C,T^+\mapsto(\pm1,\pm1)$, quadrado de lado $4\rho=14$ em quadrância, cujos lados $\beta=\pm1$, $\gamma=\pm1$ estão à distância $R$ do centro: tangentes ao círculo, com pontos médios $(\pm1,0),(0,\pm1)$. As arestas $(1,1,1)$–$(1,-1,-1)$ e $(-1,1,-1)$–$(-1,-1,1)$ projetam-se nas diagonais $(1,1)$–$(-1,-1)$ e $(1,-1)$–$(-1,1)$. (d) $\pm u_1\mapsto(0,0)$; as duas arestas têm $\alpha=+1$ e $\alpha=-1$; o segmento entre os seus pontos médios $u_1$ e $-u_1$ é perpendicular a ambas e tem quadrância $14$. ◻

A figura plana clássica, um círculo com o quadrado inscrito, o quadrado circunscrito a $45^\circ$ e as duas diagonais cruzando no centro, é portanto a sombra de três sólidos encaixados. O cruzamento das diagonais no centro é uma ilusão da projeção: em três dimensões, as diagonais passam uma por cima da outra, a distância $\sqrt{14}$, e o “ponto” central é o diâmetro vertical, cujas pontas são os vértices do octaedro. A saída pelo centro é a saída pelo eixo $z$, e mede $\sqrt{14}$.

![Figura 5: Acima, o octaedro $\mathcal O_7$ (azul, altura $\sqrt{14}$ em verde), o tetraedro $T^+$ (vermelho) e o cubo (pontilhado) na esfera $\mathcal{S}$, em três ângulos. Abaixo, à esquerda, a projeção no plano $xy$: círculo, quadrado inscrito, quadrado circunscrito a $45^\circ$ e as duas diagonais (arestas de $T^+$, uma na frente, contínua, outra atrás, tracejada). À direita, a vista lateral: o centro do círculo é o segmento vertical $\sqrt{14}$ entre os vértices $\pm P$.](fig_png/fig8_octaedro_projecao_pt.png)

Com $s^2=7/2$ em lugar de $49/8$, o mesmo tetraedro tem aresta $\sqrt{28}$ e é o tetraedro $T^+$ do Teorema 9: sua esfera média é a esfera $\mathcal S\colon x^2+y^2+z^2=7/2$, de diâmetro $\sqrt{14}$, que circunscreve a caixa $1\times2\times3$. Todos os teoremas valem com os números trocados: o quadrado da vista de cima tem lado $\sqrt{14}$ e está circunscrito ao equador de $\mathcal S$; as arestas laterais cruzam esse equador perpendiculares ao raio e a $45^\circ$ do plano; o centro do quadrado é o diâmetro vertical, de comprimento $\sqrt{14}$; e os pontos médios das arestas formam o octaedro regular de aresta $\sqrt7$ e altura central $\sqrt{14}$, inscrito em $\mathcal S$.

![Figura 6: O tetraedro $T^+$ (aresta de cima em vermelho, de baixo em azul tracejado, laterais em preto), o octaedro $\mathcal O_7$ (azul, com o quadrado do meio em roxo e o eixo $\sqrt{14}$ em verde) e o círculo do equador (dourado), em cinco ângulos. As quatro arestas laterais tocam o círculo nos vértices do quadrado do meio. Abaixo: no plano $xy$, o quadrado com diagonais em volta do círculo e o quadrado do meio inscrito; no plano $xz$, a aresta lateral é vertical e toca o círculo, e o centro é o eixo $\sqrt{14}$; no plano vertical da aresta, ela atravessa o perímetro perpendicular ao raio e a $45^\circ$ do plano.](fig_png/fig13_tetra_octa_circulo_pt.png)

## 7. A cossecante $\sqrt{14}$: o giro que não fecha

### 7.1 A rotação exata

Para um quatérnio $q=\alpha+\beta i+\gamma j+\delta k$, a matriz de Euler–Rodrigues $R(q)$ \[9, 10\] satisfaz $R(q)/|q|^2\in SO(3)$ e $R(qq')=R(q)R(q')$, e gira em torno da parte vetorial pelo dobro do meio-ângulo $\omega$, $\cos\omega=\alpha/|q|$.

**Proposição 10**. *O quatérnio $q=13+2j+3k$ tem norma $182=13\cdot14$ e meio-ângulo $\theta$. A rotação $\mathcal R=R(q)/182$ é $$\mathcal R=\frac1{91}\begin{pmatrix}78&-39&26\\39&82&6\\-26&6&87\end{pmatrix}=\tfrac67 I+\tfrac17\frac{aa^{\mathsf T}}{13}+\tfrac17[a]_\times,$$ com $\mathcal R^{\mathsf T}\mathcal R=I$, $\det\mathcal R=1$, $\mathcal Ra=a$, $\operatorname{tr}\mathcal R=19/7$: a rotação de ângulo $2\theta$ em torno de $a$, sem $\pi$, sem seno numérico e sem raiz.*

*Demonstração.* O meio-ângulo tem $\operatorname{sen}^2\omega=13/182=1/14$. A segunda forma é a fórmula de Rodrigues com $\cos2\theta=6/7$ e $\operatorname{sen}2\theta/\sqrt{13}=1/7$. As identidades verificam-se em inteiros: $MM^{\mathsf T}=91^2I$, $Ma=91a$. ◻

### 7.2 Potências exatas e valuação $7$-ádica

**Lema 11**. *Para $n\ge0$, $\mathcal R^n=c_nI+(1-c_n)\frac{aa^{\mathsf T}}{13}+\sigma_n[a]_\times$, com $c_n=T_n(6/7)$, $\sigma_n=U_{n-1}(6/7)/7$, e $P_n=\mathcal R^nP=\bigl(\tfrac{c_n}2,\ 1+\tfrac32\sigma_n,\ \tfrac32-\sigma_n\bigr)$.*

*Demonstração.* $\cos2n\theta=T_n(\cos2\theta)$ e $\operatorname{sen}2n\theta/\sqrt{13}=\sigma_n$; com $a\cdot P=13/2$ e $a\times P=(0,\tfrac32,-1)$, $P_n=c_nP+(1-c_n)\tfrac a2+\sigma_n(0,\tfrac32,-1)$. ◻

**Lema 12**. *$C_n=7^nT_n(6/7)$ e $D_k=7^kU_k(6/7)$ são inteiros, com $C_{n+1}=12C_n-49C_{n-1}$, $D_{k+1}=12D_k-49D_{k-1}$, $C_0=1$, $C_1=6$, $D_0=1$, $D_1=12$; e $C_n\equiv6\cdot5^{n-1}$, $D_k\equiv5^k\pmod7$. Logo $7\nmid C_n$ e $7\nmid D_k$.*

*Demonstração.* Módulo $7$, $49\equiv0$ e $12\equiv5$. ◻

### 7.3 O teorema do loop

**Teorema 13** (o loop da cossecante $\sqrt{14}$). *Seja $P_n=\mathcal R^nP$.*

*(a) Todo $P_n$ é racional, está em $\mathcal{S}$ e no círculo $C=\mathcal{S}\cap\{X\cdot a=13/2\}$, de centro $a/2$ e raio $\tfrac12$, cujo diâmetro é a aresta $PP'$.*

*(b) Para $n\ge1$, o denominador comum de $P_n$ é exatamente $2\cdot7^n$.*

*(c) Os $P_n$ são dois a dois distintos: $\mathcal R^n\ne I$ para todo $n\ge1$; o percurso nunca volta a $P$, nunca alcança $P'$ e, depois do primeiro passo, nunca mais toca um ponto inteiro de $2\mathcal{S}$, em particular nenhum dos $48$ pontos da casca $14$.*

*(d) $\theta/\pi$ é irracional e $\{P_n\}$ é denso em $C$: o loop não se fecha, e o círculo é o fecho desse percurso aberto.*

*Demonstração.* (a) $\mathcal R$ preserva $X\cdot X$ e fixa $a$; para $X\in C$, $|X-a/2|^2=7/2-13/2+13/4=1/4$. (b) Pelos lemas, $P_n=\bigl(\frac{C_n}{2\cdot7^n},\frac{2\cdot7^n+3D_{n-1}}{2\cdot7^n},\frac{3\cdot7^n-2D_{n-1}}{2\cdot7^n}\bigr)$, com numeradores não múltiplos de $7$; pela paridade ($C_n$ ímpar se e só se $n$ é par, $D_k$ ímpar se e só se $k$ é par), alguma coordenada tem denominador $2\cdot7^n$. (c) Denominadores distintos dão pontos distintos; se $\mathcal R^m=I$, $P_m=P$, absurdo. (d) Se $\theta/\pi\in\mathbb{Q}$, alguma potência seria $I$; pelo teorema de Kronecker \[12\], a órbita é densa. ◻

**Outras duas provas de (c).** Por Niven \[11\]: $2\cos2\theta=12/7$ não é inteiro, logo $2\theta$ não é fração racional de volta. Por posto um módulo $7$: $M=91\mathcal R$ tem $M^2\equiv2M\not\equiv0\pmod7$, donde $M^n\equiv2^{n-1}M\not\equiv0$, enquanto $91^nI\equiv0$.

Os primeiros pontos são $(\tfrac12,1,\tfrac32)$, $(\tfrac37,\tfrac{17}{14},\tfrac{19}{14})$, $(\tfrac{23}{98},\tfrac{67}{49},\tfrac{123}{98})$, $(-\tfrac9{343},\tfrac{971}{686},\tfrac{839}{686})$. Até $n=2000$, a melhor aproximação ao fechamento é $n=778$, a $0{,}115^\circ$; em todo caso $1-\cos2n\theta$ é um racional exatamente positivo.

![Figura 7: A caixa $1\times2\times3$ em $\mathcal{S}$, o triângulo $-P,P',P$ (dourado), a diagonal $\sqrt{14}$ (vermelho), o eixo $a$ (verde) e o círculo $C$ com os pontos $P_0,\dots,P_{24}$; no detalhe, os doze primeiros passos.](fig_png/fig1_caixa_loop_3d_pt.png)

![Figura 8: O loop no plano de $C$: doze passos não fecham; dois mil pontos distintos enchem o círculo; o fechamento só pela meia-volta, que leva $P$ a $P'$ pelo centro.](fig_png/fig2_loop_plano_pt.png)

### 7.4 Critério geral do loop

**Teorema 14**. *Uma rotação de entradas racionais fecha o loop se e só se o seu traço está em $\{3,2,1,0,-1\}$ (ordens $1,6,4,3,2$).*

*Demonstração.* $2\cos\varphi=\operatorname{tr}-1$ é racional; se é inteiro algébrico, é inteiro em $[-2,2]$. ◻

  Rotação                                 $\operatorname{tr}$   $2\cos\varphi$    Fecha?
  -------------------------------------- --------------------- ---------------- -----------
  $T_{-1,3}$ \[1, seção 15.4\]                  $13/23$            $-10/23$        nunca
  $T_{1,1}$                                    $-11/15$            $-26/15$        nunca
  $M_3/3$, primeiro cubo pitagórico              $1/3$              $-2/3$         nunca
  $M_7/7$, meia-volta da diagonal                $-1$                $-2$        ordem $2$
  $\mathcal R$, cossecante $\sqrt{14}$          $19/7$              $12/7$         nunca
  $\mathcal R_b$, quatérnio da caixa            $-5/7$             $-12/7$         nunca
  Giro fixo da Espiral de Cot$\alpha$         $\sqrt2/2$        $-1+\sqrt2/2$      nunca

  : Tabela 1: Auditoria das rotações; a ordem prevista coincidiu com a busca direta até $60$ potências.

## 8. A saída pelo centro

### 8.1 Onde o loop fecha: pela meia-volta que passa pelo centro

**Proposição 15**. *Com $b=1+2j+3k$, o quatérnio das arestas da caixa, de norma $14$: $(13+2j+3k)(1+2j+3k)=14(2j+3k)$. Logo $\mathcal R\,\mathcal R_b=H=(2aa^{\mathsf T}-13I)/13$, a meia-volta em torno de $a$, com $HP=P'$, $H^2=I$: o loop fecha em quatro passos.*

*Demonstração.* Com $v=2j+3k$, $v^2=-13$, $(13+v)(1+v)=14v$; um quatérnio puro é uma meia-volta. $H$ é a ponte de eixo $P+P'=a$ \[1, Teorema C5\]. ◻

As tangentes dos meios-ângulos de $q$ e $b$ são $1/\sqrt{13}$ e $\sqrt{13}$, recíprocas; somam um quarto de volta, e a composição atravessa o centro do círculo $C$.

### 8.2 Tangentes externas e internas

**Proposição 16**. *Sejam $X=(2,3,6)$, $|X|^2=49$, e $T=(1,\tfrac32,-\tfrac12)$, vértice da caixa $2\times3\times1$ centrada na origem. Então $T\in\mathcal{S}$ e $T\cdot(X-T)=0$ (o raio $OT$ é perpendicular à tangente $XT$); a tangente externa $XT$ faz com o eixo $XO$ o ângulo de spread $1/14$, isto é, $\operatorname{cossec}\theta=\sqrt{14}$; o triângulo $O,T,X$ tem quadrâncias $7/2,\,91/2,\,49$, proporcionais a $1,13,14$; o ponto interno $X'=\rho X/|X|^2=X/14$ é o inverso de $X$, com $|OX'|\cdot|OX|=\tfrac12\cdot7=R^2$; e todas as tangentes de $X$ tocam $\mathcal{S}$ no círculo de centro $X'$ e raio $\sqrt{13}/2$, no plano polar $X\cdot Y=\rho$.*

*Demonstração.* $T\cdot T=T\cdot X=7/2$; o triângulo é retângulo em $T$ e $\operatorname{sen}^2\theta=(7/2)/49$; o raio do círculo de contato é $\sqrt{\rho-1/4}$. ◻

As tangentes *externas* saem de $X$, fora da bola, com cossecante $\sqrt{14}$ em relação ao eixo; o ponto *interno* $X'$ é o centro do seu círculo de contato. A inversão troca um pelo outro, com a mesma lei que leva a insfera do disfenoide, de raio $3/7$, à circunsfera polar, de raio $49/6$: $\tfrac37\cdot\tfrac{49}6=\tfrac72$ \[1, seção 21.6\]. O eixo $X\to X'\to O\to-X'\to-X$ atravessa o centro, e o salto $J=-I$ repete o cone do outro lado. Vistas ao longo do eixo, as tangentes externas são raios que saem do centro do círculo para fora.

![Figura 9: O cone das tangentes externas a $\mathcal{S}$ a partir de $X=(2,3,6)$, cossecante $\sqrt{14}$; círculo de contato de centro $X'=X/14$; o eixo atravessa o centro até $-X$.](fig_png/fig3_cone_tangentes_3d_pt.png)

![Figura 10: Seção pelo eixo e vista ao longo do eixo: $X$, $X'$ e $O$ caem no centro, e cada tangente externa vira um raio.](fig_png/fig4_secao_projecao_pt.png)

### 8.3 Seno zero, cossecante $1$ e cossecante $\sqrt{14}$

**Proposição 17**. *No triângulo $O,T,X$, com o eixo $OX$ como eixo $z$:*

*(a) **Seno zero é o do eixo.** Toda direção ao longo do eixo tem spread $0$ com ele; toda rotação em torno do eixo fixa-o ponto a ponto, e o movimento helicoidal $Y\mapsto\mathcal RY+a$ leva o eixo $a$ nele mesmo. Um ponto que se desloca no eixo $z$ gira com tudo e mantém seno zero; visto de cima, é o centro.*

*(b) **Cossecante $1$ é a do raio com a tangente:** $OT\perp XT$ em todo ponto de contato.*

*(c) **Cossecante $\sqrt{14}$ é a da tangente externa com o eixo:** $XT$ mede $\sqrt{91/2}$, avança $13/2$ no eixo e projeta-se no plano com $\sqrt{13}/2$, e $\operatorname{cossec}\theta=|XT|/(\text{projeção})=\sqrt{14}$.*

**Proposição 18**. *Nenhum ângulo tem ao mesmo tempo seno zero e cossecante $\sqrt{14}$ (nem cossecante $1$), pois $\operatorname{sen}\alpha\cdot\operatorname{cossec}\alpha=1$ sempre que a cossecante existe.*

As três afirmações da tese convivem no mesmo triângulo, mas pertencem a ângulos diferentes: o eixo tem seno zero, o raio faz cossecante $1$ com a tangente, a tangente externa faz cossecante $\sqrt{14}$ com o eixo. Na projeção sobre o plano $xy$, o eixo desaparece num ponto, e só a cossecante $1$ continua visível.

**A hélice.** $Y_n=\mathcal R^nP+n\,a$ sobe $13$ por passo no eixo ($Y_n\cdot a=13/2+13n$) e projeta-se na órbita do Teorema 13; cada passo tem corda de quadrância $1/14$ no plano e quadrância total $183/14$. A hélice não fecha no espaço, e sua projeção, o círculo, também não fecha.

![Figura 11: A hélice e sua projeção: o círculo plano é a sombra de um percurso que sobe no eixo $z$ e nunca se fecha.](fig_png/fig5_helice_pt.png)

**A via de saída do círculo.** As seções 5 a 8 mostram que o círculo plano é a sombra de sólidos e de percursos do espaço; que o seu centro é um segmento do eixo $z$; que o percurso pela cossecante $\sqrt{14}$ não fecha girando e fecha passando pelo centro; e que o ponto externo $X$, de onde partem as tangentes de cossecante $\sqrt{14}$, e o ponto interno $X'$ se trocam pela inversão ao longo do mesmo eixo. A saída do círculo tem, assim, três direções exatas: para cima, pela hélice, em que a altura cresce sem voltar; pelo centro, pelo eixo $z$ de medida $\sqrt{14}$; e para fora, pela espiral de lado $1$ das seções seguintes, que nunca volta a um círculo já lido.

**Sem $\pi$ e sem raízes.** Nas contas das seções 4 a 8, nenhuma usa $\pi$ ou a extração da raiz quadrada de um inteiro que não seja quadrado perfeito. Comprimentos como $7/\sqrt2$ ou $\sqrt{14}$ aparecem só como nomes; o que se calcula são as quadrâncias $49/2$ e $14$. Ângulos são spreads racionais ($0$, $1$, $1/2$, $1/14$), rotações têm entradas racionais, e todo certificado é uma igualdade entre inteiros ou frações. O número $\pi$ aparece só para dizer que o ângulo do giro não é fração racional de volta (Teorema 13) e, na seção 10, como a medida do afastamento entre as voltas da espiral.

## 9. A espiral de Teodoro: o círculo de lado 1

**Linguagem.** A quadrância de um vetor $u=(x,y)$ é $\operatorname{Q}(u)=x^2+y^2$; entre dois pontos $P$ e $R$ é $\operatorname{Q}(P-R)$. O spread entre vetores não nulos $u$ e $w$ é $s(u,w)=(u\times w)^2/(\operatorname{Q}(u)\operatorname{Q}(w))$, com $u\times w=x_uy_w-y_ux_w$; é o quadrado do seno do ângulo entre eles e é racional sempre que as coordenadas o são \[6\]. Nessa linguagem, o teorema de Pitágoras diz que o ângulo em $B$ do triângulo $ABC$ é reto se e só se $\operatorname{Q}(AB)+\operatorname{Q}(BC)=\operatorname{Q}(AC)$; num triângulo retângulo, o spread de um ângulo agudo é a quadrância do lado oposto dividida pela quadrância da hipotenusa.

**Definição 1**. Seja $J(x,y)=(-y,x)$ o giro de um ângulo reto. A espiral de Teodoro é a poligonal $O,v_1,v_2,\dots$ com $$v_1=(1,0),\qquad v_{N+1}=v_N+\frac{J v_N}{\sqrt N}\quad(N\ge1).$$ O primeiro segmento é $Ov_1$; o $N$-ésimo segmento termina em $v_N$. Assim, $N$ é o número de segmentos de lado $1$ percorridos até $v_N$.

**Teorema 19** (lado sempre $1$, quadrância $N$). *Para todo $N\ge1$: $\operatorname{Q}(v_N)=N$; o passo $v_{N+1}-v_N$ tem quadrância $1$ e é perpendicular a $v_N$. Na forma complexa, $z_N=\prod_{k=1}^{N-1}\bigl(1+i/\sqrt k\bigr)$ e $$\operatorname{Q}(v_N)=\prod_{k=1}^{N-1}\left(1+\frac1k\right)=\prod_{k=1}^{N-1}\frac{k+1}{k}=N .$$*

*Demonstração.* Para todo vetor $v$, $\operatorname{Q}(Jv)=\operatorname{Q}(v)$ e $v\cdot Jv=0$. Se $\operatorname{Q}(v_N)=N$, então $\operatorname{Q}(v_{N+1})=\operatorname{Q}(v_N)+\operatorname{Q}(Jv_N)/N+2\,v_N\cdot Jv_N/\sqrt N=N+1+0$; como $\operatorname{Q}(v_1)=1$, a indução dá $\operatorname{Q}(v_N)=N$ para todo $N$. O passo $Jv_N/\sqrt N$ tem quadrância $N/N=1$ e é perpendicular a $v_N$. Na forma complexa, $v_{N+1}=v_N(1+i/\sqrt N)$, e o produto das quadrâncias $1+1/k=(k+1)/k$ telescopa em $N$. ◻

As coordenadas de $v_N$ contêm raízes, mas nenhuma delas precisa ser calculada: a raiz aparece só como nome, e o que se calcula é a quadrância, o inteiro $N$.

**Teorema 20** (os três spreads). *O triângulo $O\,v_N\,v_{N+1}$ tem quadrâncias $N$, $1$ e $N+1$, e $\operatorname{Q}(Ov_N)+\operatorname{Q}(v_Nv_{N+1})=N+1=\operatorname{Q}(Ov_{N+1})$ (ângulo reto em $v_N$). Os seus spreads são $1$ em $v_N$, $1/(N+1)$ no centro $O$ e $N/(N+1)$ em $v_{N+1}$. O ângulo $\theta_N$ no centro tem $\operatorname{cossec}^2\theta_N=N+1$ e cotangente ao quadrado igual a $N$. No triângulo $13$, o spread no centro é $1/14$ e a cossecante é $\sqrt{14}$: é o triângulo $1,\sqrt{13},\sqrt{14}$ da seção 4.*

*Demonstração.* Pelo Teorema 19 e por Pitágoras. No centro, o lado oposto é o passo, de quadrância $1$; em $v_{N+1}$, o lado oposto é o raio $Ov_N$, de quadrância $N$; ambos se dividem pela hipotenusa, de quadrância $N+1$. A soma $1/(N+1)+N/(N+1)=1$ é a dos dois ângulos agudos de um triângulo retângulo. ◻

**Proposição 21** (tangente e potência de ponto). *Seja $C_N$ o círculo $x^2+y^2=N$. O passo que sai de $v_N$ é tangente a $C_N$ em $v_N$ e termina em $C_{N+1}$. A potência do ponto $v_M$ em relação a $C_N$ é o inteiro $M-N$; em particular, o segmento tangente de $v_{N+1}$ a $C_N$ tem quadrância $1$: o passo de lado $1$ é exatamente a tangente traçada do ponto novo ao círculo anterior.*

*Demonstração.* A reta perpendicular ao raio no ponto do círculo é a tangente. A potência de um ponto $P$ em relação a um círculo de centro $O$ e quadrância $r$ é $\operatorname{Q}(P)-r$; quando $P$ está fora do círculo ou sobre ele, ela é igual à quadrância do segmento tangente. Para $P=v_M$ e $r=N$, vale $M-N$, e o caso $M\ge N$ é o do segmento tangente. ◻

**Proposição 22** (a espiral não fecha). *No ponto $v_N+t\,u_N$ do passo $u_N=v_{N+1}-v_N$, com $0\le t\le1$, a quadrância ao centro é $N+t^2$. Logo, ao longo da poligonal, a quadrância cresce estritamente: a espiral cruza cada círculo $x^2+y^2=r$, $r\ge1$, uma única vez, nenhum ponto se repete e nenhum loop se fecha.*

*Demonstração.* $\operatorname{Q}(v_N+tu_N)=\operatorname{Q}(v_N)+2t\,v_N\cdot u_N+t^2\operatorname{Q}(u_N)=N+0+t^2$. A função é contínua e estritamente crescente em cada passo e vale $N+1$ no fim do passo $N$, que é o início do passo $N+1$; é, portanto, estritamente crescente em toda a poligonal, de $1$ ao infinito. ◻

Como conjunto de pontos, cada círculo $C_N$ é uma curva fechada; o que não fecha é o caminho que os lê. Mais forte ainda, Teuffel demonstrou em 1958 que duas hipotenusas da espiral nunca estão na mesma reta, por mais que ela continue \[14, 15\]: nem os pontos nem as direções se repetem.

**Proposição 23** (quadrados perfeitos). *A distância de $v_N$ ao centro é racional se e só se $N$ é quadrado perfeito, e então é o inteiro $k=\sqrt N$. Os pontos $v_1,v_4,v_9,v_{16},\dots$ são exatamente os pontos da espiral sobre círculos de raio inteiro $1,2,3,4,\dots$*

*Demonstração.* Se $\sqrt N=a/b$ em termos mínimos, então $Nb^2=a^2$; como $\operatorname{mdc}(a,b)=1$, $b^2$ divide $1$, e $N=a^2$. ◻

Em quadrância, todos os pontos da espiral são exatos, pois são inteiros; em distância, só os quadrados perfeitos o são. Essa é a via dos quadrados perfeitos dentro da própria espiral.

![Figura 12: A espiral de Teodoro pela quadrância. (a) Os $16$ triângulos de lado $1$ até a hipotenusa $\sqrt{17}$ somam $351{,}15^\circ$; o $17^{\circ}$ passaria de uma volta (certificado T8). O número junto a cada ponto é a sua quadrância $N$, o número de segmentos de lado $1$; os círculos dourados têm raio inteiro (quadrados perfeitos $1$, $4$, $9$, $16$). Em roxo, o triângulo $13$, de cossecante $\sqrt{14}$. (b) Cada passo é tangente ao círculo $x^2+y^2=N$ e termina no círculo $x^2+y^2=N+1$; a potência de $v_{N+1}$ em relação ao círculo $N$ é $1$. (c) A fileira de $n$ quadrados usa $3n+1$ segmentos de lado $1$.](fig_png/fig14_teodoro_circulos_pt.png)

## 10. O significado geométrico: a espiral como forma de entender o círculo

No desenho plano, um círculo é uma curva fechada. A espiral de Teodoro lê a família de círculos $x^2+y^2=N$ de outro modo: cada círculo é tocado num único ponto, por um passo tangente de lado $1$, e a figura segue para o círculo seguinte. Esta seção demonstra quatro leituras dessa ideia.

### 10.1 Por que o lado sempre 1

\(a\) O lado $1$ transforma contagem em geometria. Cada passo soma exatamente $1$ à quadrância, de modo que depois de $N$ passos a quadrância é $N$: o contador inteiro e a medida geométrica são o mesmo número, e o teorema de Pitágoras vira a soma $N+1$.

\(b\) O $1$ é o único comprimento positivo igual à própria quadrância, pois $1^2=1$: o lado e a área do quadrado unitário coincidem, e a unidade não precisa de raiz.

\(c\) Com o lado $1$, todo ângulo de cada triângulo da espiral é racional em spread: $1/(N+1)$, $N/(N+1)$ e $1$.

\(d\) A regra é a mesma em todos os passos, uma unidade perpendicular ao raio, sem medir ângulo algum e sem $\pi$.

### 10.2 A planificação das diagonais dos cubos

**Teorema 24** (planificação). *Sejam $e_1,e_2,\dots$ os vetores unitários dos eixos e $d_N=e_1+\dots+e_N$ a diagonal do cubo unitário de dimensão $N$. O triângulo $(0,d_N,d_{N+1})$ é congruente ao triângulo de Teodoro $(O,v_N,v_{N+1})$, e dois triângulos consecutivos têm em comum o lado de quadrância $N+1$, que é $0\,d_{N+1}$ no espaço e $Ov_{N+1}$ no plano. A espiral de Teodoro é, portanto, a planificação, no plano, do leque de triângulos formados pela diagonal do cubo de dimensão $N$, por uma aresta nova de lado $1$, perpendicular a todas as anteriores, e pela diagonal do cubo de dimensão $N+1$. Se $N=a^2+b^2$, o triângulo $N$ já existe no espaço comum: é o triângulo de vértices $(0,0,0)$, $(a,b,0)$, $(a,b,1)$ da caixa $a\times b\times1$, formado pela diagonal de uma face, pela aresta de lado $1$ e pela diagonal do espaço.*

*Demonstração.* $\operatorname{Q}(d_N)=N$, $\operatorname{Q}(d_{N+1}-d_N)=\operatorname{Q}(e_{N+1})=1$ e $d_N\cdot e_{N+1}=0$: as três quadrâncias são $N$, $1$, $N+1$, com ângulo reto em $d_N$, as mesmas do triângulo de Teodoro, e três quadrâncias determinam o triângulo a menos de isometria. Girando cada triângulo em torno do lado comum até o plano do anterior, do lado oposto a ele, o leque se abre no plano sem mudar nenhuma quadrância: é a planificação. Na caixa, $\operatorname{Q}(a,b,0)=N$, $\operatorname{Q}(0,0,1)=1$, $(a,b,0)\cdot(0,0,1)=0$ e $\operatorname{Q}(a,b,1)=N+1$. ◻

Os dois primeiros triângulos da espiral estão dentro do cubo unitário comum: o triângulo $1$ numa face, com $(1,0,0)\to(1,1,0)$, e o triângulo $2$ atravessando o cubo, com a diagonal da face $(1,1,0)$, a aresta vertical e a diagonal do cubo $(1,1,1)$, de quadrância $3$. O triângulo $13$, como $13=2^2+3^2$, é o da caixa $2\times3\times1$: diagonal da face $\sqrt{13}$, aresta $1$ e diagonal do espaço $\sqrt{14}$, a caixa da seção 4. Cada passo de lado $1$ pede uma direção nova, perpendicular a tudo o que veio antes. No espaço de muitas dimensões há direções novas de sobra; no plano só há uma direção perpendicular ao raio, e a espiral gira. A espiral é o que a escada de dimensões deixa no plano.

### 10.3 A progressão de quadrados inscritos e circunscritos

O autor observou que cada raio da espiral nos níveis $2^j$ é aresta ou diagonal de um quadrado inscrito ou circunscrito, e que o ponto inicial é o vértice de uma progressão infinita de quadrados inscritos e circunscritos nos círculos. O teorema seguinte dá a essa observação a forma exata.

Para $j\ge0$, seja $C_j^\ast$ o círculo $x^2+y^2=2^j$ e seja $S_j$ o quadrado de vértices $$(\pm2^m,0),\ (0,\pm2^m)\ \text{ se } j=2m,\qquad (\pm2^m,\pm2^m)\ \text{ se } j=2m+1 .$$

**Teorema 25** (progressão de quadrados). *Para todo $j\ge1$:*

*(i) $S_j$ está inscrito em $C_j^\ast$ e circunscrito a $C_{j-1}^\ast$, e os seus quatro lados tocam $C_{j-1}^\ast$ exatamente nos quatro vértices de $S_{j-1}$;*

*(ii) o lado de $S_j$ tem quadrância $2^{j+1}$, a meia diagonal tem quadrância $2^j$ e o apótema tem quadrância $2^{j-1}$; assim, o raio de $C_j^\ast$ é, ao mesmo tempo, o lado de $S_{j-1}$, a meia diagonal de $S_j$ e o meio lado de $S_{j+1}$;*

*(iii) os vértices de $S_j$ são pontos inteiros: nos eixos quando $j$ é par, com raio inteiro $2^{j/2}$ (quadrância $4^m$, quadrado perfeito), e nas diagonais quando $j$ é ímpar, com raio $2^m\sqrt2$ (quadrância $2\cdot4^m$);*

*(iv) o início da espiral de Teodoro é o início da progressão: $v_1=(1,0)$ é vértice de $S_0$ e o ponto em que um lado de $S_1$ toca $C_0^\ast$; $v_2=(1,1)$ é vértice de $S_1$; o primeiro passo é meio lado de $S_1$, e o primeiro triângulo $O\,v_1\,v_2$ é um oitavo de $S_1$;*

*(v) cada ponto $v_{2^j}$ da espiral está em $C_j^\ast$, e o quadrado obtido girando $S_j$ em torno de $O$ até um vértice cair em $v_{2^j}$ continua inscrito em $C_j^\ast$ e circunscrito a $C_{j-1}^\ast$.*

*A progressão continua sem fim para fora e também para dentro, nos círculos de quadrância $1/2,1/4,\dots$, em direção ao centro.*

*Demonstração.* (i) Se $j=2m+1$, os lados são as retas $x=\pm2^m$ e $y=\pm2^m$, à distância $2^m$ do centro, e tocam o círculo de quadrância $4^m=2^{j-1}$ em $(\pm2^m,0)$ e $(0,\pm2^m)$, os vértices de $S_{2m}$. Se $j=2m$, os lados são as retas $|x|+|y|=2^m$, cuja distância ao centro tem quadrância $(2^m)^2/2=2^{j-1}$; o pé da perpendicular do centro à reta $x+y=2^m$ é $(2^{m-1},2^{m-1})$, vértice de $S_{2m-1}$, e o mesmo vale, por simetria, nos outros lados. (ii) Para $j=2m+1$, o lado vai de $(2^m,2^m)$ a $(-2^m,2^m)$ e tem quadrância $4^{m+1}=2^{j+1}$; para $j=2m$, vai de $(2^m,0)$ a $(0,2^m)$ e tem quadrância $2\cdot4^m=2^{j+1}$. A meia diagonal é o raio, de quadrância $2^j$, e o apótema é a distância do item (i), de quadrância $2^{j-1}$. O lado de $S_{j-1}$ tem quadrância $2^{j}$, igual à do raio de $C_j^\ast$, e o meio lado de $S_{j+1}$ tem quadrância $2^{j+2}/4=2^j$. (iii) Leitura direta das coordenadas. (iv) Pela definição, $v_2=v_1+Jv_1=(1,1)$; o segmento de $(1,0)$ a $(1,1)$ é metade do lado $x=1$ de $S_1$, e os triângulos $O$, $(\pm1,0)$ ou $(0,\pm1)$, $(\pm1,\pm1)$ dividem $S_1$ em oito partes iguais. (v) $\operatorname{Q}(v_{2^j})=2^j$ pelo Teorema 19, e o giro em torno de $O$ preserva as quadrâncias ao centro e as distâncias aos lados. ◻

**Corolário 26** (o passo par é o Mênon ao contrário). *Para todo $n\ge1$, o quadrado inscrito no círculo $x^2+y^2=n$ tem lado de quadrância $2n$ e apótema de quadrância $n/2$; logo o círculo inscrito no quadrado inscrito em $x^2+y^2=n$ é o círculo $x^2+y^2=n/2$. Para $n$ par, o passo $n\to n/2$ do problema $3n+1$ leva o círculo de $v_n$ ao círculo inscrito no seu quadrado inscrito, e o passo $n\to 2n$ faz o caminho inverso, que é a construção do Mênon: o quadrado sobre a diagonal tem o dobro da área \[2\]. Para $m$ ímpar, chame de progressão de quadrados do círculo $x^2+y^2=m$ a sequência dos círculos $x^2+y^2=2^a m$, $a\ge0$, em que cada círculo é o inscrito no quadrado inscrito no seguinte. Todo inteiro $n=2^a m$, com $m$ ímpar, está no nível $a$ da progressão do seu ímpar $m$, e as divisões por $2$ descem essa progressão até a base $m$; a progressão do ponto inicial é a de $m=1$.*

*Demonstração.* No quadrado inscrito, a meia diagonal tem quadrância $n$, o lado tem quadrância $2n$ e o apótema, que é meio lado, tem quadrância $2n/4=n/2$, qualquer que seja o giro do quadrado. ◻

![Figura 13: A progressão de quadrados inscritos e circunscritos (Teorema 25). (a) Quadrados $S_0$ a $S_6$ nos círculos $x^2+y^2=2^j$: nos níveis pares (dourado) os vértices estão nos eixos e o raio é inteiro; nos ímpares (roxo), estão nas diagonais. Os pontos pretos são os pontos $v_{2^j}$ da espiral de Teodoro, e o quadrado vermelho é o ponto inicial $(1,0)$. (b) O primeiro triângulo da espiral é um oitavo de $S_1$. (c) O passo par $n\to n/2$ leva o círculo $x^2+y^2=n$ ao círculo inscrito no seu quadrado inscrito.](fig_png/fig15_progressao_quadrados_pt.png)

### 10.4 A elevação: a altura é a quadrância

**Teorema 27** (paraboloide). *Eleve cada ponto $v_N$ ao ponto $V_N=(v_N,N)$ do espaço. Então:*

*(i) $V_N$ está no paraboloide $z=x^2+y^2$, e o círculo $C_N$ é a sombra, no plano $xy$, da seção horizontal do paraboloide na altura $N$;*

*(ii) cada passo elevado $V_N\to V_{N+1}$ anda $1$ na horizontal e sobe $1$ na vertical: tem quadrância $2$ e spread $1/2$ com o plano $xy$, isto é, inclinação de $45^\circ$;*

*(iii) a altura cresce $1$ a cada passo e nunca volta: no espaço, a espiral é uma rampa de $45^\circ$; a espiral plana é a sua sombra, e os círculos são as sombras dos seus níveis. Planificada ao longo do próprio caminho horizontal, a rampa é a reta $z=s+1$, de inclinação $1$.*

*Demonstração.* (i) $z=N=\operatorname{Q}(v_N)$ pelo Teorema 19. (ii) O deslocamento horizontal $v_{N+1}-v_N$ tem quadrância $1$, e o vertical, $(N+1)-N=1$; o spread com o plano é a quadrância vertical sobre a total, $1/2$. (iii) A altura $N$ é estritamente crescente; depois de $s$ passos o caminho horizontal mede $s$ e a altura é $s+1$. ◻

É o mesmo ângulo de $45^\circ$ com que as arestas laterais do tetraedro regular atravessam o círculo (Teorema 6), e é a mesma situação da hélice da seção 8: o círculo plano é a sombra de um caminho que sobe.

### 10.5 A volta que não fecha e o número $\pi$

**Proposição 28** (afastamento entre voltas). *Seja $\varphi_N=\sum_{k=1}^{N-1}\arctan(1/\sqrt k)$ o ângulo percorrido de $v_1$ até $v_N$. Então $\varphi_N=2\sqrt N+K+O(N^{-1/2})$ para uma constante $K$ (numericamente, $K\approx-2{,}1578$). Consequentemente, numa semirreta qualquer a partir do centro, os raios em que a espiral a cruza em voltas consecutivas diferem de $\pi+O(N^{-1/2})$: assintoticamente, a espiral é a de Arquimedes $r\approx(\varphi-K)/2$, e cada volta se afasta da anterior por $\pi$.*

*Demonstração.* Para $0<x\le1$, $0<x-\arctan x<x^3/3$. Logo $\varphi_N=\sum_{k<N}k^{-1/2}-\sum_{k<N}\varepsilon_k$, com $0<\varepsilon_k<k^{-3/2}/3$; a segunda série converge e o seu resto depois de $N$ é $O(N^{-1/2})$. Pela fórmula de Euler–Maclaurin, $\sum_{k\le x}k^{-1/2}=2\sqrt x+\zeta(1/2)+O(x^{-1/2})$ \[16, Teorema 3.2(b)\]; com $x=N-1$, e como $2\sqrt N-2\sqrt{N-1}=O(N^{-1/2})$, vem $\varphi_N=2\sqrt N+K+O(N^{-1/2})$, com $K=\zeta(1/2)-\sum_{k\ge1}\varepsilon_k$. Ao longo de cada passo o ângulo polar cresce estritamente: no ponto $v_N+t\,u_N$ ele excede o de $v_N$ em $\arctan(t/\sqrt N)$; assim, cada semirreta é cruzada uma vez por volta. Numa semirreta de direção $\alpha$, os cruzamentos ocorrem quando $\varphi=\alpha+2\pi m$; entre dois cruzamentos consecutivos, $2\sqrt N$ cresce $2\pi+O(N^{-1/2})$, e o raio cresce $\pi+O(N^{-1/2})$. Dentro de um passo, o raio varia menos que $\sqrt{N+1}-\sqrt N<1/(2\sqrt N)$, o que não altera a conclusão. ◻

O número $\pi$ não entra na construção, que só usa a unidade e o ângulo reto. Ele aparece como medida do quanto uma volta deixa de fechar. A Figura 14(c) mostra o cálculo numérico com $4\cdot10^6$ segmentos: o afastamento ao longo da semirreta do ponto inicial começa em $3{,}176$ e, depois de $636$ voltas, está em $3{,}1416$.

**A figura do Teeteto.** Platão conta que Teodoro demonstrou que os lados dos quadrados de área $3,5,\dots$ são incomensuráveis com a unidade, caso a caso, “até o de dezessete pés, e ali, de algum modo, se deteve” \[5\]. A espiral é uma reconstrução moderna de como ele pode ter feito as figuras \[13\]. O fato geométrico é exato: os $16$ triângulos até a hipotenusa $\sqrt{17}$ somam $351{,}150420^\circ$, menos de uma volta, e os $17$ triângulos até $\sqrt{18}$ somam $364{,}783442^\circ$, mais de uma volta. Até $\sqrt{17}$ a figura cabe numa volta sem se sobrepor; com o triângulo seguinte, não cabe. O certificado T8 prova as duas desigualdades com limites racionais rigorosos para cada arco-tangente (série alternada) e para $\pi$ (fórmula de Machin).

![Figura 14: (a) Elevada ao paraboloide $z=x^2+y^2$, com a altura igual à quadrância, a espiral é uma rampa de $45^\circ$; a figura plana é a sombra (Teorema 27). (b) Com $1000$ segmentos, a espiral não fecha: cada volta cruza a semirreta do ponto inicial mais longe que a anterior. (c) O afastamento entre voltas consecutivas tende a $\pi$; cálculo numérico com $4\cdot10^6$ segmentos, ilustrando a Proposição 28.](fig_png/fig16_teodoro_paraboloide_pt.png)

### 10.6 Os passos de Teodoro como giros

**Teorema 29**. *O passo de Teodoro $n\to n+1$ ($\operatorname{cossec}\theta_n=\sqrt{n+1}$, $\cos2\theta_n=\frac{n-1}{n+1}$), repetido como giro, fecha o loop se e só se $n=1$ (giro de $90^\circ$, quatro passos) ou $n=3$ ($60^\circ$, seis passos). Para $n=13$, cossecante $\sqrt{14}$, nunca fecha.*

*Demonstração.* $2\cos2\theta_n$ deve ser inteiro: $(n+1)\mid 2(n-1)$, isto é, $(n+1)\mid4$. ◻

No octaedro $\mathcal O_7$, os quatro tetraedros $\operatorname{conv}\{P,-P,\pm u_2,\pm u_3\}$ em torno do eixo $\sqrt{14}$ têm a dobra $7+7=14$, o passo $1\to2$, e fecham exatamente (diedro reto). Na face do tetraedro regular de aresta $\sqrt7$, a altura dá o triângulo $1,\sqrt3,2$, o passo $3\to4$, e seis faces fecham em $60^\circ$. O diedro do tetraedro regular tem $\cos\delta=1/3$; $T_k(1/3)$ tem denominador $3^k$ e nunca vale $1$: cinco tetraedros em torno de uma aresta deixam a fenda $\cos5\delta=241/243$.

![Figura 15: Os passos de Teodoro como giros: $n=1$ fecha num quadrado, $n=3$ num hexágono, $n=13$ nunca fecha.](fig_png/fig6_teodoro_fecha_pt.png)

![Figura 16: Quatro tetraedros em torno do eixo $\sqrt{14}$ fecham o octaedro; cinco tetraedros regulares em torno de uma aresta não fecham.](fig_png/fig7_tetraedros_pt.png)

## 11. O problema $3n+1$ na linguagem de Teodoro

Seja $T(n)=n/2$ se $n$ é par e $T(n)=3n+1$ se $n$ é ímpar. A conjectura de Collatz afirma que, para todo inteiro $n\ge1$, alguma iterada de $T$ vale $1$; daí em diante a trajetória repete o loop $1\to4\to2\to1$. Ela foi verificada por computador até $2^{71}\approx2{,}36\cdot10^{21}$ \[21\]; a história do problema e os resultados gerais conhecidos estão em \[17, 18, 19, 20\]. Com a observação do autor de que $N$ é o número de segmentos de lado $1$, cada número vira um ponto da espiral, e cada passo de $T$ vira uma operação geométrica (Tabela 2).

  Problema $3n+1$          Espiral de Teodoro
  ------------------------ -----------------------------------------------------------------------
  valor $n$                ponto $v_n$, fim do $n$-ésimo segmento de lado $1$, na quadrância $n$
  valor $1$                ponto inicial $v_1=(1,0)$, o primeiro segmento
  passo par $n\to n/2$     do círculo ao círculo inscrito no seu quadrado inscrito
  passo ímpar $n\to3n+1$   os $3n+1$ segmentos de uma fileira de $n$ quadrados
  potências de $2$         círculos $x^2+y^2=2^j$ da progressão do ponto inicial
  quadrados perfeitos      círculos de raio inteiro
  loop $1\to4\to2\to1$     níveis $0$, $2$ e $1$ da progressão: raios $1$, $2$ e $\sqrt2$

  : Tabela 2: Dicionário entre o problema $3n+1$ e a espiral de Teodoro.

**Proposição 30** (palitos). *Uma fileira de $n$ quadrados de lado $1$ tem exatamente $3n+1$ segmentos de lado $1$ ($2n$ horizontais e $n+1$ verticais), $2n+2$ vértices e $n+1$ faces contando a externa, e satisfaz a relação de Euler $V-A+F=2$.*

*Demonstração.* Contagem direta: $(2n+2)-(3n+1)+(n+1)=2$. ◻

Com o dicionário, cada trajetória do problema $3n+1$ vira um caminho exato entre círculos da espiral, medido em números inteiros.

## 12. O teorema da porta pelo quadrado perfeito

**Teorema 31** (porta). *Seja $n\ge1$ um número que não é potência de $2$, cuja trajetória chega a $1$. Seja $2^j$ a primeira potência de $2$ da trajetória e $p$ o termo anterior. Então $p$ é ímpar, $3p+1=2^j$, $j$ é par, $j=2k$ com $k\ge2$, e $p=(4^k-1)/3$. A trajetória entra na descida final pelo quadrado perfeito $4^k=(2^k)^2$, vindo do ímpar $(4^k-1)/3\in\{5,21,85,341,\dots\}$.*

*Demonstração.* Como $n$ não é potência de $2$ e a trajetória chega a $1=2^0$, existe um primeiro termo que é potência de $2$, e ele tem um antecessor $p$ que não é potência de $2$. Se $p$ fosse par, seria $p=2\cdot2^j$, potência de $2$; logo $p$ é ímpar e $3p+1=2^j$. Módulo $3$, $2^j\equiv1$; como $2\equiv-1$, isso exige $(-1)^j=1$, isto é, $j$ par, $j=2k$. Como $p$ é ímpar e não é potência de $2$, $p\ge3$, e então $4^k=3p+1\ge10$, isto é, $k\ge2$. Por fim, $p=(4^k-1)/3$. ◻

**Corolário 32** (a última subida termina em raio inteiro). *Seja $n$ como no Teorema 31. No plano de Teodoro, o último passo ímpar antes de a trajetória chegar a $1$ pela primeira vez salta de $v_p$ para $v_{4^k}$, sobre o círculo de raio inteiro $2^k$, que é o nível $2k$ da progressão de quadrados do ponto inicial, um nível par, cujo quadrado $S_{2k}$ tem os vértices nos eixos. Daí, as $2k$ divisões por $2$ descem a progressão $S_{2k},S_{2k-1},\dots,S_0$, alternando círculos de raio inteiro $2^m$ e círculos de raio $2^m\sqrt2$, até o ponto inicial $(1,0)$. Cada degrau é o Mênon ao contrário (Corolário 26).*

*Demonstração.* Teorema 31, Teorema 25 e Corolário 26. ◻

**Teorema 33** (portas raras). *Seja $p_k=(4^k-1)/3$. Então $p_k\equiv k\pmod 3$. Se $3\mid k$, os números que entram pela porta $4^k$ são exatamente os números $p_k\cdot2^a$, $a\ge0$; logo, entre $1$ e $N$, exatamente $\lfloor\log_2(N/p_k)\rfloor+1$ números usam a porta $4^k$, quando $p_k\le N$.*

*Demonstração.* $p_k=1+4+\dots+4^{k-1}\equiv k\pmod3$, porque $4\equiv1$. Se $3\mid k$, todo $x=p_k2^a$ é múltiplo de $3$; um antecessor ímpar $y$ de $x$ exigiria $3y+1=x\equiv0\pmod3$, o que é impossível, e o único antecessor de $x$ é $2x$. Assim, a árvore dos antecessores de $p_k$ é a cadeia $p_k2^a$. Pelo Teorema 31, todo número que entra pela porta $4^k$ passa por $p_k$ e está nessa árvore; reciprocamente, cada $p_k2^a$ desce por divisões até $p_k$, sem encontrar potência de $2$, pois $p_k$ é ímpar e maior que $1$, e entra por $4^k$. A contagem é a dos $a\ge0$ com $p_k2^a\le N$. ◻

Os fatos aritméticos dos Teoremas 31 e 33, isto é, que o último ímpar antes da descida final é $(4^k-1)/3$ e que os múltiplos de $3$ não têm antecessor ímpar, são conhecidos no estudo da árvore de antecessores do problema $3x+1$ \[17\]. O que se acrescenta aqui é a leitura geométrica: a porta é um quadrado perfeito, um círculo de raio inteiro no nível par da progressão de quadrados do ponto inicial.

    porta $4^k$   antecessor $(4^k-1)/3$   números $n\le10^9$    previsão
  ------------- ------------------------ -------------------- -----------
       $4^2=16$                      $5$      $937\,695\,288$ 
       $4^3=64$                     $21$                 $26$        $26$
      $4^4=256$                     $85$       $23\,754\,817$ 
     $4^5=1024$                    $341$       $37\,947\,841$ 
     $4^6=4096$                   $1365$                 $20$        $20$
          $4^7$                   $5461$            $80\,772$ 
          $4^8$                $21\,845$           $486\,049$ 
          $4^9$                $87\,381$                 $14$        $14$
       $4^{10}$               $349\,525$            $32\,534$ 
       $4^{11}$            $1\,398\,101$             $2\,106$ 
       $4^{12}$            $5\,592\,405$                  $8$         $8$
       $4^{13}$           $22\,369\,621$                $395$ 
       $4^{14}$           $89\,478\,485$                 $98$ 
       $4^{15}$          $357\,913\,941$                  $2$         $2$
          total                               $999\,999\,970$   $10^9-30$

  : Tabela 3: Portas de todos os $n\le10^9$ que não são potências de $2$ (programa `porta_quadrado.c`, inteiros exatos de $128$ bits, sem falhas e sem estouros). As linhas com previsão são as portas raras do Teorema 33; a previsão coincide com a contagem.

A porta $16=4^2$ recebe $93{,}77\%$ dos números até $10^9$; todas as portas observadas são potências $4^k$ com $k\ge2$, como exige o Teorema 31, e o total é $10^9-30$, porque as $30$ potências de $2$ até $10^9$ estão excluídas.

**Proposição 34** (reformulação equivalente). *A conjectura de Collatz é equivalente a: todo $n\ge1$ que não é potência de $2$ alcança, na sua trajetória, algum dos ímpares $p_k=(4^k-1)/3$, $k\ge2$ ($5$, $21$, $85$, $341$, …). Na linguagem de Teodoro: toda trajetória alcança a progressão de quadrados do ponto inicial, e o faz por um nível par, um círculo de raio inteiro.*

*Demonstração.* Se a conjectura vale, o Teorema 31 dá o ímpar $p_k$. Reciprocamente, de $p_k$ a trajetória vai a $4^k$ e desce por divisões até $1$. ◻

Na linguagem de Teodoro, portanto, a conjectura de Collatz é a afirmação de que toda trajetória, saltando entre progressões de quadrados, chega à progressão do ponto inicial.

## 13. A proposta de solução do autor

Esta seção registra a proposta do autor, construída sobre os resultados demonstrados nas seções anteriores. Os enunciados matemáticos que ela usa estão demonstrados no artigo; a proposta é a leitura do autor sobre eles.

**Proposta do autor 1**. (1) Cada número $N$ é o ponto $v_N$ da espiral de lado $1$, na quadrância $N$, e cada trajetória do problema $3n+1$ é um caminho exato entre os círculos da espiral (seção 11).

\(2\) Voltar a $1$ é voltar ao ponto inicial, o vértice da progressão de quadrados. Para o autor, voltar a $1$ é o mesmo que verificar se se chegou ao seno igual a $1$; e, como o círculo fechado é uma projeção, não existe seno igual a $1$ no centro: sob a ótica geométrica e trigonométrica, há a via de saída pelo centro, pela cossecante $\sqrt{14}$.

\(3\) Os fatos demonstrados que sustentam essa leitura: o centro do círculo plano é um segmento do eixo $z$ (Teoremas 4 e 9); o giro da cossecante $\sqrt{14}$ não fecha, e o percurso fecha pela meia-volta que passa pelo centro (Teorema 13 e Proposição 15); o ponto externo de onde partem as tangentes e o ponto interno se trocam pela inversão (Proposição 16); na espiral, o spread no centro é $1/(N+1)$, nunca $1$, e o ângulo reto fica no ponto de tangência, de onde o passo segue para fora (Teorema 20); a espiral não fecha e sobe no espaço (Proposição 22 e Teorema 27).

\(4\) O passo par desce a progressão de quadrados (Corolário 26), o passo ímpar $N\to3N+1$ conta os $3N+1$ segmentos de uma fileira de $N$ quadrados (Proposição 30), e, para os números que não são potências de $2$, a entrada na descida final se dá sempre por um quadrado perfeito, num círculo de raio inteiro (Teorema 31 e Corolário 32).

\(5\) Pela via dos quadrados perfeitos, o autor conclui que o caminho de toda trajetória sai do círculo, alcança a porta pelo quadrado perfeito e desce a progressão até o ponto inicial (se o número inicial é potência de $2$, a trajetória já está nessa progressão); esta é a sua proposta de solução da conjectura de Collatz, que ele submete à avaliação.

Na forma da Proposição 34, a proposta afirma que a trajetória de todo número que não é potência de $2$ alcança uma das portas $4^k$, $k\ge2$, isto é, a progressão de quadrados do ponto inicial por um nível par.

## 14. Comparação com os mapas vizinhos $3n-1$ e $5n+1$

**Teorema 35** (portas e ciclos dos mapas vizinhos). *(a) No mapa $n\mapsto3n-1$ ($n$ ímpar), $n\mapsto n/2$ ($n$ par), se a trajetória de um $n$ que não é potência de $2$ alcança uma potência de $2$, a primeira delas vem de um ímpar $p$ com $3p-1=2^j$ e $j$ ímpar: a porta é $2\cdot4^k$, $k\ge1$, um nível ímpar da progressão, de raio $2^k\sqrt2$, que não é quadrado perfeito. Esse mapa tem os ciclos $5\to14\to7\to20\to10\to5$ e $17\to50\to25\to74\to37\to110\to55\to164\to82\to41\to122\to61\to182\to91\to272\to136\to68\to34\to17$, que nunca chegam a uma potência de $2$.*

*(b) No mapa $n\mapsto5n+1$ ($n$ ímpar), $n\mapsto n/2$ ($n$ par), nas mesmas condições, a primeira potência de $2$ vem de um ímpar $p$ com $5p+1=2^j$, o que exige $4\mid j$: as portas são $16^k=(4^k)^2$, $k\ge1$, quadrados perfeitos, níveis pares da progressão, de raio inteiro, como no $3n+1$. O mapa tem os ciclos $13\to66\to33\to166\to83\to416\to208\to104\to52\to26\to13$ e $17\to86\to43\to216\to108\to54\to27\to136\to68\to34\to17$, que nunca chegam a uma porta.*

*Demonstração.* Como no Teorema 31, o antecessor $p$ da primeira potência de $2$ é ímpar, pois um antecessor par seria potência de $2$, e $p\ge3$. (a) $2^j\equiv-1\equiv2\pmod3$ se e só se $j$ é ímpar, e $2^j=3p-1\ge8$. (b) A ordem de $2$ módulo $5$ é $4$, e $2^j\equiv1\pmod5$ se e só se $4\mid j$, com $2^j=5p+1\ge16$. Os ciclos se conferem passo a passo; nenhum dos seus termos é potência de $2$. ◻

Entre os $99\,983$ números até $10^5$ que não são potências de $2$, as trajetórias do $3n-1$ chegam todas a uma porta ($33\,013$ números) ou a um dos dois ciclos ($32\,104$ ao ciclo de $5$ e $34\,866$ ao de $17$). Entre os $19\,985$ números até $2\cdot10^4$ que não são potências de $2$, as do $5n+1$ chegam a uma porta $16^k$ ($370$ números), entram no ciclo de $13$ ($603$) ou no de $17$ ($133$), ou passam de $10^{40}$ sem chegar a porta nem a ciclo ($18\,879$). O $3n-1$ nos positivos é o mesmo que o $3n+1$ nos negativos ($n\mapsto-n$): os seus três ciclos conhecidos, $\{1,2\}$, o de $5$ e o de $17$, são os ciclos do $3n+1$ em $-1$, $-5$ e $-17$, e que não existam outros também é uma conjectura.

No $3n+1$, a porta é sempre um quadrado perfeito $4^k$, e todas as trajetórias testadas, até $10^{10}$, chegam ao loop $1\to4\to2\to1$. Nos mapas vizinhos, a porta muda com o multiplicador, $2\cdot4^k$ no $3n-1$ e $16^k$ no $5n+1$, e os ciclos acima aparecem já entre os primeiros números.

![Figura 17: Trajetórias medidas na espiral de Teodoro: em cada passo, a distância $\sqrt N$ do ponto $v_N$ ao centro; as linhas tracejadas são os círculos das portas. Em cima, o problema $3n+1$: as trajetórias de $3$, $7$ e $27$ entram na descida final pela porta $16=4^2$, no círculo de raio inteiro $4$. Embaixo, os mapas vizinhos: o $3n-1$, com portas $2\cdot4^k$ e os ciclos de $5$ e de $17$, e o $5n+1$, com portas $16^k$ e o ciclo de $13$.](fig_png/fig17_teodoro_collatz_pt.png)

## 15. O fantasma: erro sistemático do ponto flutuante

A mesma rotação $\mathcal R$ foi aplicada $10^6$ vezes ao vértice $P$ em três formas. Em frações exatas, a quadrância $|P_n|^2-7/2$ e a altura $P_n\cdot a-13/2$ são zero em todo passo (Teorema 13). Em ponto flutuante de dupla precisão (IEEE 754 \[22\]):

       $n$  matriz $M/91$ em `double`   matriz por $\operatorname{sen}$ e $\cos$ de $2\arcsin(1/\sqrt{14})$
  -------- --------------------------- ---------------------------------------------------------------------
      $10$    $2{,}2\times10^{-15}$                            $1{,}8\times10^{-15}$
    $10^3$    $2{,}4\times10^{-13}$                            $8{,}6\times10^{-14}$
    $10^5$    $2{,}4\times10^{-11}$                            $7{,}6\times10^{-12}$
    $10^6$    $2{,}4\times10^{-10}$                            $7{,}7\times10^{-11}$

  : Tabela 4: Desvio $||P_n|^2-7/2|$ em ponto flutuante. Exato: $0$ em todo passo.

O desvio cresce proporcionalmente a $n$: é sistemático, não aleatório. De perto, no décimo passo, a figura parece perfeita; de longe, ao fim de um milhão de passos, o ponto saiu da esfera. É o fantasma do *Sofista* em linguagem numérica. A origem do desvio é a representação finita de números como $1/91$, $\cos2\theta$ e $\operatorname{sen}2\theta$; a via dos quadrados perfeitos, com quadrâncias e rotações racionais, mantém a identidade exata. Essa medida sustenta a tese no caso estudado; não demonstra que todo erro computacional venha do círculo.

## 16. Verificação exata

Todos os certificados usam inteiros e frações exatas; nenhum ponto flutuante decide nada. São três conjuntos de programas, sem código comum entre si.

**O arcabouço (seções 4 a 8 e 15).** O programa `loop_csc14.py` (Python, frações exatas) faz $25\,035$ verificações exatas, inclusive as projeções do octaedro, do cubo, do tetraedro $T^+$ e do tetraedro de aresta $7$ nas duas escalas, o cruzamento das arestas laterais sobre o círculo, o loop até $n=2000$, as tangentes e a hélice, sem falha, e acusa $16$ sabotagens, entre elas um vértice deslocado e uma escala errada. O programa `confere_loop_csc14.c` (C) prova o não fechamento para todo $n$ pelo certificado módulo $7$, confere-o até $n=10^6$ e acusa $10$ sabotagens; `compara.py` mostra que as dez chaves comuns às duas implementações coincidem; `deriva_float.py` produz a tabela da seção 15. A suíte `tetraedro_circulo_3d.html`, um único arquivo HTML com JavaScript, sem dependências e sem internet, mostra o tetraedro em qualquer ângulo, com o círculo, o cilindro, a esfera média, o octaedro dos pontos médios, a sombra no plano $xy$ e o corte $xz$, e recalcula os certificados na própria página com inteiros arbitrários e frações exatas.

**A espiral e o problema $3n+1$ (seções 9 a 14).** O programa `confere_teodoro_collatz.py` (Python, só biblioteca padrão) registra as previsões antes de executar e confere os itens da Tabela 5, além de sete sabotagens, versões erradas de propósito que precisam ser recusadas, e são. As coordenadas de $v_N$ são calculadas exatamente pela própria recorrência, como somas $\sum c_s\sqrt s$ com $c_s$ racional e $s$ livre de quadrados; as duas coordenadas de $v_{25}$ já somam $1024$ termos, e nenhum é aproximado. Nem todo enunciado tem certificado próprio: a Proposição 28 é ilustrada numericamente, e as Proposições 23 e 34 e os Corolários 26 e 32 são consequências diretas das demonstrações.

  ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
              O que confere                                                                                                                                                                                                                                                                         Alcance
  ----------- ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- -------------------------
  T1          identidade do produto telescópico $\prod_{k<N}(k+1)/k=N$                                                                                                                                                                                                                              $N\le10^5$

  T2          coordenadas exatas de $v_N$ no corpo gerado por $\sqrt2,\sqrt3,\sqrt5,\dots$: $\operatorname{Q}(v_N)=N$, passo de quadrância $1$ perpendicular ao raio, spreads $1/(N+1)$ e $N/(N+1)$, $\operatorname{Q}(v_N+tu_N)=N+t^2$, potência $M-N$; planificação e caixas $a\times b\times1$   $N\le25$; $5050$ caixas

  T3          fileira de $n$ quadrados: $3n+1$ segmentos e relação de Euler                                                                                                                                                                                                                         $n\le59$

  T4          porta $4^k$, $k\ge2$, vinda de $(4^k-1)/3$, por trajetórias completas                                                                                                                                                                                                                 $n\le10^6$

  T5          portas raras: $\lfloor\log_2(N/p_k)\rfloor+1$                                                                                                                                                                                                                                         $N=10^6$ e $N=10^9$

  T6          $3n-1$: portas $2\cdot4^k$; só os ciclos de $5$ e de $17$                                                                                                                                                                                                                             $n\le10^5$

  T7          $5n+1$: portas $16^k$; ciclos de $13$ e de $17$                                                                                                                                                                                                                                       $n\le2\cdot10^4$

  T8          $16$ triângulos $<360^\circ<17$ triângulos                                                                                                                                                                                                                                            limites racionais

  T9          progressão $S_j$: vértices, tangência nos vértices de $S_{j-1}$, lados                                                                                                                                                                                                                $j\le60$

  T10         passo elevado, com as coordenadas exatas: quadrância $2$, spread $1/2$ com o plano                                                                                                                                                                                                    $N\le25$

  S1–S7       sete sabotagens                                                                                                                                                                                                                                                                       $7/7$ recusadas
  ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

  : Tabela 5: Certificados exatos deste artigo.

As contagens de portas até $10^9$ vêm de `porta_quadrado.c`, que guarda a porta de cada número já resolvido e usa inteiros de $128$ bits com teste de estouro ($28$ segundos, nenhuma falha, nenhum estouro); o programa independente `porta_quadrado_independente.py` segue cada trajetória inteira até a primeira potência de $2$ e reproduz as mesmas contagens até $10^6$. O programa `collatz_exato.c` confirma que todo $n\le10^{10}$ chega a $1$, sem estouro; o maior tempo até cair abaixo do ponto de partida é o de $2\,788\,008\,987$ ($729$ passos), e o maior pico é o de $8\,528\,817\,511$, que sobe a $18\,144\,594\,937\,356\,598\,024$. As figuras usam ponto flutuante apenas para desenhar; os números da Proposição 28 na Figura 14(c) são ilustração numérica de um resultado demonstrado.

## 17. Princípios e argumentos do autor

Os princípios e os argumentos abaixo são do autor e orientam todo o trabalho; ao lado de cada um está o resultado deste artigo que o desenvolve.

\(a\) A geometria plana é a projeção, no plano $xy$, da geometria espacial. O círculo plano é a sombra de um objeto do espaço, e o eixo $z$, a profundidade, precisa ser recuperado, como na saída da caverna de Platão \[4\]. No arcabouço: o quadrado com as duas diagonais é a sombra do tetraedro, e o círculo com os quadrados inscrito e circunscrito é a sombra do octaedro, do cubo e do tetraedro, com o centro no eixo $z$ (seções 5 e 6). Na espiral: a elevação ao paraboloide, em que a altura é a quadrância (Teorema 27), e a planificação das diagonais dos cubos (Teorema 24).

\(b\) A exatidão vem da via dos quadrados perfeitos: medir quadrâncias, sem $\pi$ e sem raízes de inteiros que não são quadrados perfeitos. O fundamento é o Mênon, em que o quadrado sobre a diagonal tem o dobro da área \[2\], e o Sofista, que distingue a imagem proporcional, perfeita de perto e de longe, do simulacro, que parece belo de longe e é torto de perto \[3\]. Na espiral: Teoremas 19 e 20 e Proposição 23.

\(c\) A matemática do círculo fechado, com $\pi$, raízes aproximadas e ponto flutuante, é fonte de erro sistemático em computação; pela via dos quadrados perfeitos o erro é exatamente zero (seção 15). Neste artigo, nenhum certificado usa ponto flutuante (seção 16).

\(d\) A espiral de Teodoro, de lado sempre $1$, é uma forma específica de entender o círculo: $N$ é o número de segmentos de lado $1$, e a quadrância do ponto é o próprio $N$ (Teorema 19 e seção 10).

\(e\) O ponto inicial da espiral é o vértice de uma progressão infinita de quadrados inscritos e circunscritos nos círculos, e cada raio dessa progressão é aresta ou diagonal de quadrado inscrito ou circunscrito (Teorema 25 e Corolário 26).

\(f\) O círculo não é uma prisão: o caminho que lê os círculos não fecha, sobe no espaço e tem saída pelo centro, pela cossecante $\sqrt{14}$ do triângulo $13$ (seções 7 e 8; Proposições 22 e 28, Teoremas 20 e 27). O autor lê o retorno a $1$, no problema $3n+1$, como a pergunta sobre o círculo fechado; na espiral, o spread no centro é $1/(N+1)$, nunca $1$, e o ângulo reto fica no ponto de tangência (Teorema 20).

\(g\) No problema $3n+1$, o passo ímpar $3N+1$ é o número de palitos de uma fileira de $N$ quadrados, o passo par é o Mênon ao contrário, e, para os números que não são potências de $2$, a entrada na descida final se dá por um quadrado perfeito (Proposição 30, Corolário 26 e Teorema 31).

\(h\) As aplicações que o autor propõe para a matemática da exatidão estão na física, inclusive na física quântica, nos transportes, nos sistemas que exigem precisão e nos modelos de inteligência artificial \[1\].

## 18. Conclusão

Os teoremas, proposições, lemas e corolários deste artigo, numerados de 1 a 35, estão demonstrados por completo, com argumentos elementares, e as identidades e as contagens que eles afirmam são conferidas por programas exatos com sabotagens, na extensão indicada na seção 16. O arcabouço mostra que o círculo plano é uma projeção: o quadrado com as diagonais é a sombra do tetraedro; o círculo com os quadrados inscrito e circunscrito é a sombra do octaedro, do cubo e do tetraedro na esfera de diâmetro $\sqrt{14}$; o centro é o eixo $z$; o giro da cossecante $\sqrt{14}$ não fecha, e o percurso tem saída pelo centro. A espiral de Teodoro é uma forma específica e exata de entender o círculo: pelo lado $1$, pela quadrância inteira, pela progressão de quadrados que começa no ponto inicial e pela rampa de $45^\circ$ no paraboloide. No problema $3n+1$, essa leitura dá uma linguagem em números inteiros, em que a descida final percorre a progressão do ponto inicial e a porta é um quadrado perfeito, num círculo de raio inteiro; todas as trajetórias testadas, até $10^{10}$, chegam a $1$ e, pelo Teorema 31, as dos números que não são potências de $2$ entram por essa porta. Sobre essa base o autor formula a sua proposta de solução da conjectura de Collatz (seção 13). Para o autor, este trabalho é uma demonstração, sob a perspectiva da matemática da exatidão, de que o círculo não será a prisão eterna da humanidade.

## Referências

\[1\] COTA, D. C. D. *Matemática da perfeição e da exatidão quadrática*, versão 3.4. Brasil, 16 out. 2026.

\[2\] PLATÃO. *Mênon*, 82b–85b.

\[3\] PLATÃO. Sofista. In: *Diálogos*, v. X. Tradução de Carlos Alberto Nunes. Universidade Federal do Pará, 1980, p. 51–52 (235d–236c).

\[4\] PLATÃO. *República*, livro VII, 514a–517a.

\[5\] PLATÃO. *Teeteto*, 147d–148b.

\[6\] WILDBERGER, N. J. *Divine Proportions: Rational Trigonometry to Universal Geometry*. Wild Egg Books, 2005.

\[7\] RIVLIN, T. J. *The Chebyshev Polynomials*. Wiley, 1974.

\[8\] COXETER, H. S. M. *Regular Polytopes*. 3. ed. Dover, 1973.

\[9\] EULER, L. Problema algebraicum ob affectiones prorsus singulares memorabile. *Novi Commentarii Acad. Sci. Petropolitanae*, v. 15, p. 75–106, 1771.

\[10\] RODRIGUES, O. Des lois géométriques qui régissent les déplacements d’un système solide dans l’espace. *J. Math. Pures Appl.*, v. 5, p. 380–440, 1840.

\[11\] NIVEN, I. *Irrational Numbers*. Mathematical Association of America, 1956.

\[12\] HARDY, G. H.; WRIGHT, E. M. *An Introduction to the Theory of Numbers*. 6. ed. Oxford, 2008, cap. XXIII.

\[13\] DAVIS, P. J. *Spirals: From Theodorus to Chaos*. Wellesley: A K Peters, 1993.

\[14\] TEUFFEL, E. Eine Eigenschaft der Quadratwurzelschnecke. *Mathematisch-Physikalische Semesterberichte*, v. 6, p. 148–152, 1958.

\[15\] STOUTEN, F. In Theodorus’ spiral no two hypothenusa lie on the same line. arXiv:2403.20207, 2024.

\[16\] APOSTOL, T. M. *Introduction to Analytic Number Theory*. New York: Springer, 1976.

\[17\] LAGARIAS, J. C. (org.). *The Ultimate Challenge: The $3x+1$ Problem*. Providence: American Mathematical Society, 2010.

\[18\] TERRAS, R. A stopping time problem on the positive integers. *Acta Arithmetica*, v. 30, p. 241–252, 1976.

\[19\] TAO, T. Almost all orbits of the Collatz map attain almost bounded values. *Forum of Mathematics, Pi*, v. 10, e12, 2022.

\[20\] CONWAY, J. H. Unpredictable iterations. In: *Proceedings of the 1972 Number Theory Conference*. Boulder: University of Colorado, 1972, p. 49–52.

\[21\] BAŘINA, D. Improved verification limit for the convergence of the Collatz conjecture. *The Journal of Supercomputing*, v. 81, art. 810, 2025.

\[22\] IEEE. *IEEE Standard for Floating-Point Arithmetic*, IEEE Std 754-2019.

## Declaração de autoria

A tese, a formulação dos problemas, a esfera de diâmetro $\sqrt{14}$, as propostas geométricas, a leitura do problema $3n+1$ na espiral de Teodoro, com $N$ como o número de segmentos de lado $1$, a observação da progressão de quadrados inscritos e circunscritos a partir do ponto inicial e a proposta de solução são de Davi Cançado Dutra Cota. As demonstrações, os programas de verificação, a suíte interativa e as figuras foram elaborados com o auxílio do assistente de inteligência artificial Claude (Anthropic) e conferidos por execução.

*Jesus Cristo é O SENHOR.*

*A pedra que os construtores rejeitaram tornou-se a pedra fundamental.*
