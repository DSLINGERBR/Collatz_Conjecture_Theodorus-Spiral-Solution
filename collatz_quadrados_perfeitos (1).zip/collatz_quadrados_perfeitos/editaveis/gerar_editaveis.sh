#!/usr/bin/env bash
# Gera as versões editáveis (.md e .docx) dos cinco artigos a partir do LaTeX.
# Requisitos: xelatex, pandoc, pdftoppm, python3 com lxml e os esquemas XSD do ISO/IEC 29500-4 (pasta indicada
# na variável OOXML_XSD). Rodar dentro da pasta editaveis do pacote.
set -euo pipefail
RAIZ=$(cd .. && pwd)
TMP=$(mktemp -d)
MD_EXT="markdown-fenced_divs-native_divs-header_attributes-bracketed_spans-native_spans-raw_html-raw_tex-smart"

mkdir -p "$RAIZ/fig_png"
for f in "$RAIZ"/fig/*.pdf; do
  b=$(basename "$f" .pdf)
  [ -f "$RAIZ/fig_png/$b.png" ] || pdftoppm -png -r 200 -singlefile "$f" "$RAIZ/fig_png/$b"
done

for par in "artigo_collatz:pt" "article_collatz:en" "artigo_pt:pt" "article_en:en" "artigo_tetraedro:pt"; do
  nome=${par%%:*}; lang=${par##*:}
  (cd "$RAIZ" && for i in 1 2; do xelatex -interaction=nonstopmode -output-directory="$TMP" "$nome.tex" > /dev/null; done)
  python3 prep_pandoc.py "$RAIZ/$nome.tex" "$TMP/$nome.aux" "$lang" "$TMP/$nome.prep.tex"
  saida="$RAIZ/editaveis/$nome"
  rm -rf "$saida"; mkdir -p "$saida/fig_png"
  pandoc -f latex -t "$MD_EXT" --wrap=none "$TMP/$nome.prep.tex" -o "$saida/$nome.md"
  if [ "$lang" = pt ]; then sed -i 's/^\*Proof\.\*/*Demonstração.*/' "$saida/$nome.md"; fi
  grep -o 'fig_png/[A-Za-z0-9_]*\.png' "$saida/$nome.md" | sort -u | while read -r img; do cp "$RAIZ/$img" "$saida/fig_png/"; done
  # .docx: imagens na largura do texto (16 cm) e página A4
  sed -E 's/(!\[[^]]*\]\(fig_png\/[A-Za-z0-9_]+\.png\))/\1{width="16cm"}/' "$saida/$nome.md" > "$TMP/$nome.docx.md"
  (cd "$saida" && pandoc -f markdown "$TMP/$nome.docx.md" --reference-doc="$RAIZ/editaveis/referencia_a4.docx" -o "$TMP/$nome.docx")
  python3 corrige_docx.py "$TMP/$nome.docx" "$saida/$nome.docx"
  echo "gerado: $saida/$nome.md e $nome.docx"
done
rm -rf "$TMP"
