*Jesus Cristo é O SENHOR.*

*A pedra que os construtores rejeitaram tornou-se a pedra fundamental.*

# O tetraedro regular e o círculo

**O quadrado com as duas diagonais é a projeção de um sólido: demonstração exata em três dimensões**

Davi Cançado Dutra Cota — Brasil — 21 de outubro de 2026

## Resumo

O desenho plano de um quadrado com as duas diagonais, ao lado de um círculo, é a sombra exata, no plano $xy$, de um tetraedro regular. Para o tetraedro de aresta $7$ demonstra-se, com coordenadas exatas e quadrâncias racionais: (i) visto de cima ele é um quadrado de lado $7/\sqrt2$ com as duas diagonais de comprimento $7$; (ii) as diagonais são arestas opostas que não se tocam, nas alturas $z=\pm7/(2\sqrt2)$, e o centro do quadrado é, no espaço, o segmento vertical de comprimento $7/\sqrt2$; (iii) as quatro arestas laterais, que no plano parecem tangentes ao círculo inscrito no quadrado, atravessam o plano do círculo exatamente sobre o seu perímetro, perpendiculares ao raio e inclinadas $45^\circ$ em relação ao plano e à tangente do círculo; (iv) o círculo que passa pelos vértices do quadrado não é tocado pelo sólido: os vértices estão acima e abaixo dele; (v) girando o mesmo tetraedro, a sombra passa do quadrado com diagonais ao triângulo equilátero com o quarto vértice no centro, a profundidade $7\sqrt{2/3}$; (vi) os pontos médios das seis arestas formam um octaedro regular cujos vértices do equador são os quatro pontos em que as arestas cruzam o círculo e cujos dois vértices do eixo são as pontas do segmento central. Na esfera de diâmetro $\sqrt{14}$, a mesma figura tem aresta $\sqrt{28}$, e o centro do quadrado é o diâmetro $\sqrt{14}$. Uma suíte interativa em HTML, que funciona sem internet, mostra o sólido em qualquer ângulo e confere os valores com inteiros exatos.

## 1. Tese e o que se demonstra

**Tese do autor 1**. A geometria plana é a projeção, no plano $xy$, da geometria espacial. O desenho plano não mostra o eixo $z$, a profundidade; para a matemática exata, as figuras precisam ser lidas em três dimensões, com as medidas feitas pela via dos quadrados perfeitos. Não usar $\pi$ nem raízes de inteiros que não são quadrados perfeitos é o arcabouço que abrirá caminhos na física, inclusive na física quântica, nos transportes, nos sistemas que exigem precisão e nos modelos de inteligência artificial. O círculo fechado é útil para ensinar; como base do desenvolvimento científico e tecnológico, é fonte de erro. Na alegoria da caverna de Platão, prisioneiros tomam sombras projetadas numa parede pela realidade \[5\]; a figura plana é a sombra do sólido, e sair da caverna é recuperar o eixo $z$.

Este artigo demonstra a tese num caso exemplar e completo: o quadrado com as duas diagonais. Todas as afirmações são proposições com prova e com certificado computacional exato (seção 9). A palavra “projeção” tem aqui o sentido preciso da aplicação $\pi(x,y,z)=(x,y)$, que esquece a profundidade.

**Notação.** A quadrância de um vetor $u$ é $u\cdot u$; o spread entre $u$ e $v$ é $s(u,v)=1-(u\cdot v)^2/((u\cdot u)(v\cdot v))=\operatorname{sen}^2\angle(u,v)$: vale $0$ para retas paralelas, $1$ para perpendiculares e $1/2$ para um ângulo de $45^\circ$ \[3\]. Com dados racionais, ambos são racionais.

## 2. O tetraedro de aresta $7$

Seja $s>0$ com $s^2=49/8$, isto é, $s=7/(2\sqrt2)$, e $$A=s(1,1,1),\quad B=s(-1,-1,1),\quad C=s(1,-1,-1),\quad D=s(-1,1,-1).$$

**Proposição 1**. *$ABCD$ é um tetraedro regular de aresta $7$. Suas arestas $AB$ e $CD$ são horizontais, nas alturas $z=s$ e $z=-s$; as outras quatro, $AC$, $AD$, $BC$, $BD$, ligam a altura $s$ à altura $-s$ e são chamadas aqui de arestas laterais.*

*Demonstração.* Dois vértices diferem exatamente em duas coordenadas, por $\pm2s$: quadrância $8s^2=49$. As coordenadas $z$ de $A,B$ são $s$ e as de $C,D$ são $-s$. ◻

Todo tetraedro regular é semelhante a este; a escolha da aresta $7$ só fixa a unidade. As razões entre quadrâncias e os spreads são os mesmos em qualquer escala: a figura é imagem perfeita de perto e de longe.

## 3. Vista de cima: o quadrado com as duas diagonais

**Teorema 2**. *A projeção $\pi(ABCD)$ no plano $xy$ é o quadrado de vértices $(\pm s,\pm s)$, de lado $2s=7/\sqrt2$, com as duas diagonais $\pi(AB)$ e $\pi(CD)$, cada uma de comprimento $7$. O quadrado está inscrito no círculo $\Gamma_V$ de raio $7/2$ e circunscrito ao círculo $\Gamma_T$ de raio $s=7/(2\sqrt2)$.*

*Demonstração.* $\pi(A)=(s,s)$, $\pi(B)=(-s,-s)$, $\pi(C)=(s,-s)$, $\pi(D)=(-s,s)$. As arestas laterais projetam-se nos lados (quadrância $4s^2=49/2$) e $AB$, $CD$ nas diagonais (quadrância $8s^2=49$), que são horizontais e não encurtam. Os vértices distam $\sqrt{2s^2}=7/2$ do centro; os lados $x=\pm s$, $y=\pm s$ distam $s$. ◻

## 4. As diagonais não se cortam: o centro é um segmento do eixo $z$

**Teorema 3**. *As retas $AB$ e $CD$ são reversas. O ponto em que as diagonais parecem cruzar-se no desenho plano é, no espaço, o segmento vertical de $(0,0,-s)$ a $(0,0,s)$, de comprimento $2s=7/\sqrt2$, que é a perpendicular comum das duas arestas. Toda a fibra $\pi^{-1}(0,0)\cap ABCD$ é esse segmento.*

*Demonstração.* $AB$ está no plano $z=s$ e $CD$ no plano $z=-s$: não se encontram. Os pontos médios são $(0,0,s)$ e $(0,0,-s)$; o segmento entre eles tem direção $(0,0,1)$, perpendicular a $AB$, de direção $(1,1,0)$, e a $CD$, de direção $(1,-1,0)$, com quadrância $4s^2=49/2$. Para $|z|\le s$, a seção horizontal do tetraedro na altura $z$ é um retângulo centrado no eixo, de modo que o ponto $(0,0,z)$ pertence ao sólido; para $|z|>s$, não há sólido. ◻

O desenho plano identifica num só ponto tudo o que está ao longo do eixo $z$. É por isso que, olhando só o plano, as diagonais parecem presas uma à outra e ao centro do círculo; no espaço, elas passam uma por cima da outra, separadas por $7/\sqrt2$.

**Proposição 4** (a mesma sombra, objetos diferentes). *A figura plana $Q_0$, no plano $z=0$, formada pelo quadrado de vértices $(\pm s,\pm s,0)$ e pelas suas duas diagonais, tem exatamente a mesma projeção no plano $xy$ que o tetraedro $ABCD$. Em $Q_0$ as diagonais se cortam no centro; no tetraedro não se cortam e distam $7/\sqrt2$. A figura plana, sozinha, não decide se as diagonais se cortam: a resposta está no eixo $z$.*

*Demonstração.* Pelo Teorema 2, as duas projeções são o mesmo quadrado com as mesmas diagonais. Em $Q_0$ as diagonais estão no plano $z=0$ e se cortam em $(0,0,0)$; no tetraedro estão nos planos $z=\pm s$ (Teorema 3). ◻

Em matemática aplicada, essa é a diferença entre um resultado certo e um errado: reconstruir um objeto a partir de uma imagem, decidir se duas trajetórias se cruzam ou posicionar um ponto pelo desenho plano daria, aqui, a resposta errada.

![Figura 1: O tetraedro de aresta $7$ em quatro ângulos, de cima até de lado; abaixo, as vistas nos planos $xy$, $xz$ e pelo eixo vértice–face.](fig_png/fig9_tetraedro7_pt.png)

## 5. Como o tetraedro encontra o círculo

No plano $z=0$ consideram-se os dois círculos do Teorema 2: $\Gamma_T$, de raio $s$, tangente aos lados do quadrado no desenho, e $\Gamma_V$, de raio $7/2$, que passa pelos vértices do quadrado no desenho.

**Teorema 5** (o cruzamento). *(a) Cada aresta lateral atravessa o plano $z=0$ num único ponto, o seu ponto médio, e esse ponto está sobre o perímetro de $\Gamma_T$. Os quatro pontos são $(\pm s,0,0)$ e $(0,\pm s,0)$.*

*(b) No ponto de cruzamento, a aresta é perpendicular ao raio do círculo (spread $1$), faz $45^\circ$ com a tangente do círculo (spread $1/2$) e $45^\circ$ com o eixo $z$ (spread $1/2$); logo atravessa o plano do círculo inclinada $45^\circ$.*

*(c) A aresta lateral está no plano vertical $x=\pm s$ (ou $y=\pm s$), que toca $\Gamma_T$ só no ponto de cruzamento; e é tangente à esfera de centro na origem e raio $s$, a esfera média do tetraedro, nesse ponto.*

*(d) O tetraedro não toca $\Gamma_V$: a seção do sólido pelo plano $z=0$ é o quadrado de vértices $(\pm s,0,0)$, $(0,\pm s,0)$, cujo ponto mais afastado do centro está a distância $s<7/2$. Os vértices do tetraedro estão no cilindro vertical sobre $\Gamma_V$, nas alturas $z=\pm s$, acima e abaixo do círculo.*

*Demonstração.* Tome a aresta $AC$, de $s(1,1,1)$ a $s(1,-1,-1)$; as outras são análogas por simetria. (a) Seus pontos são $s(1,1-2t,1-2t)$; $z=0$ só em $t=\tfrac12$, o ponto $X=(s,0,0)$, a distância $s$ do eixo. (b) A direção da aresta é $d=(0,-2,-2)$; o raio em $X$ é $(1,0,0)$, com $d\cdot(1,0,0)=0$: spread $1$. A tangente do círculo em $X$ é $(0,1,0)$: $s=1-4/8=1/2$. O eixo é $(0,0,1)$: $s=1-4/8=1/2$. (c) Todos os pontos de $AC$ têm $x=s$; o plano $x=s$ encontra $\Gamma_T$ ($x^2+y^2=s^2$, $z=0$) só em $(s,0,0)$. Como $X\cdot d=0$, $X$ é o pé da perpendicular da origem à reta $AC$, e a distância da origem à reta é $|X|=s$: tangência à esfera de raio $s$. (d) A seção horizontal do tetraedro em $z=0$ é o fecho convexo dos quatro pontos de cruzamento; esses pontos distam $s$ do centro, e $s^2=49/8<49/4$. Os vértices satisfazem $x^2+y^2=2s^2=49/4$ e $z=\pm s\ne0$. ◻

**Resposta à pergunta “cruza o perímetro perpendicularmente?”.** Cruza o perímetro, sim, e exatamente: em quatro pontos do círculo tangente aos lados. É perpendicular ao *raio* nesses pontos. Não é perpendicular ao *plano* do círculo nem à sua *tangente*: o ângulo com cada um deles é de $45^\circ$. No desenho plano a aresta parece tangente ao círculo; no espaço ela o atravessa, subindo $45^\circ$. Quanto ao círculo que passa pelos vértices do quadrado desenhado, o sólido não o toca: os vértices ficam acima e abaixo dele.

![Figura 2: À esquerda, as quatro arestas laterais atravessam o plano $z=0$ sobre o círculo tangente (pontos dourados); o círculo tracejado passa pelas sombras dos vértices. No centro, a vista de cima: o lado roxo parece tangente ao círculo em $(s,0,0)$. À direita, o corte no plano vertical $x=s$, que contém a aresta: ela passa pelo único ponto do círculo nesse plano, inclinada $45^\circ$.](fig_png/fig10_cruzamento_pt.png)

## 6. Girar o sólido: do quadrado ao triângulo com o vértice no centro

**Teorema 6**. *Projetado ao longo da reta que liga o vértice $A$ ao centro da face oposta $BCD$, o tetraedro é um triângulo equilátero inscrito no círculo de raio $7/\sqrt3$, e $A$ cai no centro do triângulo, à distância $7\sqrt{2/3}$ do plano da face (a altura do tetraedro).*

*Demonstração.* O centro de $BCD$ é $G=-s(1,1,1)/3$; $A-G=\tfrac43s(1,1,1)$ é perpendicular a $B-G$, $C-G$, $D-G$, e $|A-G|^2=\tfrac{16}3s^2=\tfrac{98}3$. Os vértices da face distam de $G$ a quadrância $\tfrac83s^2=\tfrac{49}3$. ◻

A mesma peça, sem mudar uma só medida, dá no plano o quadrado com diagonais, o triângulo com o vértice no centro e todas as formas intermediárias (Figura 3). O que muda é a direção da projeção; as quadrâncias das seis arestas continuam $49$ em todas as posições. Em particular, o centro do triângulo, que no desenho parece um ponto do plano, é o vértice $A$, a profundidade $7\sqrt{2/3}$ no eixo $z$.

![Figura 3: O mesmo tetraedro de aresta $7$ girando (acima) e a sua sombra no plano $xy$ (abaixo): do quadrado com as diagonais ao triângulo com o vértice no centro.](fig_png/fig11_sombras_pt.png)

## 7. A ligação com o octaedro

**Teorema 7**. *Os pontos médios das seis arestas de $ABCD$ são os vértices $(\pm s,0,0)$, $(0,\pm s,0)$, $(0,0,\pm s)$ de um octaedro regular de aresta $7/2$ e altura central $2s=7/\sqrt2$. Os quatro vértices do seu equador são os pontos de cruzamento do Teorema 5, sobre o círculo $\Gamma_T$; os dois vértices do eixo são as pontas do segmento central do Teorema 3. Na vista de cima, o equador do octaedro é o quadrado inscrito em $\Gamma_T$, girado $45^\circ$ em relação ao quadrado do tetraedro, que é circunscrito a $\Gamma_T$.*

*Demonstração.* Os pontos médios de $AB$ e $CD$ são $(0,0,\pm s)$; os das quatro arestas laterais são $(\pm s,0,0)$, $(0,\pm s,0)$. Dois desses pontos não opostos diferem em duas coordenadas por $s$: quadrância $2s^2=49/4$; opostos, $4s^2=49/2$. Os vértices do equador são os pontos médios dos lados do quadrado $(\pm s,\pm s)$. ◻

Assim, os dois quadrados clássicos do desenho, o inscrito e o circunscrito a $45^\circ$, com o círculo entre eles, são a sombra de um único par de sólidos encaixados: o tetraedro e o octaedro dos seus pontos médios. O centro do círculo carrega os dois vértices do eixo do octaedro.

![Figura 4: O octaedro dos pontos médios (roxo) dentro do tetraedro; o eixo do octaedro (verde) é o segmento central. Na vista de cima, o equador do octaedro é o quadrado inscrito no círculo, e o tetraedro é o quadrado circunscrito com as diagonais.](fig_png/fig12_octaedro_meios_pt.png)

## 8. Na esfera de diâmetro $\sqrt{14}$

Com $s^2=7/2$ em lugar de $49/8$, o mesmo tetraedro tem aresta $\sqrt{28}$ e é o tetraedro $T^+$ do artigo \[1\]: sua esfera média é a esfera $\mathcal S\colon x^2+y^2+z^2=7/2$, de diâmetro $\sqrt{14}$, que circunscreve a caixa $1\times2\times3$. Todos os teoremas valem com os números trocados: o quadrado da vista de cima tem lado $\sqrt{14}$ e está circunscrito ao equador de $\mathcal S$; as arestas laterais cruzam esse equador perpendiculares ao raio e a $45^\circ$ do plano; o centro do quadrado é o diâmetro vertical, de comprimento $\sqrt{14}$; e os pontos médios das arestas formam o octaedro regular de aresta $\sqrt7$ e altura central $\sqrt{14}$, inscrito em $\mathcal S$. A saída pelo centro do círculo plano é a saída pelo eixo $z$, e mede $\sqrt{14}$.

![Figura 5: Na esfera de diâmetro $\sqrt{14}$: o tetraedro $T^+$ (aresta de cima em vermelho, de baixo em azul tracejado, laterais em preto), o octaedro dos pontos médios (azul, com o quadrado do meio em roxo e o eixo $\sqrt{14}$ em verde) e o círculo do equador (dourado), em cinco ângulos. As quatro arestas laterais tocam o círculo nos vértices do quadrado do meio. Abaixo: no plano $xy$, o quadrado com diagonais em volta do círculo e o quadrado do meio inscrito; no plano $xz$, a aresta lateral é vertical e toca o círculo, e o centro é o eixo $\sqrt{14}$; no plano vertical da aresta, ela atravessa o perímetro perpendicular ao raio e a $45^\circ$ do plano.](fig_png/fig13_tetra_octa_circulo_pt.png)

**Sem $\pi$ e sem raízes.** Nenhum resultado deste artigo usa $\pi$ ou a extração da raiz quadrada de um inteiro que não seja quadrado perfeito. Comprimentos como $7/\sqrt2$ ou $\sqrt{14}$ aparecem só como nomes; o que se calcula são as quadrâncias $49/2$ e $14$. Ângulos são spreads racionais ($1$ e $1/2$), e todo certificado é uma igualdade entre inteiros ou frações.

![Figura 6: Na esfera de diâmetro $\sqrt{14}$: o octaedro de altura $\sqrt{14}$, o tetraedro $T^+$ e o cubo, e as suas projeções no plano $xy$ e no plano lateral.](fig_png/fig8_octaedro_projecao_pt.png)

## 9. Verificação e suíte interativa

As afirmações dos Teoremas 2 a 7, nas duas escalas ($s^2=49/8$ e $s^2=7/2$), são conferidas em frações exatas pelo programa `loop_csc14.py` (certificados P13 e P14, parte de $25\,035$ verificações sem falha, com dezesseis sabotagens acusadas, entre elas um vértice deslocado e uma escala errada). A suíte `tetraedro_circulo_3d.html`, um único arquivo HTML com JavaScript, sem dependências e sem internet, mostra o tetraedro em qualquer ângulo, com o círculo, o cilindro, a esfera média, o octaedro dos pontos médios, a sombra no plano $xy$ e o corte $xz$; oferece as vistas do quadrado com diagonais, do triângulo com o vértice no centro e de lado; e recalcula os certificados na própria página com inteiros arbitrários (BigInt) e frações exatas.

## 10. Alcance

Os teoremas são de geometria euclidiana elementar e estão demonstrados por completo. O que eles mostram é que um desenho plano comum, o quadrado com as diagonais junto ao círculo, admite uma leitura espacial exata em que o centro é um segmento do eixo $z$, as diagonais não se tocam e as arestas atravessam o círculo a $45^\circ$. A geometria plana continua sendo, por si, uma teoria coerente; o que se defende aqui é ler as suas figuras como sombras de sólidos quando o problema é espacial. As consequências que o autor espera para a computação, a física e os modelos de inteligência artificial são teses do autor.

## Referências

\[1\] COTA, D. C. D. *O círculo plano é uma projeção: o loop da cossecante $\sqrt{14}$, o octaedro de altura $\sqrt{14}$ e o tetraedro regular*. Brasil, 21 out. 2026.

\[2\] COTA, D. C. D. *Matemática da perfeição e da exatidão quadrática*, versão 3.4. Brasil, 16 out. 2026.

\[3\] WILDBERGER, N. J. *Divine Proportions: Rational Trigonometry to Universal Geometry*. Wild Egg Books, 2005.

\[4\] COXETER, H. S. M. *Regular Polytopes*. 3. ed. Dover, 1973.

\[5\] PLATÃO. *República*, livro VII, 514a–517a.

\[6\] PLATÃO. Sofista, 235d–236c. In: *Diálogos*, v. X. Tradução de Carlos Alberto Nunes. Universidade Federal do Pará, 1980.

## Declaração de autoria

A tese e a proposta geométrica são de Davi Cançado Dutra Cota. As demonstrações, os programas, a suíte interativa e as figuras foram elaborados com o auxílio do assistente de inteligência artificial Claude (Anthropic) e conferidos por execução.

*Jesus Cristo é O SENHOR.*

*A pedra que os construtores rejeitaram tornou-se a pedra fundamental.*
