*Jesus Cristo é O SENHOR.*

*A pedra que os construtores rejeitaram tornou-se a pedra fundamental.*

# O círculo plano é uma projeção

**O loop da cossecante $\sqrt{14}$, o octaedro de altura $\sqrt{14}$ e o tetraedro regular: exatidão pela via dos quadrados perfeitos**

Davi Cançado Dutra Cota — Brasil — 21 de outubro de 2026

## Resumo

Este artigo defende que a geometria plana deve ser entendida como a projeção, no plano $xy$, da geometria espacial, e demonstra com exatidão os fatos que sustentam essa leitura no caso da esfera $\mathcal{S}\colon x^2+y^2+z^2=7/2$, de diâmetro $\sqrt{14}$. (i) O círculo visto de cima, com o quadrado inscrito, o quadrado circunscrito a $45^\circ$ e as duas diagonais, é a projeção exata de três sólidos: o octaedro regular de aresta $\sqrt7$ e altura central $\sqrt{14}$, o cubo de aresta $\sqrt{14}$ e o tetraedro regular de aresta $\sqrt{28}$ cujos pontos médios das arestas são os vértices do octaedro. O centro do círculo plano não é um ponto: são dois vértices do octaedro, em profundidades $\pm\sqrt{14}/2$ no eixo $z$, ligados pelo diâmetro $\sqrt{14}$. (ii) O tetraedro regular de aresta $7$, visto de cima, é um quadrado inscrito com as duas diagonais; as diagonais são arestas opostas que não se tocam, separadas por $7/\sqrt2$ no eixo $z$; visto pelo eixo vértice–face, é um triângulo inscrito com o quarto vértice no centro, em profundidade $7\sqrt{2/3}$. (iii) O percurso que avança pelo ângulo de cossecante $\sqrt{14}$ (o triângulo $1,\sqrt{13},\sqrt{14}$ da caixa $1\times2\times3$) nunca se fecha: os seus pontos têm denominador exato $2\cdot7^n$; o loop só se fecha pela meia-volta que passa pelo centro. (iv) As tangentes externas de cossecante $\sqrt{14}$ e o ponto interno ligado a elas pela inversão mostram a saída pelo centro. Toda a matemática é feita com quadrâncias, isto é, pela via dos quadrados perfeitos, fundamentada na distinção de Platão, no *Sofista*, entre a imagem proporcional de perto e de longe e o simulacro. Uma medida em ponto flutuante mostra o erro sistemático que essa via evita. Duas implementações independentes conferem tudo.

## 1. Tese e enunciados

**Tese do autor 1**. A geometria plana é a projeção, no plano $xy$, da geometria espacial ($x,y,z$), e precisa ser entendida assim. O círculo plano é uma projeção; o percurso sobre ele não se fecha e tem saída pelo centro, ao longo do eixo $z$, pela raiz de catorze. A matemática do círculo, feita com $\pi$, senos e raízes aproximados, é uma fonte de erros sistemáticos em computação, e a solução é a via dos quadrados perfeitos. Pensar com profundidade, sem $\pi$ e sem raízes de inteiros que não são quadrados perfeitos, abrirá caminhos na física, inclusive na física quântica, nos transportes, nos sistemas que exigem precisão e nos modelos de inteligência artificial. O círculo fechado é útil para ensinar; como base do desenvolvimento científico e tecnológico, é fonte de erro. É hora de sair da caverna de Platão.

O artigo separa com cuidado o que é tese, que orienta a pesquisa, do que é demonstrado. São demonstrados: as projeções exatas da seção 4 e da seção 5 (o centro do círculo plano é um segmento ou um vértice no eixo $z$); o teorema do loop da seção 8 (o percurso pela cossecante $\sqrt{14}$ nunca se fecha); a saída pelo centro das seções 9 e 10; e a separação exata entre seno zero, cossecante $1$ e cossecante $\sqrt{14}$ da seção 11; e, na seção 4, que a figura plana sozinha não decide se as diagonais do quadrado se cortam. É medido, não demonstrado em geral, o erro sistemático da seção 14.

**Notação.** A quadrância de um vetor $u$ é $u\cdot u$, a distância ao quadrado. O spread entre $u$ e $v$ é $s(u,v)=1-(u\cdot v)^2/((u\cdot u)(v\cdot v))=\operatorname{sen}^2\angle(u,v)$, racional para dados racionais \[9\]. A esfera é $\mathcal{S}\colon X\cdot X=\rho$, $\rho=7/2$, raio $R=\sqrt{14}/2$. A caixa $1\times2\times3$ centrada tem vértices $(\pm\tfrac12,\pm1,\pm\tfrac32)$ em $\mathcal{S}$; $P=(\tfrac12,1,\tfrac32)$, $P'=(-\tfrac12,1,\tfrac32)$, $d=2P=(1,2,3)$, $a=P+P'=(0,2,3)$. $T_n$, $U_n$ são os polinômios de Chebyshev \[8\].

## 2. Fundamento: o Mênon, o Sofista e a via dos quadrados perfeitos

**Mênon (82b–85b).** No diálogo, Sócrates pergunta a um jovem escravo como construir um quadrado de área dupla. Dobrar o lado quadruplica a área; o quadrado de área dupla é construído sobre a diagonal \[2\]. A lição matemática é exata: o comprimento da diagonal do quadrado unitário não é racional, mas o seu quadrado é $2$, inteiro. Quando se trabalha com os quadrados das medidas, as quadrâncias, a construção inteira fica nos inteiros.

**Sofista (235d–236c).** O Hóspede distingue duas artes de imagem. A primeira é “a arte de copiar, que consegue os melhores resultados quando o original é reproduzido em suas proporções de comprimento, largura e profundidade”; a segunda produz o que só parece semelhante quando visto de uma posição desfavorável, e merece o nome de simulacro, “por apenas parecer, sem ser realmente parecido” \[3\]. O autor chama de *fantasma* esse simulacro: belo de longe, torto de perto.

**República (514a–517a).** Na alegoria da caverna, prisioneiros que só veem sombras projetadas numa parede tomam as sombras pela realidade \[11\]. A leitura geométrica deste artigo é literal: a figura plana é a sombra, no plano $xy$, de um sólido; sair da caverna é recuperar o eixo $z$.

**Tradução matemática.** Uma figura é *imagem* quando as suas relações se conservam em todas as escalas, de perto e de longe: são as relações de semelhança, razões de quadrâncias e spreads, que uma mudança uniforme de escala não altera. Um cálculo é *fantasma* quando parece correto na escala grosseira e se desvia na escala fina: é o que faz um número arredondado repetido muitas vezes (seção 14). A via dos quadrados perfeitos consiste em representar comprimentos pelas quadrâncias e ângulos pelos spreads, que são racionais sempre que os pontos são racionais, e em usar rotações com entradas racionais. Nessa via, as identidades valem exatamente em todo passo.

## 3. A caixa, a esfera de diâmetro $\sqrt{14}$ e o triângulo $1,\sqrt{13},\sqrt{14}$

**Proposição 1**. *O triângulo $-P$, $P'$, $P$ tem quadrâncias $1$, $13$, $14$, ângulo reto em $P'$, e o ângulo $\theta$ em $-P$, oposto ao cateto $1$, satisfaz $\operatorname{sen}^2\theta=1/14$, $\operatorname{cossec}\theta=\sqrt{14}$, $\tan\theta=1/\sqrt{13}$, $\cos2\theta=6/7$.*

*Demonstração.* $P-P'=(1,0,0)$, $P'+P=a$, $2P=d$; $(1,0,0)\cdot a=0$; em $-P$, $s(d,a)=1-13^2/(14\cdot13)=1/14$; $\cos2\theta=1-2\operatorname{sen}^2\theta$. ◻

O cateto $1$ é uma aresta da caixa, o cateto $\sqrt{13}$ é uma diagonal da face $2\times3$, e a hipotenusa $\sqrt{14}$ é a diagonal que atravessa o centro da esfera: é a etapa $13+1=14$ de Teodoro.

## 4. O círculo plano como projeção: o octaedro de altura $\sqrt{14}$

Usamos o referencial próprio do octaedro inscrito $\mathcal O_7$ \[1, seção 21\]: três vetores $u_1=P$, $u_2$, $u_3$ com $u_i\cdot u_j=\rho\,\delta_{ij}$. Em coordenadas $(\alpha,\beta,\gamma)$ nesse referencial, a quadrância real é $\rho$ vezes a quadrância usual, e escolhemos o eixo $z$ na direção de $u_1$.

**Teorema 2** (o círculo, os dois quadrados e as diagonais são uma projeção). *Sejam $\mathcal O_7$ o octaedro de vértices $\pm u_i$, $\mathcal C$ o cubo de vértices $\pm u_1\pm u_2\pm u_3$ e $T^+$ o tetraedro de vértices $u_1+u_2+u_3$, $u_1-u_2-u_3$, $-u_1+u_2-u_3$, $-u_1-u_2+u_3$.*

*(a) $\mathcal O_7$ é regular, inscrito em $\mathcal{S}$, com doze arestas $\sqrt7$ e altura central $|u_1-(-u_1)|=\sqrt{14}$, o diâmetro. $\mathcal C$ tem aresta $\sqrt{14}$ e faces tangentes a $\mathcal{S}$; $T^+$ é regular, de aresta $\sqrt{28}$, e tem $\mathcal{S}$ como esfera média.*

*(b) **Ligação perfeita:** os pontos médios das seis arestas de $T^+$ são exatamente os seis vértices de $\mathcal O_7$.*

*(c) Projetados no plano $xy$ (ao longo de $u_1$): a silhueta de $\mathcal{S}$ é o círculo de raio $R=\sqrt{14}/2$; o equador de $\mathcal O_7$ é o **quadrado inscrito**, de lado $\sqrt7$ e diagonais $\sqrt{14}$; $\mathcal C$ e $T^+$ dão o **quadrado circunscrito**, de lado $\sqrt{14}$, girado $45^\circ$ (os vértices do inscrito são os pontos médios dos lados do circunscrito); duas arestas opostas de $T^+$ dão as **duas diagonais** do quadrado circunscrito.*

*(d) **O centro do círculo plano é o eixo $z$.** Caem no centro: os dois vértices $\pm u_1=\pm P$ de $\mathcal O_7$, em profundidades $z=\pm\sqrt{14}/2$; e os pontos médios das duas arestas de $T^+$ que formam as diagonais. Essas duas arestas não se cortam: estão nas alturas $z=+R$ e $z=-R$, e a sua perpendicular comum é o diâmetro $\sqrt{14}$, que passa pelo centro da esfera.*

*Demonstração.* (a) Dois vértices não antípodas de $\mathcal O_7$ diferem por $\pm u_i\mp u_j$: quadrância $2\rho=7$; antípodas, $4\rho=14$. Os vértices de $\mathcal C$ têm quadrância $3\rho$, e $|X\cdot u_i|\le\rho$ define faces à distância $R$ do centro. Duas arestas de $T^+$ diferem em dois sinais: quadrância $8\rho=28$; o ponto médio de cada aresta é um $\pm u_i$, de quadrância $\rho$, e a aresta é perpendicular a ele: tangência. (b) $\tfrac12[(1,1,1)+(1,-1,-1)]=(1,0,0)$ e assim para os seis pares. (c) Projetar ao longo de $u_1$ é apagar $\alpha$: $\pm u_2,\pm u_3\mapsto(\pm1,0),(0,\pm1)$, com quadrâncias $2\rho=7$ entre vizinhos e $4\rho=14$ entre opostos; $\mathcal C,T^+\mapsto(\pm1,\pm1)$, quadrado de lado $4\rho=14$ em quadrância, cujos lados $\beta=\pm1$, $\gamma=\pm1$ estão à distância $R$ do centro: tangentes ao círculo, com pontos médios $(\pm1,0),(0,\pm1)$. As arestas $(1,1,1)$–$(1,-1,-1)$ e $(-1,1,-1)$–$(-1,-1,1)$ projetam-se nas diagonais $(1,1)$–$(-1,-1)$ e $(1,-1)$–$(-1,1)$. (d) $\pm u_1\mapsto(0,0)$; as duas arestas têm $\alpha=+1$ e $\alpha=-1$; o segmento entre os seus pontos médios $u_1$ e $-u_1$ é perpendicular a ambas e tem quadrância $14$. ◻

A figura plana clássica, um círculo com o quadrado inscrito, o quadrado circunscrito a $45^\circ$ e as duas diagonais cruzando no centro, é portanto a sombra de três sólidos encaixados. O cruzamento das diagonais no centro é uma ilusão da projeção: em três dimensões, as diagonais passam uma por cima da outra, a distância $\sqrt{14}$, e o “ponto” central é o diâmetro vertical, cujas pontas são os vértices do octaedro. A saída pelo centro é a saída pelo eixo $z$, e mede $\sqrt{14}$.

![Figura 1: Acima, o octaedro $\mathcal O_7$ (azul, altura $\sqrt{14}$ em verde), o tetraedro $T^+$ (vermelho) e o cubo (pontilhado) na esfera $\mathcal{S}$, em três ângulos. Abaixo, à esquerda, a projeção no plano $xy$: círculo, quadrado inscrito, quadrado circunscrito a $45^\circ$ e as duas diagonais (arestas de $T^+$, uma na frente, contínua, outra atrás, tracejada). À direita, a vista lateral: o centro do círculo é o segmento vertical $\sqrt{14}$ entre os vértices $\pm P$.](fig_png/fig8_octaedro_projecao_pt.png)

**Proposição 3** (a mesma sombra, objetos diferentes). *Seja $Q_0$ a figura plana, no plano $z=0$, formada pelo quadrado de vértices $(\pm R,\pm R,0)$ e pelas suas duas diagonais, com $z$ ao longo de $u_1$ como no Teorema 2. $Q_0$ e o tetraedro $T^+$ têm exatamente a mesma projeção no plano $xy$: o quadrado de lado $\sqrt{14}$ com as duas diagonais. Em $Q_0$ as diagonais se cortam no centro; em $T^+$ elas não se cortam, e a distância entre elas é $\sqrt{14}$. Portanto a figura plana, sozinha, não decide se as diagonais se cortam: a resposta está no eixo $z$.*

*Demonstração.* Os vértices de $T^+$ são $R(\varepsilon_1,\varepsilon_2,\varepsilon_3)$ com $\varepsilon_1\varepsilon_2\varepsilon_3=1$; apagar a terceira coordenada dá os quatro vértices $(\pm R,\pm R)$ de $Q_0$, e cada aresta de $T^+$ vai num lado ou numa diagonal. As arestas que dão as diagonais estão nos planos $z=R$ e $z=-R$; sua perpendicular comum tem quadrância $4R^2=14$. Em $Q_0$, as diagonais estão no mesmo plano e se cortam em $(0,0,0)$. ◻

**Proposição 4** (a aresta lateral atravessa o perímetro). *As quatro arestas laterais de $T^+$ atravessam o plano do equador $z=0$ exatamente nos vértices do quadrado do meio, $(\pm R,0,0)$ e $(0,\pm R,0)$, que estão sobre o círculo do equador de $\mathcal{S}$. Nesses pontos cada aresta é perpendicular ao raio e faz $45^\circ$ com o plano do círculo e com a sua tangente; e é tangente à esfera $\mathcal{S}$, que toca só nesse ponto.*

*Demonstração.* A aresta de $R(1,1,1)$ a $R(1,-1,-1)$ é $R(1,1-2t,1-2t)$; corta $z=0$ em $t=\tfrac12$, no ponto $(R,0,0)$. Sua direção $(0,-2,-2)$ tem spread $1$ com o raio $(1,0,0)$ e spread $1/2$ com a tangente $(0,1,0)$ e com o eixo $(0,0,1)$. Como o ponto é o pé da perpendicular do centro à aresta e dista $R$ do centro, a aresta é tangente a $\mathcal{S}$. As outras três seguem por simetria. ◻

Em matemática aplicada, essa é a diferença entre um resultado certo e um errado: reconstruir um objeto a partir de uma imagem, decidir se duas trajetórias se cruzam ou posicionar um ponto no espaço pelo desenho plano daria, no caso de $T^+$, a resposta errada. A Figura 2 mostra a mesma configuração em cinco ângulos.

![Figura 2: O tetraedro $T^+$ (aresta de cima em vermelho, de baixo em azul tracejado, laterais em preto), o octaedro $\mathcal O_7$ (azul, com o quadrado do meio em roxo e o eixo $\sqrt{14}$ em verde) e o círculo do equador (dourado), em cinco ângulos. As quatro arestas laterais tocam o círculo nos vértices do quadrado do meio. Abaixo: no plano $xy$, o quadrado com diagonais em volta do círculo e o quadrado do meio inscrito; no plano $xz$, a aresta lateral é vertical e toca o círculo, e o centro é o eixo $\sqrt{14}$; no plano vertical da aresta, ela atravessa o perímetro perpendicular ao raio e a $45^\circ$ do plano.](fig_png/fig13_tetra_octa_circulo_pt.png)

**Sem $\pi$ e sem raízes.** Nenhum resultado deste artigo usa $\pi$ ou a extração da raiz quadrada de um inteiro que não seja quadrado perfeito. Comprimentos como $\sqrt{14}$ aparecem só como nomes: o que se calcula é a quadrância $14$. Ângulos são spreads racionais, rotações têm entradas racionais, e todo certificado é uma igualdade entre inteiros ou frações. É nesse sentido preciso que a via dos quadrados perfeitos dispensa a constante circular e as raízes.

## 5. O tetraedro regular de aresta $7$: o quadrado com as diagonais

**Teorema 5**. *Seja $s^2=49/8$ e $\mathcal T_7$ o tetraedro de vértices $s(1,1,1)$, $s(-1,-1,1)$, $s(1,-1,-1)$, $s(-1,1,-1)$.*

*(a) $\mathcal T_7$ é regular, com seis arestas de comprimento $7$.*

*(b) Visto de cima (projeção no plano $xy$), é um quadrado de lado $7/\sqrt2$ inscrito no círculo de raio $7/2$, com as duas diagonais, cada uma de comprimento $7$.*

*(c) As duas diagonais são arestas opostas, nas alturas $z=+s$ e $z=-s$: não se tocam. O centro do quadrado é, em três dimensões, o segmento vertical de comprimento $2s=7/\sqrt2$, perpendicular comum às duas arestas.*

*(d) Visto pelo eixo vértice–face, $\mathcal T_7$ é um triângulo equilátero inscrito no círculo de raio $7/\sqrt3$, e o quarto vértice cai no centro, na profundidade $7\sqrt{2/3}$ (altura do tetraedro).*

*Demonstração.* (a) Vértices diferem em dois sinais: quadrância $8s^2=49$. (b) As projeções são $(\pm s,\pm s)$: lado $2s$, quadrância $4s^2=49/2$; diagonais de quadrância $8s^2=49$; raio ao quadrado $2s^2=49/4$. (c) As arestas $s(1,1,1)$–$s(-1,-1,1)$ e $s(1,-1,-1)$–$s(-1,1,-1)$ têm $z=s$ e $z=-s$; o segmento entre os pontos médios $(0,0,\pm s)$ é vertical e perpendicular às duas. (d) A face oposta a $s(1,1,1)$ tem centro $-s(1,1,1)/3$; a altura ao quadrado é $s^2\cdot16/3=98/3$, e o raio da face ao quadrado é $s^2\cdot 8/3=49/3$. ◻

A mesma figura que o desenho plano mostra como “quadrado inscrito com as duas diagonais presas no círculo” é, no espaço, um tetraedro: as diagonais não estão presas ao círculo nem uma à outra; elas passam a alturas diferentes. Todo tetraedro regular é semelhante a $\mathcal T_7$, e o tetraedro $T^+$ do Teorema 2 é $\mathcal T_7$ em outra escala: imagem perfeita de perto e de longe, no sentido do *Sofista*.

![Figura 3: O tetraedro regular de aresta $7$. Acima, quatro ângulos, de cima até de lado: o quadrado com diagonais se abre e mostra que as diagonais (vermelha e azul) estão em alturas diferentes; o eixo $z$ em verde. Abaixo: o plano $xy$ (quadrado inscrito com diagonais $7$), o plano $xz$ (o centro do quadrado é o segmento $7/\sqrt2$) e a vista pelo eixo vértice–face (triângulo inscrito com o vértice no centro, em profundidade $7\sqrt{2/3}$).](fig_png/fig9_tetraedro7_pt.png)

## 6. A rotação exata da cossecante $\sqrt{14}$

Para um quatérnio $q=\alpha+\beta i+\gamma j+\delta k$, a matriz de Euler–Rodrigues $R(q)$ \[4, 5\] satisfaz $R(q)/|q|^2\in SO(3)$ e $R(qq')=R(q)R(q')$, e gira em torno da parte vetorial pelo dobro do meio-ângulo $\omega$, $\cos\omega=\alpha/|q|$.

**Proposição 6**. *O quatérnio $q=13+2j+3k$ tem norma $182=13\cdot14$ e meio-ângulo $\theta$. A rotação $\mathcal R=R(q)/182$ é $$\mathcal R=\frac1{91}\begin{pmatrix}78&-39&26\\39&82&6\\-26&6&87\end{pmatrix}=\tfrac67 I+\tfrac17\frac{aa^{\mathsf T}}{13}+\tfrac17[a]_\times,$$ com $\mathcal R^{\mathsf T}\mathcal R=I$, $\det\mathcal R=1$, $\mathcal Ra=a$, $\operatorname{tr}\mathcal R=19/7$: a rotação de ângulo $2\theta$ em torno de $a$, sem $\pi$, sem seno numérico e sem raiz.*

*Demonstração.* O meio-ângulo tem $\operatorname{sen}^2\omega=13/182=1/14$. A segunda forma é a fórmula de Rodrigues com $\cos2\theta=6/7$ e $\operatorname{sen}2\theta/\sqrt{13}=1/7$. As identidades verificam-se em inteiros: $MM^{\mathsf T}=91^2I$, $Ma=91a$. ◻

## 7. Potências exatas e valuação $7$-ádica

**Lema 7**. *Para $n\ge0$, $\mathcal R^n=c_nI+(1-c_n)\frac{aa^{\mathsf T}}{13}+\sigma_n[a]_\times$, com $c_n=T_n(6/7)$, $\sigma_n=U_{n-1}(6/7)/7$, e $P_n=\mathcal R^nP=\bigl(\tfrac{c_n}2,\ 1+\tfrac32\sigma_n,\ \tfrac32-\sigma_n\bigr)$.*

*Demonstração.* $\cos2n\theta=T_n(\cos2\theta)$ e $\operatorname{sen}2n\theta/\sqrt{13}=\sigma_n$; com $a\cdot P=13/2$ e $a\times P=(0,\tfrac32,-1)$, $P_n=c_nP+(1-c_n)\tfrac a2+\sigma_n(0,\tfrac32,-1)$. ◻

**Lema 8**. *$C_n=7^nT_n(6/7)$ e $D_k=7^kU_k(6/7)$ são inteiros, com $C_{n+1}=12C_n-49C_{n-1}$, $D_{k+1}=12D_k-49D_{k-1}$, $C_0=1$, $C_1=6$, $D_0=1$, $D_1=12$; e $C_n\equiv6\cdot5^{n-1}$, $D_k\equiv5^k\pmod7$. Logo $7\nmid C_n$ e $7\nmid D_k$.*

*Demonstração.* Módulo $7$, $49\equiv0$ e $12\equiv5$. ◻

## 8. O teorema do loop

**Teorema 9** (o loop da cossecante $\sqrt{14}$). *Seja $P_n=\mathcal R^nP$.*

*(a) Todo $P_n$ é racional, está em $\mathcal{S}$ e no círculo $C=\mathcal{S}\cap\{X\cdot a=13/2\}$, de centro $a/2$ e raio $\tfrac12$, cujo diâmetro é a aresta $PP'$.*

*(b) Para $n\ge1$, o denominador comum de $P_n$ é exatamente $2\cdot7^n$.*

*(c) Os $P_n$ são dois a dois distintos: $\mathcal R^n\ne I$ para todo $n\ge1$; o percurso nunca volta a $P$, nunca alcança $P'$ e, depois do primeiro passo, nunca mais toca um ponto inteiro de $2\mathcal{S}$, em particular nenhum dos $48$ pontos da casca $14$.*

*(d) $\theta/\pi$ é irracional e $\{P_n\}$ é denso em $C$: o loop não se fecha, e o círculo é o fecho desse percurso aberto.*

*Demonstração.* (a) $\mathcal R$ preserva $X\cdot X$ e fixa $a$; para $X\in C$, $|X-a/2|^2=7/2-13/2+13/4=1/4$. (b) Pelos lemas, $P_n=\bigl(\frac{C_n}{2\cdot7^n},\frac{2\cdot7^n+3D_{n-1}}{2\cdot7^n},\frac{3\cdot7^n-2D_{n-1}}{2\cdot7^n}\bigr)$, com numeradores não múltiplos de $7$; pela paridade ($C_n$ ímpar se e só se $n$ é par, $D_k$ ímpar se e só se $k$ é par), alguma coordenada tem denominador $2\cdot7^n$. (c) Denominadores distintos dão pontos distintos; se $\mathcal R^m=I$, $P_m=P$, absurdo. (d) Se $\theta/\pi\in\mathbb{Q}$, alguma potência seria $I$; pelo teorema de Kronecker \[7\], a órbita é densa. ◻

**Outras duas provas de (c).** Por Niven \[6\]: $2\cos2\theta=12/7$ não é inteiro, logo $2\theta$ não é fração racional de volta. Por posto um módulo $7$: $M=91\mathcal R$ tem $M^2\equiv2M\not\equiv0\pmod7$, donde $M^n\equiv2^{n-1}M\not\equiv0$, enquanto $91^nI\equiv0$.

Os primeiros pontos são $(\tfrac12,1,\tfrac32)$, $(\tfrac37,\tfrac{17}{14},\tfrac{19}{14})$, $(\tfrac{23}{98},\tfrac{67}{49},\tfrac{123}{98})$, $(-\tfrac9{343},\tfrac{971}{686},\tfrac{839}{686})$. Até $n=2000$, a melhor aproximação ao fechamento é $n=778$, a $0{,}115^\circ$; em todo caso $1-\cos2n\theta$ é um racional exatamente positivo.

![Figura 4: A caixa $1\times2\times3$ em $\mathcal{S}$, o triângulo $-P,P',P$ (dourado), a diagonal $\sqrt{14}$ (vermelho), o eixo $a$ (verde) e o círculo $C$ com os pontos $P_0,\dots,P_{24}$; no detalhe, os doze primeiros passos.](fig_png/fig1_caixa_loop_3d_pt.png)

![Figura 5: O loop no plano de $C$: doze passos não fecham; dois mil pontos distintos enchem o círculo; o fechamento só pela meia-volta, que leva $P$ a $P'$ pelo centro.](fig_png/fig2_loop_plano_pt.png)

## 9. Onde o loop fecha: pela meia-volta que passa pelo centro

**Proposição 10**. *Com $b=1+2j+3k$, o quatérnio das arestas da caixa, de norma $14$: $(13+2j+3k)(1+2j+3k)=14(2j+3k)$. Logo $\mathcal R\,\mathcal R_b=H=(2aa^{\mathsf T}-13I)/13$, a meia-volta em torno de $a$, com $HP=P'$, $H^2=I$: o loop fecha em quatro passos.*

*Demonstração.* Com $v=2j+3k$, $v^2=-13$, $(13+v)(1+v)=14v$; um quatérnio puro é uma meia-volta. $H$ é a ponte de eixo $P+P'=a$ \[1, Teorema C5\]. ◻

As tangentes dos meios-ângulos de $q$ e $b$ são $1/\sqrt{13}$ e $\sqrt{13}$, recíprocas; somam um quarto de volta, e a composição atravessa o centro do círculo $C$.

## 10. Tangentes externas e internas: a saída pelo centro

**Proposição 11**. *Sejam $X=(2,3,6)$, $|X|^2=49$, e $T=(1,\tfrac32,-\tfrac12)$, vértice da caixa $2\times3\times1$ centrada na origem. Então $T\in\mathcal{S}$ e $T\cdot(X-T)=0$ (o raio $OT$ é perpendicular à tangente $XT$); a tangente externa $XT$ faz com o eixo $XO$ o ângulo de spread $1/14$, isto é, $\operatorname{cossec}\theta=\sqrt{14}$; o triângulo $O,T,X$ tem quadrâncias $7/2,\,91/2,\,49$, proporcionais a $1,13,14$; o ponto interno $X'=\rho X/|X|^2=X/14$ é o inverso de $X$, com $|OX'|\cdot|OX|=\tfrac12\cdot7=R^2$; e todas as tangentes de $X$ tocam $\mathcal{S}$ no círculo de centro $X'$ e raio $\sqrt{13}/2$, no plano polar $X\cdot Y=\rho$.*

*Demonstração.* $T\cdot T=T\cdot X=7/2$; o triângulo é retângulo em $T$ e $\operatorname{sen}^2\theta=(7/2)/49$; o raio do círculo de contato é $\sqrt{\rho-1/4}$. ◻

As tangentes *externas* saem de $X$, fora da bola, com cossecante $\sqrt{14}$ em relação ao eixo; o ponto *interno* $X'$ é o centro do seu círculo de contato. A inversão troca um pelo outro, com a mesma lei que leva a insfera do disfenoide, de raio $3/7$, à circunsfera polar, de raio $49/6$: $\tfrac37\cdot\tfrac{49}6=\tfrac72$ \[1, seção 21.6\]. O eixo $X\to X'\to O\to-X'\to-X$ atravessa o centro, e o salto $J=-I$ repete o cone do outro lado. Vistas ao longo do eixo, as tangentes externas são raios que saem do centro do círculo para fora.

![Figura 6: O cone das tangentes externas a $\mathcal{S}$ a partir de $X=(2,3,6)$, cossecante $\sqrt{14}$; círculo de contato de centro $X'=X/14$; o eixo atravessa o centro até $-X$.](fig_png/fig3_cone_tangentes_3d_pt.png)

![Figura 7: Seção pelo eixo e vista ao longo do eixo: $X$, $X'$ e $O$ caem no centro, e cada tangente externa vira um raio.](fig_png/fig4_secao_projecao_pt.png)

## 11. Seno zero, cossecante $1$ e cossecante $\sqrt{14}$

**Proposição 12**. *No triângulo $O,T,X$, com o eixo $OX$ como eixo $z$:*

*(a) **Seno zero é o do eixo.** Toda direção ao longo do eixo tem spread $0$ com ele; toda rotação em torno do eixo fixa-o ponto a ponto, e o movimento helicoidal $Y\mapsto\mathcal RY+a$ leva o eixo $a$ nele mesmo. Um ponto que se desloca no eixo $z$ gira com tudo e mantém seno zero; visto de cima, é o centro.*

*(b) **Cossecante $1$ é a do raio com a tangente:** $OT\perp XT$ em todo ponto de contato.*

*(c) **Cossecante $\sqrt{14}$ é a da tangente externa com o eixo:** $XT$ mede $\sqrt{91/2}$, avança $13/2$ no eixo e projeta-se no plano com $\sqrt{13}/2$, e $\operatorname{cossec}\theta=|XT|/(\text{projeção})=\sqrt{14}$.*

**Proposição 13**. *Nenhum ângulo tem ao mesmo tempo seno zero e cossecante $\sqrt{14}$ (nem cossecante $1$), pois $\operatorname{sen}\alpha\cdot\operatorname{cossec}\alpha=1$ sempre que a cossecante existe.*

As três afirmações da tese convivem no mesmo triângulo, mas pertencem a ângulos diferentes: o eixo tem seno zero, o raio faz cossecante $1$ com a tangente, a tangente externa faz cossecante $\sqrt{14}$ com o eixo. Na projeção sobre o plano $xy$, o eixo desaparece num ponto, e só a cossecante $1$ continua visível.

**A hélice.** $Y_n=\mathcal R^nP+n\,a$ sobe $13$ por passo no eixo ($Y_n\cdot a=13/2+13n$) e projeta-se na órbita do Teorema 9; cada passo tem corda de quadrância $1/14$ no plano e quadrância total $183/14$. A hélice não fecha no espaço, e sua projeção, o círculo, também não fecha.

![Figura 8: A hélice e sua projeção: o círculo plano é a sombra de um percurso que sobe no eixo $z$ e nunca se fecha.](fig_png/fig5_helice_pt.png)

## 12. Teodoro e o tetraedro de aresta $\sqrt7$

**Teorema 14**. *O passo de Teodoro $n\to n+1$ ($\operatorname{cossec}\theta_n=\sqrt{n+1}$, $\cos2\theta_n=\frac{n-1}{n+1}$), repetido como giro, fecha o loop se e só se $n=1$ (giro de $90^\circ$, quatro passos) ou $n=3$ ($60^\circ$, seis passos). Para $n=13$, cossecante $\sqrt{14}$, nunca fecha.*

*Demonstração.* $2\cos2\theta_n$ deve ser inteiro: $(n+1)\mid 2(n-1)$, isto é, $(n+1)\mid4$. ◻

No octaedro $\mathcal O_7$, os quatro tetraedros $\operatorname{conv}\{P,-P,\pm u_2,\pm u_3\}$ em torno do eixo $\sqrt{14}$ têm a dobra $7+7=14$, o passo $1\to2$, e fecham exatamente (diedro reto). Na face do tetraedro regular de aresta $\sqrt7$, a altura dá o triângulo $1,\sqrt3,2$, o passo $3\to4$, e seis faces fecham em $60^\circ$. O diedro do tetraedro regular tem $\cos\delta=1/3$; $T_k(1/3)$ tem denominador $3^k$ e nunca vale $1$: cinco tetraedros em torno de uma aresta deixam a fenda $\cos5\delta=241/243$.

![Figura 9: Os passos de Teodoro como giros: $n=1$ fecha num quadrado, $n=3$ num hexágono, $n=13$ nunca fecha.](fig_png/fig6_teodoro_fecha_pt.png)

![Figura 10: Quatro tetraedros em torno do eixo $\sqrt{14}$ fecham o octaedro; cinco tetraedros regulares em torno de uma aresta não fecham.](fig_png/fig7_tetraedros_pt.png)

**A espiral inteira.** A espiral de Teodoro completa, lida como o círculo de lado $1$, é desenvolvida no artigo principal \[13\]. Lá se demonstra que, depois de $N$ segmentos de lado $1$, o ponto está na quadrância $N$ e cada passo é tangente ao círculo $x^2+y^2=N$; que a espiral é a planificação das diagonais dos cubos de dimensão $N$ e $N+1$, com o triângulo $13$ na caixa $1\times2\times3$; que o seu início é o de uma progressão de quadrados inscritos e circunscritos nos círculos $x^2+y^2=2^j$; que, elevada ao paraboloide $z=x^2+y^2$, ela é uma rampa de $45^\circ$; e que, no problema $3n+1$, toda trajetória que chega a $1$, partindo de um número que não é potência de $2$, entra na descida final por um quadrado perfeito $4^k$.

## 13. Critério geral do loop

**Teorema 15**. *Uma rotação de entradas racionais fecha o loop se e só se o seu traço está em $\{3,2,1,0,-1\}$ (ordens $1,6,4,3,2$).*

*Demonstração.* $2\cos\varphi=\operatorname{tr}-1$ é racional; se é inteiro algébrico, é inteiro em $[-2,2]$. ◻

  Rotação                                 $\operatorname{tr}$   $2\cos\varphi$    Fecha?
  -------------------------------------- --------------------- ---------------- -----------
  $T_{-1,3}$ \[1, seção 15.4\]                  $13/23$            $-10/23$        nunca
  $T_{1,1}$                                    $-11/15$            $-26/15$        nunca
  $M_3/3$, primeiro cubo pitagórico              $1/3$              $-2/3$         nunca
  $M_7/7$, meia-volta da diagonal                $-1$                $-2$        ordem $2$
  $\mathcal R$, cossecante $\sqrt{14}$          $19/7$              $12/7$         nunca
  $\mathcal R_b$, quatérnio da caixa            $-5/7$             $-12/7$         nunca
  Giro fixo da Espiral de Cot$\alpha$         $\sqrt2/2$        $-1+\sqrt2/2$      nunca

  : Tabela 1: Auditoria das rotações; a ordem prevista coincidiu com a busca direta até $60$ potências.

## 14. O fantasma: erro sistemático do ponto flutuante

A mesma rotação $\mathcal R$ foi aplicada $10^6$ vezes ao vértice $P$ em três formas. Em frações exatas, a quadrância $|P_n|^2-7/2$ e a altura $P_n\cdot a-13/2$ são zero em todo passo (Teorema 9). Em ponto flutuante de dupla precisão (IEEE 754):

       $n$  matriz $M/91$ em `double`   matriz por $\operatorname{sen}$ e $\cos$ de $2\arcsin(1/\sqrt{14})$
  -------- --------------------------- ---------------------------------------------------------------------
      $10$    $2{,}2\times10^{-15}$                            $1{,}8\times10^{-15}$
    $10^3$    $2{,}4\times10^{-13}$                            $8{,}6\times10^{-14}$
    $10^5$    $2{,}4\times10^{-11}$                            $7{,}6\times10^{-12}$
    $10^6$    $2{,}4\times10^{-10}$                            $7{,}7\times10^{-11}$

  : Tabela 2: Desvio $||P_n|^2-7/2|$ em ponto flutuante. Exato: $0$ em todo passo.

O desvio cresce proporcionalmente a $n$: é sistemático, não aleatório. De perto, no décimo passo, a figura parece perfeita; de longe, ao fim de um milhão de passos, o ponto saiu da esfera. É o fantasma do *Sofista* em linguagem numérica. A origem do desvio é a representação finita de números como $1/91$, $\cos2\theta$ e $\operatorname{sen}2\theta$; a via dos quadrados perfeitos, com quadrâncias e rotações racionais, mantém a identidade exata. Essa medida sustenta a tese no caso estudado; não demonstra que todo erro computacional venha do círculo.

## 15. Verificação computacional

Duas implementações sem código comum conferem as afirmações. `loop_csc14.py` (Python, frações exatas) faz $25\,035$ verificações exatas, inclusive as projeções do octaedro, do cubo, de $T^+$ e de $\mathcal T_7$, o loop até $n=2000$, as tangentes e a hélice, sem falha, e acusa $16$ sabotagens. `confere_loop_csc14.c` (C) prova o não fechamento para todo $n$ pelo certificado módulo $7$, confere-o até $n=10^6$ e acusa $10$ sabotagens. `compara.py` mostra que as dez chaves comuns coincidem. `deriva_float.py` produz a tabela da seção 14.

## 16. Validade e alcance

As demonstrações são completas e usam a fórmula de Euler–Rodrigues, os polinômios de Chebyshev, o teorema de Niven, o teorema de Kronecker, a inversão e a geometria dos sólidos regulares. As projeções das seções 4 e 5 são fatos elementares que este artigo organiza a serviço da tese. O teorema do loop resolve, na forma exata aqui enunciada, a questão deixada em aberto na seção 10.3 de \[1\]. Quatro precisões: (i) como conjunto de pontos, o círculo é uma curva fechada; o que se demonstra é que o percurso pela cossecante $\sqrt{14}$ não se fecha e que o centro do círculo plano é, no espaço, um segmento do eixo $z$; (ii) seno zero e cossecante $\sqrt{14}$ pertencem a ângulos diferentes; (iii) o erro sistemático foi medido num caso, não demonstrado em geral; (iv) as consequências esperadas para a física, os transportes e a inteligência artificial são teses do autor.

## Referências

\[1\] COTA, D. C. D. *Matemática da perfeição e da exatidão quadrática*, versão 3.4. Brasil, 16 out. 2026.

\[2\] PLATÃO. *Mênon*, 82b–85b.

\[3\] PLATÃO. Sofista. In: *Diálogos*, v. X. Tradução de Carlos Alberto Nunes. Universidade Federal do Pará, 1980, p. 51–52 (235d–236c).

\[4\] EULER, L. Problema algebraicum ob affectiones prorsus singulares memorabile. *Novi Commentarii Acad. Sci. Petropolitanae*, v. 15, p. 75–106, 1771.

\[5\] RODRIGUES, O. Des lois géométriques qui régissent les déplacements d’un système solide dans l’espace. *J. Math. Pures Appl.*, v. 5, p. 380–440, 1840.

\[6\] NIVEN, I. *Irrational Numbers*. Mathematical Association of America, 1956.

\[7\] HARDY, G. H.; WRIGHT, E. M. *An Introduction to the Theory of Numbers*. 6. ed. Oxford, 2008, cap. XXIII.

\[8\] RIVLIN, T. J. *The Chebyshev Polynomials*. Wiley, 1974.

\[9\] WILDBERGER, N. J. *Divine Proportions: Rational Trigonometry to Universal Geometry*. Wild Egg Books, 2005.

\[10\] COXETER, H. S. M. *Regular Polytopes*. 3. ed. Dover, 1973.

\[11\] PLATÃO. *República*, livro VII, 514a–517a.

\[12\] IEEE. *IEEE Standard for Floating-Point Arithmetic*, IEEE Std 754-2019.

\[13\] COTA, D. C. D. *Proposta de solução da Conjectura de Collatz pela via dos quadrados perfeitos e a matemática da exatidão*. Brasil, 21 out. 2026.

## Declaração de autoria

A tese, a formulação dos problemas, a esfera de diâmetro $\sqrt{14}$ e as propostas geométricas são de Davi Cançado Dutra Cota. As demonstrações, os programas de verificação e as figuras foram elaborados com o auxílio do assistente de inteligência artificial Claude (Anthropic) e conferidos por execução.

*Jesus Cristo é O SENHOR.*

*A pedra que os construtores rejeitaram tornou-se a pedra fundamental.*
