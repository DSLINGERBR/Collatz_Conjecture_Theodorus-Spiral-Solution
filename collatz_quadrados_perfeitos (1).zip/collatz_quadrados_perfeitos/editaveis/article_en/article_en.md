*Jesus Christ is THE LORD.*

*The stone rejected by the builders is now the main foundation stone!*

# The plane circle is a projection

**The loop of cosecant $\sqrt{14}$, the octahedron of height $\sqrt{14}$ and the regular tetrahedron: exactness through perfect squares**

Davi Cançado Dutra Cota — Brazil — October 21, 2026

## Abstract

This paper argues that plane geometry should be understood as the projection, onto the $xy$ plane, of spatial geometry, and proves exactly the facts that support this reading for the sphere $\mathcal{S}\colon x^2+y^2+z^2=7/2$, of diameter $\sqrt{14}$. (i) The circle seen from above, with the inscribed square, the circumscribed square at $45^\circ$ and both diagonals, is the exact projection of three solids: the regular octahedron of edge $\sqrt7$ and central height $\sqrt{14}$, the cube of edge $\sqrt{14}$, and the regular tetrahedron of edge $\sqrt{28}$ whose edge midpoints are the vertices of the octahedron. The centre of the plane circle is not a point: it is two vertices of the octahedron, at depths $\pm\sqrt{14}/2$ on the $z$ axis, joined by the diameter $\sqrt{14}$. (ii) The regular tetrahedron of edge $7$, seen from above, is an inscribed square with both diagonals; the diagonals are opposite edges that never touch, separated by $7/\sqrt2$ along $z$; seen along a vertex–face axis it is an inscribed triangle with the fourth vertex at the centre, at depth $7\sqrt{2/3}$. (iii) The path that advances by the angle of cosecant $\sqrt{14}$ (the triangle $1,\sqrt{13},\sqrt{14}$ of the $1\times2\times3$ box) never closes: its points have exact denominator $2\cdot7^n$; the loop closes only through the half-turn that passes through the centre. (iv) The external tangents of cosecant $\sqrt{14}$ and the inner point linked to them by inversion show the exit through the centre. All the mathematics is done with quadrances, that is, through perfect squares, grounded in Plato’s distinction, in the *Sophist*, between the likeness that keeps its proportions near and far and the semblance. A floating-point measurement shows the systematic error that this route avoids. Two independent implementations check everything.

## 1. Thesis and statements

**Author’s thesis 1**. Plane geometry is the projection, onto the $xy$ plane, of spatial geometry ($x,y,z$), and must be understood as such. The plane circle is a projection; the path on it does not close and has an exit through the centre, along the $z$ axis, by the square root of fourteen. The mathematics of the circle, carried out with approximated $\pi$, sines and roots, is a source of systematic errors in computation, and the remedy is the route of perfect squares. Thinking with depth, without $\pi$ and without roots of integers that are not perfect squares, will open paths in physics, including quantum physics, in transport, in systems that demand precision and in artificial intelligence models. The closed circle is useful for teaching; as a basis for scientific and technological development, it is a source of error. It is time to leave Plato’s cave.

The paper keeps apart what is thesis, which guides the research, and what is proved. Proved are: the exact projections of Sections 4 and 5 (the centre of the plane circle is a segment or a vertex on the $z$ axis); the loop theorem of Section 8 (the path by cosecant $\sqrt{14}$ never closes); the exit through the centre in Sections 9 and 10; and the exact separation of sine zero, cosecant $1$ and cosecant $\sqrt{14}$ in Section 11; and, in Section 4, that the plane figure alone cannot decide whether the diagonals of the square cross. The systematic error of Section 14 is measured, not proved in general.

**Notation.** The quadrance of a vector $u$ is $u\cdot u$, the squared distance. The spread between $u$ and $v$ is $s(u,v)=1-(u\cdot v)^2/((u\cdot u)(v\cdot v))=\sin^2\angle(u,v)$, rational for rational data \[9\]. The sphere is $\mathcal{S}\colon X\cdot X=\rho$, $\rho=7/2$, radius $R=\sqrt{14}/2$. The centred $1\times2\times3$ box has vertices $(\pm\tfrac12,\pm1,\pm\tfrac32)$ on $\mathcal{S}$; $P=(\tfrac12,1,\tfrac32)$, $P'=(-\tfrac12,1,\tfrac32)$, $d=2P=(1,2,3)$, $a=P+P'=(0,2,3)$. $T_n$, $U_n$ are the Chebyshev polynomials \[8\].

## 2. Foundation: the Meno, the Sophist and the route of perfect squares

**Meno (82b–85b).** Socrates asks a young slave how to build a square of double area. Doubling the side quadruples the area; the square of double area is built on the diagonal \[2\]. The mathematical lesson is exact: the length of the diagonal of the unit square is not rational, but its square is $2$, an integer. Working with the squares of the measures, the quadrances, keeps the whole construction in the integers.

**Sophist (235d–236c).** The Stranger distinguishes two arts of images. The first is the art of likeness-making, which succeeds best when it reproduces the proportions of the original in length, breadth and depth; the second produces what only seems like the original when seen from an unfavourable position, and deserves the name of semblance, since it only appears to resemble without really resembling \[3\]. The author calls this semblance a *phantom*: beautiful from afar, crooked up close.

**Republic (514a–517a).** In the allegory of the cave, prisoners who see only shadows cast on a wall take the shadows for reality \[11\]. The geometric reading of this paper is literal: the plane figure is the shadow, on the $xy$ plane, of a solid; leaving the cave means recovering the $z$ axis.

**Mathematical translation.** A figure is a *likeness* when its relations hold at every scale, near and far: these are the similarity relations, ratios of quadrances and spreads, which a uniform change of scale leaves unchanged. A computation is a *phantom* when it looks right at the coarse scale and drifts at the fine scale: this is what a rounded number repeated many times does (Section 14). The route of perfect squares represents lengths by quadrances and angles by spreads, which are rational whenever the points are rational, and uses rotations with rational entries. Along this route the identities hold exactly at every step.

## 3. The $1\times2\times3$ box, the sphere of diameter $\sqrt{14}$ and the triangle $1,\sqrt{13},\sqrt{14}$

**Proposition 1**. *The triangle $-P$, $P'$, $P$ has quadrances $1$, $13$, $14$, a right angle at $P'$, and the angle $\theta$ at $-P$, opposite the leg $1$, satisfies $\sin^2\theta=1/14$, $\csc\theta=\sqrt{14}$, $\tan\theta=1/\sqrt{13}$, $\cos2\theta=6/7$.*

*Proof.* $P-P'=(1,0,0)$, $P'+P=a$, $2P=d$; $(1,0,0)\cdot a=0$; at $-P$, $s(d,a)=1-13^2/(14\cdot13)=1/14$; $\cos2\theta=1-2\sin^2\theta$. ◻

The leg $1$ is an edge of the box, the leg $\sqrt{13}$ is a diagonal of the $2\times3$ face, and the hypotenuse $\sqrt{14}$ is the diagonal through the centre of the sphere: it is the step $13+1=14$ of Theodorus.

## 4. The plane circle as a projection: the octahedron of height $\sqrt{14}$

We use the proper frame of the inscribed octahedron $\mathcal O_7$ \[1, Sec. 21\]: three vectors $u_1=P$, $u_2$, $u_3$ with $u_i\cdot u_j=\rho\,\delta_{ij}$. In coordinates $(\alpha,\beta,\gamma)$ in this frame the true quadrance is $\rho$ times the usual one, and we take the $z$ axis along $u_1$.

**Theorem 2** (the circle, the two squares and the diagonals are a projection). *Let $\mathcal O_7$ be the octahedron with vertices $\pm u_i$, $\mathcal C$ the cube with vertices $\pm u_1\pm u_2\pm u_3$, and $T^+$ the tetrahedron with vertices $u_1+u_2+u_3$, $u_1-u_2-u_3$, $-u_1+u_2-u_3$, $-u_1-u_2+u_3$.*

*(a) $\mathcal O_7$ is regular, inscribed in $\mathcal{S}$, with twelve edges $\sqrt7$ and central height $|u_1-(-u_1)|=\sqrt{14}$, the diameter. $\mathcal C$ has edge $\sqrt{14}$ and faces tangent to $\mathcal{S}$; $T^+$ is regular, with edge $\sqrt{28}$, and has $\mathcal{S}$ as its midsphere.*

*(b) **Perfect link:** the midpoints of the six edges of $T^+$ are exactly the six vertices of $\mathcal O_7$.*

*(c) Projected onto the $xy$ plane (along $u_1$): the outline of $\mathcal{S}$ is the circle of radius $R=\sqrt{14}/2$; the equator of $\mathcal O_7$ is the **inscribed square**, of side $\sqrt7$ and diagonals $\sqrt{14}$; $\mathcal C$ and $T^+$ give the **circumscribed square**, of side $\sqrt{14}$, turned by $45^\circ$ (the vertices of the inscribed square are the midpoints of the sides of the circumscribed one); two opposite edges of $T^+$ give the **two diagonals** of the circumscribed square.*

*(d) **The centre of the plane circle is the $z$ axis.** Onto the centre fall the two vertices $\pm u_1=\pm P$ of $\mathcal O_7$, at depths $z=\pm\sqrt{14}/2$, and the midpoints of the two edges of $T^+$ that form the diagonals. These two edges do not meet: they lie at heights $z=+R$ and $z=-R$, and their common perpendicular is the diameter $\sqrt{14}$ through the centre of the sphere.*

*Proof.* (a) Two non-antipodal vertices of $\mathcal O_7$ differ by $\pm u_i\mp u_j$: quadrance $2\rho=7$; antipodal ones, $4\rho=14$. The vertices of $\mathcal C$ have quadrance $3\rho$, and $|X\cdot u_i|\le\rho$ defines faces at distance $R$ from the centre. Two vertices of $T^+$ differ in two signs: quadrance $8\rho=28$; the midpoint of each edge is some $\pm u_i$, of quadrance $\rho$, and the edge is perpendicular to it: tangency. (b) $\tfrac12[(1,1,1)+(1,-1,-1)]=(1,0,0)$, and likewise for the six pairs. (c) Projecting along $u_1$ deletes $\alpha$: $\pm u_2,\pm u_3\mapsto(\pm1,0),(0,\pm1)$, with quadrance $2\rho=7$ between neighbours and $4\rho=14$ between opposites; $\mathcal C,T^+\mapsto(\pm1,\pm1)$, a square of side quadrance $4\rho=14$ whose sides $\beta=\pm1$, $\gamma=\pm1$ lie at distance $R$ from the centre: tangent to the circle, with midpoints $(\pm1,0),(0,\pm1)$. The edges $(1,1,1)$–$(1,-1,-1)$ and $(-1,1,-1)$–$(-1,-1,1)$ project onto the diagonals $(1,1)$–$(-1,-1)$ and $(1,-1)$–$(-1,1)$. (d) $\pm u_1\mapsto(0,0)$; the two edges have $\alpha=+1$ and $\alpha=-1$; the segment between their midpoints $u_1$ and $-u_1$ is perpendicular to both and has quadrance $14$. ◻

The classical plane figure, a circle with the inscribed square, the circumscribed square at $45^\circ$ and the two diagonals crossing at the centre, is therefore the shadow of three nested solids. The crossing of the diagonals at the centre is an illusion of the projection: in three dimensions the diagonals pass one above the other, a distance $\sqrt{14}$ apart, and the central “point” is the vertical diameter, whose ends are vertices of the octahedron. The exit through the centre is the exit along the $z$ axis, and it measures $\sqrt{14}$.

![Figure 1: Top: the octahedron $\mathcal O_7$ (blue, height $\sqrt{14}$ in green), the tetrahedron $T^+$ (red) and the cube (dotted) in the sphere $\mathcal{S}$, from three angles. Bottom left: the projection on the $xy$ plane: circle, inscribed square, circumscribed square at $45^\circ$ and the two diagonals (edges of $T^+$, one in front, solid, one behind, dashed). Bottom right: the side view; the centre of the circle is the vertical segment $\sqrt{14}$ between the vertices $\pm P$.](fig_png/fig8_octaedro_projecao_en.png)

**Proposition 3** (the same shadow, different objects). *Let $Q_0$ be the plane figure, in the plane $z=0$, formed by the square with vertices $(\pm R,\pm R,0)$ and its two diagonals, with $z$ along $u_1$ as in Theorem 2. $Q_0$ and the tetrahedron $T^+$ have exactly the same projection on the $xy$ plane: the square of side $\sqrt{14}$ with both diagonals. In $Q_0$ the diagonals cross at the centre; in $T^+$ they do not cross, and the distance between them is $\sqrt{14}$. Therefore the plane figure alone cannot decide whether the diagonals cross: the answer lies on the $z$ axis.*

*Proof.* The vertices of $T^+$ are $R(\varepsilon_1,\varepsilon_2,\varepsilon_3)$ with $\varepsilon_1\varepsilon_2\varepsilon_3=1$; deleting the third coordinate gives the four vertices $(\pm R,\pm R)$ of $Q_0$, and each edge of $T^+$ goes to a side or a diagonal. The edges that give the diagonals lie in the planes $z=R$ and $z=-R$; their common perpendicular has quadrance $4R^2=14$. In $Q_0$ the diagonals lie in one plane and cross at $(0,0,0)$. ◻

**Proposition 4** (the lateral edge crosses the perimeter). *The four lateral edges of $T^+$ cross the equatorial plane $z=0$ exactly at the vertices of the middle square, $(\pm R,0,0)$ and $(0,\pm R,0)$, which lie on the equator circle of $\mathcal{S}$. At these points each edge is perpendicular to the radius and makes $45^\circ$ with the plane of the circle and with its tangent; and it is tangent to the sphere $\mathcal{S}$, touching it only there.*

*Proof.* The edge from $R(1,1,1)$ to $R(1,-1,-1)$ is $R(1,1-2t,1-2t)$; it meets $z=0$ at $t=\tfrac12$, at the point $(R,0,0)$. Its direction $(0,-2,-2)$ has spread $1$ with the radius $(1,0,0)$ and spread $1/2$ with the tangent $(0,1,0)$ and with the axis $(0,0,1)$. Since the point is the foot of the perpendicular from the centre to the edge and lies at distance $R$, the edge is tangent to $\mathcal{S}$. The other three follow by symmetry. ◻

In applied mathematics this is the difference between a right and a wrong result: reconstructing an object from an image, deciding whether two trajectories cross, or locating a point in space from the plane drawing would give, for $T^+$, the wrong answer. Figure 2 shows the same configuration from five angles.

![Figure 2: The tetrahedron $T^+$ (top edge in red, bottom edge in dashed blue, lateral edges in black), the octahedron $\mathcal O_7$ (blue, with the middle square in purple and the axis $\sqrt{14}$ in green) and the equator circle (gold), from five angles. The four lateral edges touch the circle at the vertices of the middle square. Bottom: in the $xy$ plane, the square with diagonals around the circle and the inscribed middle square; in the $xz$ plane, the lateral edge is vertical and touches the circle, and the centre is the axis $\sqrt{14}$; in the vertical plane of the edge, it crosses the perimeter perpendicular to the radius and at $45^\circ$ to the plane.](fig_png/fig13_tetra_octa_circulo_en.png)

**Without $\pi$ and without roots.** No result in this paper uses $\pi$ or the extraction of the square root of an integer that is not a perfect square. Lengths such as $\sqrt{14}$ appear only as names: what is computed is the quadrance $14$. Angles are rational spreads, rotations have rational entries, and every certificate is an equality between integers or fractions. It is in this precise sense that the route of perfect squares dispenses with the circular constant and with roots.

## 5. The regular tetrahedron of edge $7$: the square with its diagonals

**Theorem 5**. *Let $s^2=49/8$ and let $\mathcal T_7$ be the tetrahedron with vertices $s(1,1,1)$, $s(-1,-1,1)$, $s(1,-1,-1)$ and $s(-1,1,-1)$.*

*(a) $\mathcal T_7$ is regular, with six edges of length $7$.*

*(b) Seen from above (projection on the $xy$ plane) it is a square of side $7/\sqrt2$ inscribed in the circle of radius $7/2$, with both diagonals, each of length $7$.*

*(c) The two diagonals are opposite edges at heights $z=+s$ and $z=-s$: they do not touch. In three dimensions the centre of the square is the vertical segment of length $2s=7/\sqrt2$, the common perpendicular of the two edges.*

*(d) Seen along the vertex–face axis, $\mathcal T_7$ is an equilateral triangle inscribed in the circle of radius $7/\sqrt3$, and the fourth vertex falls on the centre, at depth $7\sqrt{2/3}$ (the height of the tetrahedron).*

*Proof.* (a) Vertices differ in two signs: quadrance $8s^2=49$. (b) The projections are $(\pm s,\pm s)$: side $2s$, quadrance $4s^2=49/2$; diagonals of quadrance $8s^2=49$; squared radius $2s^2=49/4$. (c) The edges $s(1,1,1)$–$s(-1,-1,1)$ and $s(1,-1,-1)$–$s(-1,1,-1)$ have $z=s$ and $z=-s$; the segment between the midpoints $(0,0,\pm s)$ is vertical and perpendicular to both. (d) The face opposite $s(1,1,1)$ has centre $-s(1,1,1)/3$; the squared height is $s^2\cdot16/3=98/3$ and the squared face circumradius is $s^2\cdot8/3=49/3$. ◻

The very figure that the plane drawing shows as “an inscribed square with two diagonals pinned in the circle” is, in space, a tetrahedron: the diagonals are pinned neither to the circle nor to each other; they pass at different heights. Every regular tetrahedron is similar to $\mathcal T_7$, and the tetrahedron $T^+$ of Theorem 2 is $\mathcal T_7$ at another scale: a perfect likeness near and far, in the sense of the *Sophist*.

![Figure 3: The regular tetrahedron of edge $7$. Top: four angles, from above to the side: the square with diagonals opens up and shows that the diagonals (red and blue) are at different heights; the $z$ axis in green. Bottom: the $xy$ plane (inscribed square with diagonals $7$), the $xz$ plane (the centre of the square is the segment $7/\sqrt2$) and the view along the vertex–face axis (inscribed triangle with the vertex at the centre, at depth $7\sqrt{2/3}$).](fig_png/fig9_tetraedro7_en.png)

## 6. The exact rotation of cosecant $\sqrt{14}$

For a quaternion $q=\alpha+\beta i+\gamma j+\delta k$, the Euler–Rodrigues matrix $R(q)$ \[4, 5\] satisfies $R(q)/|q|^2\in SO(3)$ and $R(qq')=R(q)R(q')$, and turns about the vector part by twice the half-angle $\omega$, $\cos\omega=\alpha/|q|$.

**Proposition 6**. *The quaternion $q=13+2j+3k$ has norm $182=13\cdot14$ and half-angle $\theta$. The rotation $\mathcal R=R(q)/182$ is $$\mathcal R=\frac1{91}\begin{pmatrix}78&-39&26\\39&82&6\\-26&6&87\end{pmatrix}=\tfrac67 I+\tfrac17\frac{aa^{\mathsf T}}{13}+\tfrac17[a]_\times,$$ with $\mathcal R^{\mathsf T}\mathcal R=I$, $\det\mathcal R=1$, $\mathcal Ra=a$, $\operatorname{tr}\mathcal R=19/7$: the rotation by $2\theta$ about $a$, with no $\pi$, no numerical sine and no root.*

*Proof.* The half-angle has $\sin^2\omega=13/182=1/14$. The second form is Rodrigues’ formula with $\cos2\theta=6/7$ and $\sin2\theta/\sqrt{13}=1/7$. The identities are checked in integers: $MM^{\mathsf T}=91^2I$, $Ma=91a$. ◻

## 7. Exact powers and the $7$-adic valuation

**Lemma 7**. *For $n\ge0$, $\mathcal R^n=c_nI+(1-c_n)\frac{aa^{\mathsf T}}{13}+\sigma_n[a]_\times$, with $c_n=T_n(6/7)$, $\sigma_n=U_{n-1}(6/7)/7$, and $P_n=\mathcal R^nP=\bigl(\tfrac{c_n}2,\ 1+\tfrac32\sigma_n,\ \tfrac32-\sigma_n\bigr)$.*

*Proof.* $\cos2n\theta=T_n(\cos2\theta)$ and $\sin2n\theta/\sqrt{13}=\sigma_n$; with $a\cdot P=13/2$ and $a\times P=(0,\tfrac32,-1)$, $P_n=c_nP+(1-c_n)\tfrac a2+\sigma_n(0,\tfrac32,-1)$. ◻

**Lemma 8**. *$C_n=7^nT_n(6/7)$ and $D_k=7^kU_k(6/7)$ are integers, with $C_{n+1}=12C_n-49C_{n-1}$, $D_{k+1}=12D_k-49D_{k-1}$, $C_0=1$, $C_1=6$, $D_0=1$, $D_1=12$; and $C_n\equiv6\cdot5^{n-1}$, $D_k\equiv5^k\pmod7$. Hence $7\nmid C_n$ and $7\nmid D_k$.*

*Proof.* Modulo $7$, $49\equiv0$ and $12\equiv5$. ◻

## 8. The loop theorem

**Theorem 9** (the loop of cosecant $\sqrt{14}$). *Let $P_n=\mathcal R^nP$.*

*(a) Every $P_n$ is rational, lies on $\mathcal{S}$ and on the circle $C=\mathcal{S}\cap\{X\cdot a=13/2\}$, with centre $a/2$ and radius $\tfrac12$, whose diameter is the edge $PP'$.*

*(b) For $n\ge1$ the common denominator of $P_n$ is exactly $2\cdot7^n$.*

*(c) The $P_n$ are pairwise distinct: $\mathcal R^n\ne I$ for all $n\ge1$; the path never returns to $P$, never reaches $P'$ and, after the first step, never again meets an integer point of $2\mathcal{S}$, in particular none of the $48$ points of shell $14$.*

*(d) $\theta/\pi$ is irrational and $\{P_n\}$ is dense in $C$: the loop does not close, and the circle is the closure of this open path.*

*Proof.* (a) $\mathcal R$ preserves $X\cdot X$ and fixes $a$; for $X\in C$, $|X-a/2|^2=7/2-13/2+13/4=1/4$. (b) By the lemmas, $P_n=\bigl(\frac{C_n}{2\cdot7^n},\frac{2\cdot7^n+3D_{n-1}}{2\cdot7^n},\frac{3\cdot7^n-2D_{n-1}}{2\cdot7^n}\bigr)$, with numerators prime to $7$; by parity ($C_n$ is odd iff $n$ is even, $D_k$ is odd iff $k$ is even) some coordinate has denominator $2\cdot7^n$. (c) Distinct denominators give distinct points; if $\mathcal R^m=I$, then $P_m=P$, absurd. (d) If $\theta/\pi\in\mathbb{Q}$, some power would be $I$; by Kronecker’s theorem \[7\] the orbit is dense. ◻

**Two further proofs of (c).** By Niven \[6\]: $2\cos2\theta=12/7$ is not an integer, so $2\theta$ is not a rational fraction of a turn. By rank one modulo $7$: $M=91\mathcal R$ has $M^2\equiv2M\not\equiv0\pmod7$, so $M^n\equiv2^{n-1}M\not\equiv0$, while $91^nI\equiv0$.

The first points are $(\tfrac12,1,\tfrac32)$, $(\tfrac37,\tfrac{17}{14},\tfrac{19}{14})$, $(\tfrac{23}{98},\tfrac{67}{49},\tfrac{123}{98})$, $(-\tfrac9{343},\tfrac{971}{686},\tfrac{839}{686})$. Up to $n=2000$ the best approach to closing is $n=778$, at $0.115^\circ$; in every case $1-\cos2n\theta$ is an exactly positive rational.

![Figure 4: The $1\times2\times3$ box in $\mathcal{S}$, the triangle $-P,P',P$ (gold), the diagonal $\sqrt{14}$ (red), the axis $a$ (green) and the circle $C$ with the points $P_0,\dots,P_{24}$; inset: the first twelve steps.](fig_png/fig1_caixa_loop_3d_en.png)

![Figure 5: The loop in the plane of $C$: twelve steps do not close; two thousand distinct points fill the circle; closing happens only through the half-turn, which takes $P$ to $P'$ through the centre.](fig_png/fig2_loop_plano_en.png)

## 9. Where the loop closes: through the half-turn across the centre

**Proposition 10**. *With $b=1+2j+3k$, the quaternion of the box edges, of norm $14$: $(13+2j+3k)(1+2j+3k)=14(2j+3k)$. Hence $\mathcal R\,\mathcal R_b=H=(2aa^{\mathsf T}-13I)/13$, the half-turn about $a$, with $HP=P'$ and $H^2=I$: the loop closes in four steps.*

*Proof.* With $v=2j+3k$, $v^2=-13$, $(13+v)(1+v)=14v$; a pure quaternion is a half-turn. $H$ is the bridge with axis $P+P'=a$ \[1, Theorem C5\]. ◻

The tangents of the half-angles of $q$ and $b$ are $1/\sqrt{13}$ and $\sqrt{13}$, reciprocal; they add to a quarter turn, and the composition crosses the centre of the circle $C$.

## 10. External and internal tangents: the exit through the centre

**Proposition 11**. *Let $X=(2,3,6)$, $|X|^2=49$, and $T=(1,\tfrac32,-\tfrac12)$, a vertex of the $2\times3\times1$ box centred at the origin. Then $T\in\mathcal{S}$ and $T\cdot(X-T)=0$ (the radius $OT$ is perpendicular to the tangent $XT$); the external tangent $XT$ makes with the axis $XO$ the angle of spread $1/14$, that is, $\csc\theta=\sqrt{14}$; the triangle $O,T,X$ has quadrances $7/2,\,91/2,\,49$, proportional to $1,13,14$; the inner point $X'=\rho X/|X|^2=X/14$ is the inverse of $X$, with $|OX'|\cdot|OX|=\tfrac12\cdot7=R^2$; and all tangents from $X$ touch $\mathcal{S}$ on the circle with centre $X'$ and radius $\sqrt{13}/2$, in the polar plane $X\cdot Y=\rho$.*

*Proof.* $T\cdot T=T\cdot X=7/2$; the triangle is right-angled at $T$ and $\sin^2\theta=(7/2)/49$; the contact radius is $\sqrt{\rho-1/4}$. ◻

The *external* tangents leave $X$, outside the ball, with cosecant $\sqrt{14}$ relative to the axis; the *inner* point $X'$ is the centre of their contact circle. Inversion exchanges the two, by the same law that takes the insphere of the disphenoid, radius $3/7$, to the polar circumsphere, radius $49/6$: $\tfrac37\cdot\tfrac{49}6=\tfrac72$ \[1, Sec. 21.6\]. The axis $X\to X'\to O\to-X'\to-X$ crosses the centre, and the jump $J=-I$ repeats the cone on the other side. Seen along the axis, the external tangents are radii leaving the centre of the circle outwards.

![Figure 6: The cone of external tangents to $\mathcal{S}$ from $X=(2,3,6)$, cosecant $\sqrt{14}$; contact circle centred at $X'=X/14$; the axis crosses the centre to $-X$.](fig_png/fig3_cone_tangentes_3d_en.png)

![Figure 7: Section through the axis and view along the axis: $X$, $X'$ and $O$ fall on the centre, and every external tangent becomes a radius.](fig_png/fig4_secao_projecao_en.png)

## 11. Sine zero, cosecant $1$ and cosecant $\sqrt{14}$

**Proposition 12**. *In the triangle $O,T,X$, with $OX$ as the $z$ axis:*

*(a) **Sine zero belongs to the axis.** Every direction along the axis has spread $0$ with it; every rotation about the axis fixes it pointwise, and the screw motion $Y\mapsto\mathcal RY+a$ maps the axis $a$ into itself. A point moving along the $z$ axis turns with everything and keeps sine zero; seen from above, it is the centre.*

*(b) **Cosecant $1$ belongs to the radius and the tangent:** $OT\perp XT$ at every point of contact.*

*(c) **Cosecant $\sqrt{14}$ belongs to the external tangent and the axis:** $XT$ has length $\sqrt{91/2}$, advances $13/2$ along the axis and projects onto the plane with length $\sqrt{13}/2$, so $\csc\theta=|XT|/(\text{projection})=\sqrt{14}$.*

**Proposition 13**. *No angle has both sine zero and cosecant $\sqrt{14}$ (nor cosecant $1$), since $\sin\alpha\cdot\csc\alpha=1$ whenever the cosecant exists.*

The three statements of the thesis live in the same triangle but belong to different angles: the axis has sine zero, the radius makes cosecant $1$ with the tangent, the external tangent makes cosecant $\sqrt{14}$ with the axis. In the projection onto the $xy$ plane the axis shrinks to a point, and only cosecant $1$ remains visible.

**The helix.** $Y_n=\mathcal R^nP+n\,a$ rises $13$ per step along the axis ($Y_n\cdot a=13/2+13n$) and projects onto the orbit of Theorem 9; each step has a chord of quadrance $1/14$ in the plane and total quadrance $183/14$. The helix does not close in space, and its projection, the circle, does not close either.

![Figure 8: The helix and its projection: the plane circle is the shadow of a path that rises along the $z$ axis and never closes.](fig_png/fig5_helice_en.png)

## 12. Theodorus and the tetrahedron of edge $\sqrt7$

**Theorem 14**. *The Theodorus step $n\to n+1$ ($\csc\theta_n=\sqrt{n+1}$, $\cos2\theta_n=\frac{n-1}{n+1}$), repeated as a turn, closes the loop if and only if $n=1$ (a $90^\circ$ turn, four steps) or $n=3$ ($60^\circ$, six steps). For $n=13$, cosecant $\sqrt{14}$, it never closes.*

*Proof.* $2\cos2\theta_n$ must be an integer: $(n+1)\mid2(n-1)$, that is, $(n+1)\mid4$. ◻

In the octahedron $\mathcal O_7$, the four tetrahedra $\operatorname{conv}\{P,-P,\pm u_2,\pm u_3\}$ around the axis $\sqrt{14}$ have the fold $7+7=14$, the step $1\to2$, and close exactly (right dihedral). On the face of the regular tetrahedron of edge $\sqrt7$, the altitude gives the triangle $1,\sqrt3,2$, the step $3\to4$, and six faces close at $60^\circ$. The dihedral angle of the regular tetrahedron has $\cos\delta=1/3$; $T_k(1/3)$ has denominator $3^k$ and never equals $1$: five tetrahedra around an edge leave the gap $\cos5\delta=241/243$.

![Figure 9: The Theodorus steps as turns: $n=1$ closes in a square, $n=3$ in a hexagon, $n=13$ never closes.](fig_png/fig6_teodoro_fecha_en.png)

![Figure 10: Four tetrahedra around the axis $\sqrt{14}$ close the octahedron; five regular tetrahedra around an edge do not close.](fig_png/fig7_tetraedros_en.png)

**The whole spiral.** The complete spiral of Theodorus, read as the circle of side $1$, is developed in the main article \[13\]. There it is proved that, after $N$ segments of side $1$, the point is at quadrance $N$ and each step is tangent to the circle $x^2+y^2=N$; that the spiral is the development of the diagonals of the cubes of dimension $N$ and $N+1$, with triangle $13$ in the $1\times2\times3$ box; that its start is the start of a progression of squares inscribed in and circumscribed about the circles $x^2+y^2=2^j$; that, lifted to the paraboloid $z=x^2+y^2$, it is a $45^\circ$ ramp; and that, in the $3n+1$ problem, every trajectory that reaches $1$, starting from a number that is not a power of $2$, enters the final descent through a perfect square $4^k$.

## 13. General loop criterion

**Theorem 15**. *A rotation with rational entries closes the loop if and only if its trace lies in $\{3,2,1,0,-1\}$ (orders $1,6,4,3,2$).*

*Proof.* $2\cos\varphi=\operatorname{tr}-1$ is rational; if it is an algebraic integer, it is an integer in $[-2,2]$. ◻

  Rotation                                 $\operatorname{tr}$   $2\cos\varphi$    Closes?
  --------------------------------------- --------------------- ---------------- -----------
  $T_{-1,3}$ \[1, Sec. 15.4\]                    $13/23$            $-10/23$        never
  $T_{1,1}$                                     $-11/15$            $-26/15$        never
  $M_3/3$, first Pythagorean cube                 $1/3$              $-2/3$         never
  $M_7/7$, half-turn about the diagonal           $-1$                $-2$        order $2$
  $\mathcal R$, cosecant $\sqrt{14}$             $19/7$              $12/7$         never
  $\mathcal R_b$, box quaternion                 $-5/7$             $-12/7$         never
  Fixed turn of the Cot$\alpha$ spiral         $\sqrt2/2$        $-1+\sqrt2/2$      never

  : Table 1: Audit of rotations; the predicted order agreed with a direct search of up to $60$ powers.

## 14. The phantom: systematic floating-point error

The same rotation $\mathcal R$ was applied $10^6$ times to the vertex $P$ in three forms. In exact fractions the quadrance $|P_n|^2-7/2$ and the height $P_n\cdot a-13/2$ are zero at every step (Theorem 9). In IEEE 754 double precision:

       $n$  matrix $M/91$ in `double`   matrix from $\sin$ and $\cos$ of $2\arcsin(1/\sqrt{14})$
  -------- --------------------------- ----------------------------------------------------------
      $10$     $2.2\times10^{-15}$                        $1.8\times10^{-15}$
    $10^3$     $2.4\times10^{-13}$                        $8.6\times10^{-14}$
    $10^5$     $2.4\times10^{-11}$                        $7.6\times10^{-12}$
    $10^6$     $2.4\times10^{-10}$                        $7.7\times10^{-11}$

  : Table 2: Deviation $||P_n|^2-7/2|$ in floating point. Exact: $0$ at every step.

The deviation grows in proportion to $n$: it is systematic, not random. Up close, at the tenth step, the figure looks perfect; from afar, after a million steps, the point has left the sphere. This is the phantom of the *Sophist* in numerical language. The deviation comes from the finite representation of numbers such as $1/91$, $\cos2\theta$ and $\sin2\theta$; the route of perfect squares, with quadrances and rational rotations, keeps the identity exact. The measurement supports the thesis in the case studied; it does not prove that every computational error comes from the circle.

## 15. Computational verification

Two implementations with no shared code check the statements. `loop_csc14.py` (Python, exact fractions) performs $25\,035$ exact checks, including the projections of the octahedron, the cube, $T^+$ and $\mathcal T_7$, the loop up to $n=2000$, the tangents and the helix, with no failure, and catches $16$ deliberate sabotages. `confere_loop_csc14.c` (C) proves non-closure for every $n$ through the modulo-$7$ certificate, checks it up to $n=10^6$ and catches $10$ sabotages. `compara.py` shows that the ten shared keys coincide. `deriva_float.py` produces the table of Section 14.

## 16. Validity and scope

The proofs are complete and use the Euler–Rodrigues formula, Chebyshev polynomials, Niven’s theorem, Kronecker’s theorem, inversion and the geometry of regular solids. The projections of Sections 4 and 5 are elementary facts that this paper organises in the service of the thesis. The loop theorem settles, in the exact form stated here, the question left open in Section 10.3 of \[1\]. Four clarifications: (i) as a point set, the circle is a closed curve; what is proved is that the path by cosecant $\sqrt{14}$ does not close and that the centre of the plane circle is, in space, a segment of the $z$ axis; (ii) sine zero and cosecant $\sqrt{14}$ belong to different angles; (iii) the systematic error was measured in one case, not proved in general; (iv) the consequences expected for physics, transport and artificial intelligence are the author’s theses.

## References

\[1\] COTA, D. C. D. *Matemática da perfeição e da exatidão quadrática* (Mathematics of perfection and quadratic exactness), version 3.4. Brazil, Oct. 16, 2026.

\[2\] PLATO. *Meno*, 82b–85b.

\[3\] PLATO. *Sophist*, 235d–236c.

\[4\] EULER, L. Problema algebraicum ob affectiones prorsus singulares memorabile. *Novi Commentarii Acad. Sci. Petropolitanae* 15 (1771), 75–106.

\[5\] RODRIGUES, O. Des lois géométriques qui régissent les déplacements d’un système solide dans l’espace. *J. Math. Pures Appl.* 5 (1840), 380–440.

\[6\] NIVEN, I. *Irrational Numbers*. Mathematical Association of America, 1956.

\[7\] HARDY, G. H.; WRIGHT, E. M. *An Introduction to the Theory of Numbers*. 6th ed. Oxford, 2008, ch. XXIII.

\[8\] RIVLIN, T. J. *The Chebyshev Polynomials*. Wiley, 1974.

\[9\] WILDBERGER, N. J. *Divine Proportions: Rational Trigonometry to Universal Geometry*. Wild Egg Books, 2005.

\[10\] COXETER, H. S. M. *Regular Polytopes*. 3rd ed. Dover, 1973.

\[11\] PLATO. *Republic*, Book VII, 514a–517a.

\[12\] IEEE. *IEEE Standard for Floating-Point Arithmetic*, IEEE Std 754-2019.

\[13\] COTA, D. C. D. *Proposed solution of the Collatz Conjecture through perfect squares and the mathematics of exactness*. Brazil, Oct. 21, 2026.

## Authorship statement

The thesis, the formulation of the problems, the sphere of diameter $\sqrt{14}$ and the geometric proposals are by Davi Cançado Dutra Cota. The proofs, the verification programs and the figures were prepared with the help of the AI assistant Claude (Anthropic) and checked by execution.

*Jesus Christ is THE LORD.*

*The stone rejected by the builders is now the main foundation stone!*
