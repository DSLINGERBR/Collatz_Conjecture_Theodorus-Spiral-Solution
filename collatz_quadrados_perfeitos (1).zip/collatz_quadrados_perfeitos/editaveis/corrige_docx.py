#!/usr/bin/env python3
"""Centraliza o bloco do título (epígrafe, título, subtítulo, autor) e a epígrafe final, com a epígrafe em letra
menor, e corrige no .docx gerado pelo pandoc as violações do esquema OOXML (ISO/IEC 29500) que o validador acusa:
ordem dos filhos em estilos, propriedades de parágrafo, de texto, de célula, configurações e propriedades
de equações; caractere solto dentro de <w:rPr>; w:nsid com 8 dígitos hexadecimais.
A ordem correta é lida dos próprios arquivos XSD (wml.xsd e shared-math.xsd do ISO/IEC 29500-4, transicional,
publicados pela Ecma como ECMA-376, parte 4).
Uso: python3 corrige_docx.py entrada.docx saida.docx [pasta_xsd]
A pasta dos esquemas também pode ser dada pela variável de ambiente OOXML_XSD."""
import os
import re
import sys
import zipfile
import lxml.etree as E

XS = "{http://www.w3.org/2001/XMLSchema}"
W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
M = "http://schemas.openxmlformats.org/officeDocument/2006/math"
entrada, saida = sys.argv[1], sys.argv[2]
pasta = sys.argv[3] if len(sys.argv) > 3 else os.environ.get("OOXML_XSD", "schemas/ISO-IEC29500-4_2016")
if not os.path.isfile(os.path.join(pasta, "wml.xsd")):
    sys.exit(f"esquemas XSD não encontrados em '{pasta}': indique a pasta como 3º argumento ou em OOXML_XSD")


class Esquema:
    def __init__(self, arquivo, ns):
        self.raiz = E.parse(arquivo).getroot()
        self.ns = ns
        self.tipos = {t.get("name"): t for t in self.raiz.iter(XS + "complexType") if t.get("name")}
        self.grupos = {g.get("name"): g for g in self.raiz.iter(XS + "group") if g.get("name")}

    def ordem(self, tipo):
        nomes = []

        def anda(no):
            for f in no:
                if f.tag == XS + "element":
                    n = (f.get("name") or f.get("ref")).split(":")[-1]
                    if n not in nomes:
                        nomes.append(n)
                elif f.tag in (XS + "sequence", XS + "choice", XS + "all"):
                    anda(f)
                elif f.tag == XS + "group" and f.get("ref"):
                    anda(self.grupos[f.get("ref").split(":")[-1]])
                elif f.tag in (XS + "complexContent", XS + "extension"):
                    if f.tag == XS + "extension":
                        base = f.get("base").split(":")[-1]
                        if base in self.tipos:
                            anda(self.tipos[base])
                    anda(f)
        anda(self.tipos[tipo])
        return nomes


wml = Esquema(f"{pasta}/wml.xsd", W)
mat = Esquema(f"{pasta}/shared-math.xsd", M)
REGRAS = {  # (namespace, elemento): (esquema, tipo)
    (W, "style"): (wml, "CT_Style"), (W, "pPr"): (wml, "CT_PPr"), (W, "rPr"): (wml, "CT_RPr"),
    (W, "tcPr"): (wml, "CT_TcPr"), (W, "settings"): (wml, "CT_Settings"), (W, "tblPr"): (wml, "CT_TblPr"),
    (W, "trPr"): (wml, "CT_TrPr"), (W, "tblStylePr"): (wml, "CT_TblStylePr"),
    (M, "rPr"): (mat, "CT_RPR"), (M, "dPr"): (mat, "CT_DPr"), (M, "mcPr"): (mat, "CT_MCPr"),
    (M, "mPr"): (mat, "CT_MPr"),
}
ORDENS = {k: esq.ordem(t) for k, (esq, t) in REGRAS.items()}
CONTEINERES = {(W, "rPr"), (W, "pPr"), (W, "style"), (W, "tcPr"), (W, "tblPr"), (W, "trPr")}


def corrige_arvore(raiz):
    trocas = 0
    for el in raiz.iter():
        if not isinstance(el.tag, str):
            continue
        q = E.QName(el)
        chave = (q.namespace, q.localname)
        if chave in CONTEINERES:
            if el.text and el.text.strip():
                el.text = None; trocas += 1
            for f in el:
                if f.tail and f.tail.strip():
                    f.tail = None; trocas += 1
        if chave == (M, "rPr") and el.find(f"{{{M}}}nor") is not None:     # texto normal: nor exclui scr/sty
            for f in el.findall(f"{{{M}}}sty") + el.findall(f"{{{M}}}scr"):
                el.remove(f); trocas += 1
        if chave in ORDENS:
            ordem = ORDENS[chave]
            filhos = list(el)
            pos = lambda f: ordem.index(E.QName(f).localname) if isinstance(f.tag, str) and E.QName(f).localname in ordem else len(ordem)
            novos = sorted(filhos, key=pos)
            if [id(f) for f in novos] != [id(f) for f in filhos]:
                for f in filhos:
                    el.remove(f)
                for f in novos:
                    el.append(f)
                trocas += 1
        if chave == (W, "nsid"):
            v = el.get(f"{{{W}}}val")
            if v and len(v) < 8:
                el.set(f"{{{W}}}val", v.upper().zfill(8)); trocas += 1
    return trocas


EPIGRAFE = ("Jesus Cristo é O SENHOR", "A pedra que os construtores", "Jesus Christ is THE LORD", "The stone rejected by the builders")


def texto_de(p):
    return "".join(t.text or "" for t in p.iter(f"{{{W}}}t"))


def estilo(p):
    s = p.find(f"{{{W}}}pPr/{{{W}}}pStyle")
    return s.get(f"{{{W}}}val") if s is not None else None


def centra(p, pequeno):
    """Alinha o parágrafo ao centro; na epígrafe, letra de 10 pt (w:sz em meios-pontos)."""
    ppr = p.find(f"{{{W}}}pPr")
    if ppr is None:
        ppr = E.Element(f"{{{W}}}pPr")
        p.insert(0, ppr)
    jc = ppr.find(f"{{{W}}}jc")
    if jc is None:
        jc = E.SubElement(ppr, f"{{{W}}}jc")
    jc.set(f"{{{W}}}val", "center")
    if pequeno:
        for r in p.iter(f"{{{W}}}r"):
            rpr = r.find(f"{{{W}}}rPr")
            if rpr is None:
                rpr = E.Element(f"{{{W}}}rPr")
                r.insert(0, rpr)
            for nome in ("sz", "szCs"):
                e = rpr.find(f"{{{W}}}{nome}")
                if e is None:
                    e = E.SubElement(rpr, f"{{{W}}}{nome}")
                e.set(f"{{{W}}}val", "20")


def centraliza(raiz):
    """Bloco do título: os parágrafos antes do primeiro Heading2 (Resumo/Abstract). Fim: a epígrafe final."""
    corpo = raiz.find(f"{{{W}}}body")
    ps = [p for p in corpo if E.QName(p).localname == "p"]
    n = 0
    for p in ps:
        if estilo(p) == "Heading2":
            break
        centra(p, texto_de(p).strip().startswith(EPIGRAFE)); n += 1
    for p in ps[-3:]:
        if texto_de(p).strip().startswith(EPIGRAFE):
            centra(p, True); n += 1
    return n


total = 0
with zipfile.ZipFile(entrada) as zi, zipfile.ZipFile(saida, "w", zipfile.ZIP_DEFLATED) as zo:
    for item in zi.infolist():
        dados = zi.read(item.filename)
        if item.filename in ("word/document.xml", "word/styles.xml", "word/settings.xml", "word/numbering.xml"):
            raiz = E.fromstring(dados)
            if item.filename == "word/document.xml":
                total += centraliza(raiz)
            total += corrige_arvore(raiz)
            dados = E.tostring(raiz, xml_declaration=True, encoding="UTF-8", standalone=True)
        if item.filename == "[Content_Types].xml":
            texto = dados.decode("utf-8")
            for ext, tipo in (("png", "image/png"), ("jpeg", "image/jpeg"), ("jpg", "image/jpeg")):
                if f'Extension="{ext}"' not in texto and any(n.lower().endswith("." + ext) for n in zi.namelist()):
                    texto = texto.replace("<Default ", f'<Default Extension="{ext}" ContentType="{tipo}" /><Default ', 1)
                    total += 1
            dados = texto.encode("utf-8")
        zo.writestr(item, dados)
print(f"{saida}: {total} correções")
