*Jesus Christ is THE LORD.*

*The stone rejected by the builders is now the main foundation stone!*

# Proposed solution of the Collatz Conjecture through perfect squares and the mathematics of exactness

**The plane circle is a projection: the tetrahedron, the octahedron and the cosecant $\sqrt{14}$ as the exit through the centre, and the spiral of Theodorus of side $1$**

Davi Cançado Dutra Cota — Brazil — October 21, 2026

## Abstract

The author presents a proposed solution of the Collatz conjecture built through perfect squares, that is, by measuring quadrances (squared distances) and spreads (squared sines), without $\pi$ and without approximated roots. The theoretical framework proves that the plane circle is a projection. The regular tetrahedron, seen from above, is the square with both diagonals; in space, the diagonals are opposite edges that do not touch, the centre of the square is a segment of the $z$ axis, and the lateral edges cross the perimeter of the circle perpendicular to the radius and at $45^\circ$ to the plane; the midpoints of the six edges are the vertices of a regular octahedron. On the sphere of diameter $\sqrt{14}$, which circumscribes the $1\times2\times3$ box, the circle with the inscribed square, the square circumscribed at $45^\circ$ and the two diagonals is the exact shadow of the octahedron of height $\sqrt{14}$, of the cube and of the tetrahedron, and the centre of the plane circle is the vertical diameter $\sqrt{14}$. The turn of cosecant $\sqrt{14}$, that of the triangle $1,\sqrt{13},\sqrt{14}$ of the box, never closes: its points have exact denominator $2\cdot7^n$; the path closes through the half-turn that passes through the centre, and the external tangents of cosecant $\sqrt{14}$, with the external point from which they issue and its inverse inside the sphere, show the exit through the centre. The spiral of Theodorus, always of side $1$, reads the circle without closing it: after $N$ segments the quadrance is $N$; its start is that of a progression of inscribed and circumscribed squares; lifted to the paraboloid $z=x^2+y^2$, it climbs at $45^\circ$. In the $3n+1$ problem, with $N$ as the number of segments of side $1$, it is proved that every trajectory that reaches $1$, starting from a number that is not a power of $2$, enters the final descent through a perfect square $4^k$, on a circle of integer radius, and walks down the progression of squares to the initial point. Building on this way out of the circle, constructed step by step, the author states his proposed solution. The identities and the counts are checked with exact integers and fractions by independent programs, with the doors counted up to $10^9$ and the trajectories up to $10^{10}$.

## 1. Thesis, principles and results

**Author’s thesis 1**. Plane geometry is the projection, onto the $xy$ plane, of spatial geometry ($x,y,z$), and must be understood as such. The plane circle is a projection: the path on it does not close and has an exit through the centre, along the $z$ axis, by the square root of fourteen. The spiral of Theodorus, always of side $1$, is a specific way of understanding the circle: each circle is read by a point and by a tangent of side $1$, and the figure moves on without ever closing. The mathematics of the circle carried out with approximated $\pi$, sines and roots is a source of systematic errors in computation, and the remedy is the route of perfect squares. Thinking with depth, without $\pi$ and without roots of integers that are not perfect squares, will open paths in physics, including quantum physics, in transport, in systems that demand precision and in artificial intelligence models. The closed circle is useful for teaching; as a basis for scientific and technological development, it is a source of error. It is time to leave Plato’s cave.

This article gathers, in a single construction, the theoretical framework of this thesis and its application to the $3n+1$ problem. The following are proved:

\(a\) the plane circle as a projection: the regular tetrahedron of edge $7$ and its shadow, the square with both diagonals, with the crossing of the lateral edges on the perimeter and the octahedron of the midpoints (Theorems 3 to 8); on the sphere of diameter $\sqrt{14}$, the octahedron of height $\sqrt{14}$, the cube and the tetrahedron (Theorem 9);

\(b\) the turn of cosecant $\sqrt{14}$, which never closes (Theorem 13), and the exit through the centre: the half-turn, the external tangents, the inversion and the separation of sine zero, cosecant $1$ and cosecant $\sqrt{14}$ (Propositions 15 to 18);

\(c\) the spiral of Theodorus by quadrance and its geometric readings: the development of the diagonals of the cubes, the progression of inscribed and circumscribed squares, the lift to the paraboloid and the gap $\pi$ between the turns (Theorems 19 to 27 and Proposition 28);

\(d\) the $3n+1$ problem in the language of Theodorus: the dictionary, the matchstick count, the door theorem through the perfect square, the rare doors and the reformulation of the conjecture (Proposition 30, Theorems 31 and 33, Corollary 32 and Proposition 34);

\(e\) the comparison with the neighbouring maps $3n-1$ and $5n+1$ (Theorem 35).

Section 3 shows the construction of the proof step by step; Section 13 states the author’s proposed solution; Section 17 gathers his principles and arguments.

## 2. Foundation: the Meno, the Sophist and the route of perfect squares

**Meno (82b–85b).** Socrates asks a young slave how to build a square of double area. Doubling the side quadruples the area; the square of double area is built on the diagonal \[2\]. The mathematical lesson is exact: the length of the diagonal of the unit square is not rational, but its square is $2$, an integer. Working with the squares of the measures, the quadrances, keeps the whole construction in the integers.

**Sophist (235d–236c).** The Stranger distinguishes two arts of images. The first is the art of likeness-making, which succeeds best when it reproduces the proportions of the original in length, breadth and depth; the second produces what only seems like the original when seen from an unfavourable position, and deserves the name of semblance, since it only appears to resemble without really resembling \[3\]. The author calls this semblance a *phantom*: beautiful from afar, crooked up close.

**Republic (514a–517a).** In the allegory of the cave, prisoners who see only shadows cast on a wall take the shadows for reality \[4\]. The geometric reading of this paper is literal: the plane figure is the shadow, on the $xy$ plane, of a solid; leaving the cave means recovering the $z$ axis.

**Mathematical translation.** A figure is a *likeness* when its relations hold at every scale, near and far: these are the similarity relations, ratios of quadrances and spreads, which a uniform change of scale leaves unchanged. A computation is a *phantom* when it looks right at the coarse scale and drifts at the fine scale: this is what a rounded number repeated many times does (Section 15). The route of perfect squares represents lengths by quadrances and angles by spreads, which are rational whenever the points are rational, and uses rotations with rational entries. Along this route the identities hold exactly at every step.

**Notation.** The quadrance of a vector $u$ is $u\cdot u$, the squared distance. The spread between $u$ and $v$ is $s(u,v)=1-(u\cdot v)^2/((u\cdot u)(v\cdot v))=\sin^2\angle(u,v)$, rational for rational data \[6\]. The sphere is $\mathcal{S}\colon X\cdot X=\rho$, $\rho=7/2$, radius $R=\sqrt{14}/2$. The centred $1\times2\times3$ box has vertices $(\pm\tfrac12,\pm1,\pm\tfrac32)$ on $\mathcal{S}$; $P=(\tfrac12,1,\tfrac32)$, $P'=(-\tfrac12,1,\tfrac32)$, $d=2P=(1,2,3)$, $a=P+P'=(0,2,3)$. $T_n$, $U_n$ are the Chebyshev polynomials \[7\].

## 3. The construction of the proof, step by step

Before the complete proofs, this section shows how the construction fits together. Each step is an exact computation with quadrances; next to it is the section where it is proved in full.

**Step 1. The unit, the right angle and the diagonal.** Two segments of side $1$ at a right angle form the triangle whose hypotenuse has quadrance $1+1=2$: the diagonal of the unit square. The square built on it has area $2$, twice that of the unit square, as in the *Meno* (Section 2). The number $2$ is the quadrance; no root is computed.

**Step 2. The $1\times2\times3$ box and the triangle $1,\sqrt{13},\sqrt{14}$.** Adding three squares, $1+4+9=14$: the diagonal of the box with edges $1$, $2$, $3$ has quadrance $14$, the diagonal of the $2\times3$ face has quadrance $13$, and the edge $1$ completes the right triangle with quadrances $1$, $13$, $14$. The angle opposite the edge $1$ has spread $1/14$: cosecant $\sqrt{14}$. With the centre of the box at the origin, the eight vertices lie on the sphere $\mathcal{S}\colon x^2+y^2+z^2=7/2$, of diameter $\sqrt{14}$ (Section 4).

**Step 3. The plane circle is a shadow: the tetrahedron and the octahedron.** The regular tetrahedron with vertices $s(1,1,1)$, $s(-1,-1,1)$, $s(1,-1,-1)$, $s(-1,1,-1)$, seen from above, is the square with both diagonals. In space, the diagonals are opposite edges, one at height $+s$ and the other at height $-s$: they do not touch, and the “point” where they seem to cross is the vertical segment that joins them. The four lateral edges cross the plane of the circle exactly on the perimeter, perpendicular to the radius and at $45^\circ$ to the plane. The midpoints of the six edges are the vertices of a regular octahedron, whose axis is this central segment. At the scale of the sphere $\mathcal{S}$, the axis of the octahedron is the diameter $\sqrt{14}$: the centre of the plane circle is a segment of the $z$ axis (Sections 5 and 6).

**Step 4. The turn of cosecant $\sqrt{14}$ never closes.** The rotation by the angle $2\theta$, with $\sin^2\theta=1/14$, about the axis $a=(0,2,3)$ has the rational matrix $M/91$, with $M$ an integer matrix, and $\cos2\theta=6/7$. Starting from the vertex $P=(\tfrac12,1,\tfrac32)$ of the box, the $n$-th point has denominator exactly $2\cdot7^n$: the points never repeat, and the loop does not close. By Niven’s theorem, a rational turn closes only if twice its cosine is an integer, and $2\cos2\theta=12/7$ is not (Section 7).

**Step 5. The exit through the centre.** The path that does not close by turning closes when it passes through the centre: the quaternion of the turn, $13+2j+3k$, multiplied by the quaternion of the edges of the box, $1+2j+3k$, gives $14(2j+3k)$, a half-turn, which takes $P$ to the point $P'=(-\tfrac12,1,\tfrac32)$, diametrically opposite on the circle of the loop, whose centre is $a/2$. From the external point $X=(2,3,6)$, of quadrance $49$, the tangents to the sphere make with the axis the angle of cosecant $\sqrt{14}$; inversion in the sphere takes $X$ to the inner point $X'=X/14$, with $|OX'|\cdot|OX|=\tfrac12\cdot7=7/2=R^2$. The axis crosses the centre: this is the exit through the centre (Section 8).

**Step 6. The circle of side $1$.** The spiral of Theodorus adds, at each step, a segment of side $1$ perpendicular to the radius: after $N$ segments the quadrance is $N$, and triangle $13$ is the triangle $1,\sqrt{13},\sqrt{14}$ of Step 2. The spiral reads each circle $x^2+y^2=N$ at a single point, along the tangent, and never closes; its initial point is the vertex of a progression of inscribed and circumscribed squares; lifted to the paraboloid, it climbs at $45^\circ$ (Sections 9 and 10).

**Step 7. The $3n+1$ problem.** With $N$ as the number of segments of side $1$, the odd step $3N+1$ is the number of matchsticks in a row of $N$ squares, and the even step $N/2$ takes the circle to the circle inscribed in its inscribed square. Every trajectory that reaches $1$, starting from a number that is not a power of $2$, enters the final descent through the perfect square $4^k$, on a circle of integer radius, and walks down the progression of squares to the initial point (Sections 11 and 12).

**Step 8. The author’s proposal.** Building on the way out of the circle constructed in Steps 1 to 7, the author states his proposed solution of the Collatz conjecture (Section 13).

## 4. The $1\times2\times3$ box, the sphere of diameter $\sqrt{14}$ and the triangle $1,\sqrt{13},\sqrt{14}$

**Proposition 1**. *The triangle $-P$, $P'$, $P$ has quadrances $1$, $13$, $14$, a right angle at $P'$, and the angle $\theta$ at $-P$, opposite the leg $1$, satisfies $\sin^2\theta=1/14$, $\csc\theta=\sqrt{14}$, $\tan\theta=1/\sqrt{13}$, $\cos2\theta=6/7$.*

*Proof.* $P-P'=(1,0,0)$, $P'+P=a$, $2P=d$; $(1,0,0)\cdot a=0$; at $-P$, $s(d,a)=1-13^2/(14\cdot13)=1/14$; $\cos2\theta=1-2\sin^2\theta$. ◻

The leg $1$ is an edge of the box, the leg $\sqrt{13}$ is a diagonal of the $2\times3$ face, and the hypotenuse $\sqrt{14}$ is the diagonal through the centre of the sphere: it is the step $13+1=14$ of Theodorus.

## 5. The regular tetrahedron: the square with both diagonals is the shadow of a solid

This section proves the thesis in an exemplary and complete case: the square with both diagonals. The word “projection” has here the precise meaning of the map $\operatorname{pr}(x,y,z)=(x,y)$, which forgets depth.

### 5.1 The tetrahedron of edge $7$

Let $s>0$ with $s^2=49/8$, that is, $s=7/(2\sqrt2)$, and $$A=s(1,1,1),\quad B=s(-1,-1,1),\quad C=s(1,-1,-1),\quad D=s(-1,1,-1).$$

**Proposition 2**. *$ABCD$ is a regular tetrahedron of edge $7$. Its edges $AB$ and $CD$ are horizontal, at heights $z=s$ and $z=-s$; the other four, $AC$, $AD$, $BC$, $BD$, join height $s$ to height $-s$ and are called here the lateral edges.*

*Proof.* Two vertices differ in exactly two coordinates, by $\pm2s$: quadrance $8s^2=49$. The $z$ coordinates of $A,B$ are $s$ and those of $C,D$ are $-s$. ◻

Every regular tetrahedron is similar to this one; the choice of the edge $7$ only fixes the unit. The ratios of quadrances and the spreads are the same at every scale: the figure is a perfect likeness near and far.

### 5.2 Seen from above: the square with both diagonals

**Theorem 3**. *The projection $\operatorname{pr}(ABCD)$ on the $xy$ plane is the square with vertices $(\pm s,\pm s)$, of side $2s=7/\sqrt2$, with both diagonals $\operatorname{pr}(AB)$ and $\operatorname{pr}(CD)$, each of length $7$. The square is inscribed in the circle $\Gamma_V$ of radius $7/2$ and circumscribed about the circle $\Gamma_T$ of radius $s=7/(2\sqrt2)$.*

*Proof.* $\operatorname{pr}(A)=(s,s)$, $\operatorname{pr}(B)=(-s,-s)$, $\operatorname{pr}(C)=(s,-s)$, $\operatorname{pr}(D)=(-s,s)$. The lateral edges project onto the sides (quadrance $4s^2=49/2$) and $AB$, $CD$ onto the diagonals (quadrance $8s^2=49$), which are horizontal and do not shorten. The vertices are at distance $\sqrt{2s^2}=7/2$ from the centre; the sides $x=\pm s$, $y=\pm s$ are at distance $s$. ◻

### 5.3 The diagonals do not cross: the centre is a segment of the $z$ axis

**Theorem 4**. *The lines $AB$ and $CD$ are skew. The point where the diagonals seem to cross in the plane drawing is, in space, the vertical segment from $(0,0,-s)$ to $(0,0,s)$, of length $2s=7/\sqrt2$, which is the common perpendicular of the two edges. The whole fibre $\operatorname{pr}^{-1}(0,0)\cap ABCD$ is this segment.*

*Proof.* $AB$ lies in the plane $z=s$ and $CD$ in the plane $z=-s$: they do not meet. The midpoints are $(0,0,s)$ and $(0,0,-s)$; the segment between them has direction $(0,0,1)$, perpendicular to $AB$, of direction $(1,1,0)$, and to $CD$, of direction $(1,-1,0)$, and quadrance $4s^2=49/2$. For $|z|\le s$, the horizontal section of the tetrahedron at height $z$ is a rectangle centred on the axis, so that the point $(0,0,z)$ belongs to the solid; for $|z|>s$, there is no solid. ◻

The plane drawing collapses into a single point everything that lies along the $z$ axis. That is why, looking only at the plane, the diagonals seem pinned to each other and to the centre of the circle; in space, they pass one above the other, $7/\sqrt2$ apart.

**Proposition 5** (the same shadow, different objects). *The plane figure $Q_0$, in the plane $z=0$, formed by the square with vertices $(\pm s,\pm s,0)$ and its two diagonals, has exactly the same projection on the $xy$ plane as the tetrahedron $ABCD$. In $Q_0$ the diagonals cross at the centre; in the tetrahedron they do not cross and are $7/\sqrt2$ apart. The plane figure alone does not decide whether the diagonals cross: the answer lies on the $z$ axis.*

*Proof.* By Theorem 3, the two projections are the same square with the same diagonals. In $Q_0$ the diagonals lie in the plane $z=0$ and cross at $(0,0,0)$; in the tetrahedron they lie in the planes $z=\pm s$ (Theorem 4). ◻

In applied mathematics this is the difference between a right and a wrong result: reconstructing an object from an image, deciding whether two trajectories cross, or locating a point from the plane drawing would give, here, the wrong answer.

![Figure 1: The tetrahedron of edge $7$ from four angles, from the top view to the side view; below, the views in the $xy$ and $xz$ planes and along the vertex–face axis.](fig_png/fig9_tetraedro7_en.png)

### 5.4 How the tetrahedron meets the circle

In the plane $z=0$ we consider the two circles of Theorem 3: $\Gamma_T$, of radius $s$, tangent to the sides of the square in the drawing, and $\Gamma_V$, of radius $7/2$, which passes through the vertices of the square in the drawing.

**Theorem 6** (the crossing). *(a) Each lateral edge crosses the plane $z=0$ at a single point, its midpoint, and this point lies on the perimeter of $\Gamma_T$. The four points are $(\pm s,0,0)$ and $(0,\pm s,0)$.*

*(b) At the crossing point, the edge is perpendicular to the radius of the circle (spread $1$), makes $45^\circ$ with the tangent to the circle (spread $1/2$) and $45^\circ$ with the $z$ axis (spread $1/2$); hence it crosses the plane of the circle at an inclination of $45^\circ$.*

*(c) The lateral edge lies in the vertical plane $x=\pm s$ (or $y=\pm s$), which touches $\Gamma_T$ only at the crossing point; and, at that point, it is tangent to the sphere with centre at the origin and radius $s$, the midsphere of the tetrahedron.*

*(d) The tetrahedron does not touch $\Gamma_V$: the section of the solid by the plane $z=0$ is the square with vertices $(\pm s,0,0)$, $(0,\pm s,0)$, whose farthest point from the centre is at distance $s<7/2$. The vertices of the tetrahedron lie on the vertical cylinder over $\Gamma_V$, at heights $z=\pm s$, above and below the circle.*

*Proof.* Take the edge $AC$, from $s(1,1,1)$ to $s(1,-1,-1)$; the others are analogous by symmetry. (a) Its points are $s(1,1-2t,1-2t)$; $z=0$ only at $t=\tfrac12$, the point $X=(s,0,0)$, at distance $s$ from the axis. (b) The direction of the edge is $d=(0,-2,-2)$; the radius at $X$ is $(1,0,0)$, with $d\cdot(1,0,0)=0$: spread $1$. The tangent to the circle at $X$ is $(0,1,0)$: spread $1-4/8=1/2$. The axis is $(0,0,1)$: spread $1-4/8=1/2$. (c) All points of $AC$ have $x=s$; the plane $x=s$ meets $\Gamma_T$ ($x^2+y^2=s^2$, $z=0$) only at $(s,0,0)$. Since $X\cdot d=0$, $X$ is the foot of the perpendicular from the origin to the line $AC$, and the distance from the origin to the line is $|X|=s$: tangency to the sphere of radius $s$. (d) The horizontal section of the tetrahedron at $z=0$ is the convex hull of the four crossing points; these points are at distance $s$ from the centre, and $s^2=49/8<49/4$. The vertices satisfy $x^2+y^2=2s^2=49/4$ and $z=\pm s\ne0$. ◻

**Answer to the question “does it cross the perimeter perpendicularly?”.** It does cross the perimeter, and exactly: at four points of the circle tangent to the sides. It is perpendicular to the *radius* at these points. It is not perpendicular to the *plane* of the circle nor to its *tangent*: the angle with each of them is $45^\circ$. In the plane drawing the edge looks tangent to the circle; in space it crosses it, rising at $45^\circ$. As for the circle through the vertices of the drawn square, the solid does not touch it: the vertices lie above and below it.

![Figure 2: Left, the four lateral edges cross the plane $z=0$ on the tangent circle (gold points); the dashed circle passes through the shadows of the vertices. Centre, the view from above: the purple side looks tangent to the circle at $(s,0,0)$. Right, the section by the vertical plane $x=s$, which contains the edge: it passes through the only point of the circle in that plane, inclined at $45^\circ$.](fig_png/fig10_cruzamento_en.png)

### 5.5 Turning the solid: from the square to the triangle with the vertex at the centre

**Theorem 7**. *Projected along the line that joins the vertex $A$ to the centre of the opposite face $BCD$, the tetrahedron is an equilateral triangle inscribed in the circle of radius $7/\sqrt3$, and $A$ falls on the centre of the triangle, at distance $7\sqrt{2/3}$ from the plane of the face (the height of the tetrahedron).*

*Proof.* The centre of $BCD$ is $G=-s(1,1,1)/3$; $A-G=\tfrac43s(1,1,1)$ is perpendicular to $B-G$, $C-G$, $D-G$, and $|A-G|^2=\tfrac{16}3s^2=\tfrac{98}3$. The vertices of the face are at quadrance $\tfrac83s^2=\tfrac{49}3$ from $G$. ◻

The same piece, without changing a single measure, gives in the plane the square with diagonals, the triangle with the vertex at the centre and all the intermediate shapes (Figure 3). What changes is the direction of projection; the quadrances of the six edges remain $49$ in every position. In particular, the centre of the triangle, which in the drawing looks like a point of the plane, is the vertex $A$, at depth $7\sqrt{2/3}$ on the $z$ axis.

![Figure 3: The same tetrahedron of edge $7$ turning (top) and its shadow on the $xy$ plane (bottom): from the square with the diagonals to the triangle with the vertex at the centre.](fig_png/fig11_sombras_en.png)

### 5.6 The link with the octahedron

**Theorem 8**. *The midpoints of the six edges of $ABCD$ are the vertices $(\pm s,0,0)$, $(0,\pm s,0)$, $(0,0,\pm s)$ of a regular octahedron \[8\] of edge $7/2$ and central height $2s=7/\sqrt2$. The four vertices of its equator are the crossing points of Theorem 6, on the circle $\Gamma_T$; the two vertices of its axis are the ends of the central segment of Theorem 4. Seen from above, the equator of the octahedron is the square inscribed in $\Gamma_T$, turned by $45^\circ$ relative to the square of the tetrahedron, which is circumscribed about $\Gamma_T$.*

*Proof.* The midpoints of $AB$ and $CD$ are $(0,0,\pm s)$; those of the four lateral edges are $(\pm s,0,0)$, $(0,\pm s,0)$. Two of these points that are not opposite differ in two coordinates by $s$: quadrance $2s^2=49/4$; opposite ones, $4s^2=49/2$. The vertices of the equator are the midpoints of the sides of the square $(\pm s,\pm s)$. ◻

Thus the two classical squares of the drawing, the inscribed one and the one circumscribed at $45^\circ$, with the circle between them, are the shadow of a single pair of nested solids: the tetrahedron and the octahedron of its midpoints. Over the centre of the circle lie the two vertices of the axis of the octahedron.

![Figure 4: The octahedron of the midpoints (purple) inside the tetrahedron; the axis of the octahedron (green) is the central segment. Seen from above, the equator of the octahedron is the square inscribed in the circle, and the tetrahedron is the circumscribed square with the diagonals.](fig_png/fig12_octaedro_meios_en.png)

## 6. On the sphere of diameter $\sqrt{14}$: the octahedron of height $\sqrt{14}$ and the plane circle as a projection

We use the proper frame of the inscribed octahedron $\mathcal O_7$ \[1, Sec. 21\]: three vectors $u_1=P$, $u_2$, $u_3$ with $u_i\cdot u_j=\rho\,\delta_{ij}$. In coordinates $(\alpha,\beta,\gamma)$ in this frame the true quadrance is $\rho$ times the usual one, and we take the $z$ axis along $u_1$.

**Theorem 9** (the circle, the two squares and the diagonals are a projection). *Let $\mathcal O_7$ be the octahedron with vertices $\pm u_i$, $\mathcal C$ the cube with vertices $\pm u_1\pm u_2\pm u_3$, and $T^+$ the tetrahedron with vertices $u_1+u_2+u_3$, $u_1-u_2-u_3$, $-u_1+u_2-u_3$, $-u_1-u_2+u_3$.*

*(a) $\mathcal O_7$ is regular, inscribed in $\mathcal{S}$, with twelve edges $\sqrt7$ and central height $|u_1-(-u_1)|=\sqrt{14}$, the diameter. $\mathcal C$ has edge $\sqrt{14}$ and faces tangent to $\mathcal{S}$; $T^+$ is regular, with edge $\sqrt{28}$, and has $\mathcal{S}$ as its midsphere.*

*(b) **Perfect link:** the midpoints of the six edges of $T^+$ are exactly the six vertices of $\mathcal O_7$.*

*(c) Projected onto the $xy$ plane (along $u_1$): the outline of $\mathcal{S}$ is the circle of radius $R=\sqrt{14}/2$; the equator of $\mathcal O_7$ is the **inscribed square**, of side $\sqrt7$ and diagonals $\sqrt{14}$; $\mathcal C$ and $T^+$ give the **circumscribed square**, of side $\sqrt{14}$, turned by $45^\circ$ (the vertices of the inscribed square are the midpoints of the sides of the circumscribed one); two opposite edges of $T^+$ give the **two diagonals** of the circumscribed square.*

*(d) **The centre of the plane circle is the $z$ axis.** Onto the centre fall the two vertices $\pm u_1=\pm P$ of $\mathcal O_7$, at depths $z=\pm\sqrt{14}/2$, and the midpoints of the two edges of $T^+$ that form the diagonals. These two edges do not meet: they lie at heights $z=+R$ and $z=-R$, and their common perpendicular is the diameter $\sqrt{14}$ through the centre of the sphere.*

*Proof.* (a) Two non-antipodal vertices of $\mathcal O_7$ differ by $\pm u_i\mp u_j$: quadrance $2\rho=7$; antipodal ones, $4\rho=14$. The vertices of $\mathcal C$ have quadrance $3\rho$, and $|X\cdot u_i|\le\rho$ defines faces at distance $R$ from the centre. Two vertices of $T^+$ differ in two signs: quadrance $8\rho=28$; the midpoint of each edge is some $\pm u_i$, of quadrance $\rho$, and the edge is perpendicular to it: tangency. (b) $\tfrac12[(1,1,1)+(1,-1,-1)]=(1,0,0)$, and likewise for the six pairs. (c) Projecting along $u_1$ deletes $\alpha$: $\pm u_2,\pm u_3\mapsto(\pm1,0),(0,\pm1)$, with quadrance $2\rho=7$ between neighbours and $4\rho=14$ between opposites; $\mathcal C,T^+\mapsto(\pm1,\pm1)$, a square of side quadrance $4\rho=14$ whose sides $\beta=\pm1$, $\gamma=\pm1$ lie at distance $R$ from the centre: tangent to the circle, with midpoints $(\pm1,0),(0,\pm1)$. The edges $(1,1,1)$–$(1,-1,-1)$ and $(-1,1,-1)$–$(-1,-1,1)$ project onto the diagonals $(1,1)$–$(-1,-1)$ and $(1,-1)$–$(-1,1)$. (d) $\pm u_1\mapsto(0,0)$; the two edges have $\alpha=+1$ and $\alpha=-1$; the segment between their midpoints $u_1$ and $-u_1$ is perpendicular to both and has quadrance $14$. ◻

The classical plane figure, a circle with the inscribed square, the circumscribed square at $45^\circ$ and the two diagonals crossing at the centre, is therefore the shadow of three nested solids. The crossing of the diagonals at the centre is an illusion of the projection: in three dimensions the diagonals pass one above the other, a distance $\sqrt{14}$ apart, and the central “point” is the vertical diameter, whose ends are vertices of the octahedron. The exit through the centre is the exit along the $z$ axis, and it measures $\sqrt{14}$.

![Figure 5: Top: the octahedron $\mathcal O_7$ (blue, height $\sqrt{14}$ in green), the tetrahedron $T^+$ (red) and the cube (dotted) in the sphere $\mathcal{S}$, from three angles. Bottom left: the projection on the $xy$ plane: circle, inscribed square, circumscribed square at $45^\circ$ and the two diagonals (edges of $T^+$, one in front, solid, one behind, dashed). Bottom right: the side view; the centre of the circle is the vertical segment $\sqrt{14}$ between the vertices $\pm P$.](fig_png/fig8_octaedro_projecao_en.png)

With $s^2=7/2$ instead of $49/8$, the same tetrahedron has edge $\sqrt{28}$ and is the tetrahedron $T^+$ of Theorem 9: its midsphere is the sphere $\mathcal S\colon x^2+y^2+z^2=7/2$, of diameter $\sqrt{14}$, which circumscribes the $1\times2\times3$ box. All the theorems hold with the numbers changed: the square of the view from above has side $\sqrt{14}$ and is circumscribed about the equator of $\mathcal S$; the lateral edges cross this equator perpendicular to the radius and at $45^\circ$ to the plane; the centre of the square is the vertical diameter, of length $\sqrt{14}$; and the midpoints of the edges form the regular octahedron of edge $\sqrt7$ and central height $\sqrt{14}$, inscribed in $\mathcal S$.

![Figure 6: The tetrahedron $T^+$ (top edge in red, bottom edge in dashed blue, lateral edges in black), the octahedron $\mathcal O_7$ (blue, with the middle square in purple and the axis $\sqrt{14}$ in green) and the equator circle (gold), from five angles. The four lateral edges touch the circle at the vertices of the middle square. Bottom: in the $xy$ plane, the square with diagonals around the circle and the inscribed middle square; in the $xz$ plane, the lateral edge is vertical and touches the circle, and the centre is the axis $\sqrt{14}$; in the vertical plane of the edge, it crosses the perimeter perpendicular to the radius and at $45^\circ$ to the plane.](fig_png/fig13_tetra_octa_circulo_en.png)

## 7. The cosecant $\sqrt{14}$: the turn that does not close

### 7.1 The exact rotation

For a quaternion $q=\alpha+\beta i+\gamma j+\delta k$, the Euler–Rodrigues matrix $R(q)$ \[9, 10\] satisfies $R(q)/|q|^2\in SO(3)$ and $R(qq')=R(q)R(q')$, and turns about the vector part by twice the half-angle $\omega$, $\cos\omega=\alpha/|q|$.

**Proposition 10**. *The quaternion $q=13+2j+3k$ has norm $182=13\cdot14$ and half-angle $\theta$. The rotation $\mathcal R=R(q)/182$ is $$\mathcal R=\frac1{91}\begin{pmatrix}78&-39&26\\39&82&6\\-26&6&87\end{pmatrix}=\tfrac67 I+\tfrac17\frac{aa^{\mathsf T}}{13}+\tfrac17[a]_\times,$$ with $\mathcal R^{\mathsf T}\mathcal R=I$, $\det\mathcal R=1$, $\mathcal Ra=a$, $\operatorname{tr}\mathcal R=19/7$: the rotation by $2\theta$ about $a$, with no $\pi$, no numerical sine and no root.*

*Proof.* The half-angle has $\sin^2\omega=13/182=1/14$. The second form is Rodrigues’ formula with $\cos2\theta=6/7$ and $\sin2\theta/\sqrt{13}=1/7$. The identities are checked in integers: $MM^{\mathsf T}=91^2I$, $Ma=91a$. ◻

### 7.2 Exact powers and the $7$-adic valuation

**Lemma 11**. *For $n\ge0$, $\mathcal R^n=c_nI+(1-c_n)\frac{aa^{\mathsf T}}{13}+\sigma_n[a]_\times$, with $c_n=T_n(6/7)$, $\sigma_n=U_{n-1}(6/7)/7$, and $P_n=\mathcal R^nP=\bigl(\tfrac{c_n}2,\ 1+\tfrac32\sigma_n,\ \tfrac32-\sigma_n\bigr)$.*

*Proof.* $\cos2n\theta=T_n(\cos2\theta)$ and $\sin2n\theta/\sqrt{13}=\sigma_n$; with $a\cdot P=13/2$ and $a\times P=(0,\tfrac32,-1)$, $P_n=c_nP+(1-c_n)\tfrac a2+\sigma_n(0,\tfrac32,-1)$. ◻

**Lemma 12**. *$C_n=7^nT_n(6/7)$ and $D_k=7^kU_k(6/7)$ are integers, with $C_{n+1}=12C_n-49C_{n-1}$, $D_{k+1}=12D_k-49D_{k-1}$, $C_0=1$, $C_1=6$, $D_0=1$, $D_1=12$; and $C_n\equiv6\cdot5^{n-1}$, $D_k\equiv5^k\pmod7$. Hence $7\nmid C_n$ and $7\nmid D_k$.*

*Proof.* Modulo $7$, $49\equiv0$ and $12\equiv5$. ◻

### 7.3 The loop theorem

**Theorem 13** (the loop of cosecant $\sqrt{14}$). *Let $P_n=\mathcal R^nP$.*

*(a) Every $P_n$ is rational, lies on $\mathcal{S}$ and on the circle $C=\mathcal{S}\cap\{X\cdot a=13/2\}$, with centre $a/2$ and radius $\tfrac12$, whose diameter is the edge $PP'$.*

*(b) For $n\ge1$ the common denominator of $P_n$ is exactly $2\cdot7^n$.*

*(c) The $P_n$ are pairwise distinct: $\mathcal R^n\ne I$ for all $n\ge1$; the path never returns to $P$, never reaches $P'$ and, after the first step, never again meets an integer point of $2\mathcal{S}$, in particular none of the $48$ points of shell $14$.*

*(d) $\theta/\pi$ is irrational and $\{P_n\}$ is dense in $C$: the loop does not close, and the circle is the closure of this open path.*

*Proof.* (a) $\mathcal R$ preserves $X\cdot X$ and fixes $a$; for $X\in C$, $|X-a/2|^2=7/2-13/2+13/4=1/4$. (b) By the lemmas, $P_n=\bigl(\frac{C_n}{2\cdot7^n},\frac{2\cdot7^n+3D_{n-1}}{2\cdot7^n},\frac{3\cdot7^n-2D_{n-1}}{2\cdot7^n}\bigr)$, with numerators prime to $7$; by parity ($C_n$ is odd iff $n$ is even, $D_k$ is odd iff $k$ is even) some coordinate has denominator $2\cdot7^n$. (c) Distinct denominators give distinct points; if $\mathcal R^m=I$, then $P_m=P$, absurd. (d) If $\theta/\pi\in\mathbb{Q}$, some power would be $I$; by Kronecker’s theorem \[12\] the orbit is dense. ◻

**Two further proofs of (c).** By Niven \[11\]: $2\cos2\theta=12/7$ is not an integer, so $2\theta$ is not a rational fraction of a turn. By rank one modulo $7$: $M=91\mathcal R$ has $M^2\equiv2M\not\equiv0\pmod7$, so $M^n\equiv2^{n-1}M\not\equiv0$, while $91^nI\equiv0$.

The first points are $(\tfrac12,1,\tfrac32)$, $(\tfrac37,\tfrac{17}{14},\tfrac{19}{14})$, $(\tfrac{23}{98},\tfrac{67}{49},\tfrac{123}{98})$, $(-\tfrac9{343},\tfrac{971}{686},\tfrac{839}{686})$. Up to $n=2000$ the best approach to closing is $n=778$, at $0.115^\circ$; in every case $1-\cos2n\theta$ is an exactly positive rational.

![Figure 7: The $1\times2\times3$ box in $\mathcal{S}$, the triangle $-P,P',P$ (gold), the diagonal $\sqrt{14}$ (red), the axis $a$ (green) and the circle $C$ with the points $P_0,\dots,P_{24}$; inset: the first twelve steps.](fig_png/fig1_caixa_loop_3d_en.png)

![Figure 8: The loop in the plane of $C$: twelve steps do not close; two thousand distinct points fill the circle; closing happens only through the half-turn, which takes $P$ to $P'$ through the centre.](fig_png/fig2_loop_plano_en.png)

### 7.4 General loop criterion

**Theorem 14**. *A rotation with rational entries closes the loop if and only if its trace lies in $\{3,2,1,0,-1\}$ (orders $1,6,4,3,2$).*

*Proof.* $2\cos\varphi=\operatorname{tr}-1$ is rational; if it is an algebraic integer, it is an integer in $[-2,2]$. ◻

  Rotation                                 $\operatorname{tr}$   $2\cos\varphi$    Closes?
  --------------------------------------- --------------------- ---------------- -----------
  $T_{-1,3}$ \[1, Sec. 15.4\]                    $13/23$            $-10/23$        never
  $T_{1,1}$                                     $-11/15$            $-26/15$        never
  $M_3/3$, first Pythagorean cube                 $1/3$              $-2/3$         never
  $M_7/7$, half-turn about the diagonal           $-1$                $-2$        order $2$
  $\mathcal R$, cosecant $\sqrt{14}$             $19/7$              $12/7$         never
  $\mathcal R_b$, box quaternion                 $-5/7$             $-12/7$         never
  Fixed turn of the Cot$\alpha$ spiral         $\sqrt2/2$        $-1+\sqrt2/2$      never

  : Table 1: Audit of rotations; the predicted order agreed with a direct search of up to $60$ powers.

## 8. The exit through the centre

### 8.1 Where the loop closes: through the half-turn across the centre

**Proposition 15**. *With $b=1+2j+3k$, the quaternion of the box edges, of norm $14$: $(13+2j+3k)(1+2j+3k)=14(2j+3k)$. Hence $\mathcal R\,\mathcal R_b=H=(2aa^{\mathsf T}-13I)/13$, the half-turn about $a$, with $HP=P'$ and $H^2=I$: the loop closes in four steps.*

*Proof.* With $v=2j+3k$, $v^2=-13$, $(13+v)(1+v)=14v$; a pure quaternion is a half-turn. $H$ is the bridge with axis $P+P'=a$ \[1, Theorem C5\]. ◻

The tangents of the half-angles of $q$ and $b$ are $1/\sqrt{13}$ and $\sqrt{13}$, reciprocal; they add to a quarter turn, and the composition crosses the centre of the circle $C$.

### 8.2 External and internal tangents

**Proposition 16**. *Let $X=(2,3,6)$, $|X|^2=49$, and $T=(1,\tfrac32,-\tfrac12)$, a vertex of the $2\times3\times1$ box centred at the origin. Then $T\in\mathcal{S}$ and $T\cdot(X-T)=0$ (the radius $OT$ is perpendicular to the tangent $XT$); the external tangent $XT$ makes with the axis $XO$ the angle of spread $1/14$, that is, $\csc\theta=\sqrt{14}$; the triangle $O,T,X$ has quadrances $7/2,\,91/2,\,49$, proportional to $1,13,14$; the inner point $X'=\rho X/|X|^2=X/14$ is the inverse of $X$, with $|OX'|\cdot|OX|=\tfrac12\cdot7=R^2$; and all tangents from $X$ touch $\mathcal{S}$ on the circle with centre $X'$ and radius $\sqrt{13}/2$, in the polar plane $X\cdot Y=\rho$.*

*Proof.* $T\cdot T=T\cdot X=7/2$; the triangle is right-angled at $T$ and $\sin^2\theta=(7/2)/49$; the contact radius is $\sqrt{\rho-1/4}$. ◻

The *external* tangents leave $X$, outside the ball, with cosecant $\sqrt{14}$ relative to the axis; the *inner* point $X'$ is the centre of their contact circle. Inversion exchanges the two, by the same law that takes the insphere of the disphenoid, radius $3/7$, to the polar circumsphere, radius $49/6$: $\tfrac37\cdot\tfrac{49}6=\tfrac72$ \[1, Sec. 21.6\]. The axis $X\to X'\to O\to-X'\to-X$ crosses the centre, and the jump $J=-I$ repeats the cone on the other side. Seen along the axis, the external tangents are radii leaving the centre of the circle outwards.

![Figure 9: The cone of external tangents to $\mathcal{S}$ from $X=(2,3,6)$, cosecant $\sqrt{14}$; contact circle centred at $X'=X/14$; the axis crosses the centre to $-X$.](fig_png/fig3_cone_tangentes_3d_en.png)

![Figure 10: Section through the axis and view along the axis: $X$, $X'$ and $O$ fall on the centre, and every external tangent becomes a radius.](fig_png/fig4_secao_projecao_en.png)

### 8.3 Sine zero, cosecant $1$ and cosecant $\sqrt{14}$

**Proposition 17**. *In the triangle $O,T,X$, with $OX$ as the $z$ axis:*

*(a) **Sine zero belongs to the axis.** Every direction along the axis has spread $0$ with it; every rotation about the axis fixes it pointwise, and the screw motion $Y\mapsto\mathcal RY+a$ maps the axis $a$ into itself. A point moving along the $z$ axis turns with everything and keeps sine zero; seen from above, it is the centre.*

*(b) **Cosecant $1$ belongs to the radius and the tangent:** $OT\perp XT$ at every point of contact.*

*(c) **Cosecant $\sqrt{14}$ belongs to the external tangent and the axis:** $XT$ has length $\sqrt{91/2}$, advances $13/2$ along the axis and projects onto the plane with length $\sqrt{13}/2$, so $\csc\theta=|XT|/(\text{projection})=\sqrt{14}$.*

**Proposition 18**. *No angle has both sine zero and cosecant $\sqrt{14}$ (nor cosecant $1$), since $\sin\alpha\cdot\csc\alpha=1$ whenever the cosecant exists.*

The three statements of the thesis live in the same triangle but belong to different angles: the axis has sine zero, the radius makes cosecant $1$ with the tangent, the external tangent makes cosecant $\sqrt{14}$ with the axis. In the projection onto the $xy$ plane the axis shrinks to a point, and only cosecant $1$ remains visible.

**The helix.** $Y_n=\mathcal R^nP+n\,a$ rises $13$ per step along the axis ($Y_n\cdot a=13/2+13n$) and projects onto the orbit of Theorem 13; each step has a chord of quadrance $1/14$ in the plane and total quadrance $183/14$. The helix does not close in space, and its projection, the circle, does not close either.

![Figure 11: The helix and its projection: the plane circle is the shadow of a path that rises along the $z$ axis and never closes.](fig_png/fig5_helice_en.png)

**The way out of the circle.** Sections 5 to 8 show that the plane circle is the shadow of solids and of paths in space; that its centre is a segment of the $z$ axis; that the path by cosecant $\sqrt{14}$ does not close by turning and closes by passing through the centre; and that the external point $X$, from which the tangents of cosecant $\sqrt{14}$ issue, and the inner point $X'$ are exchanged by inversion along the same axis. The way out of the circle thus has three exact directions: upwards, along the helix, in which the height grows without coming back; through the centre, along the $z$ axis of measure $\sqrt{14}$; and outwards, along the spiral of side $1$ of the following sections, which never returns to a circle already read.

**Without $\pi$ and without roots.** In the computations of Sections 4 to 8, none uses $\pi$ or the extraction of the square root of an integer that is not a perfect square. Lengths such as $7/\sqrt2$ or $\sqrt{14}$ appear only as names; what is computed are the quadrances $49/2$ and $14$. Angles are rational spreads ($0$, $1$, $1/2$, $1/14$), rotations have rational entries, and every certificate is an equality between integers or fractions. The number $\pi$ appears only to say that the angle of the turn is not a rational fraction of a full turn (Theorem 13) and, in Section 10, as the measure of the gap between the turns of the spiral.

## 9. The spiral of Theodorus: the circle of side 1

**Language.** The quadrance of a vector $u=(x,y)$ is $\operatorname{Q}(u)=x^2+y^2$; between two points $P$ and $R$ it is $\operatorname{Q}(P-R)$. The spread between non-zero vectors $u$ and $w$ is $s(u,w)=(u\times w)^2/(\operatorname{Q}(u)\operatorname{Q}(w))$, with $u\times w=x_uy_w-y_ux_w$; it is the squared sine of the angle between them and is rational whenever the coordinates are \[6\]. In this language, Pythagoras’ theorem says that the angle at $B$ of triangle $ABC$ is right if and only if $\operatorname{Q}(AB)+\operatorname{Q}(BC)=\operatorname{Q}(AC)$; in a right triangle, the spread of an acute angle is the quadrance of the opposite side divided by the quadrance of the hypotenuse.

**Definition 1**. Let $J(x,y)=(-y,x)$ be the rotation by a right angle. The spiral of Theodorus is the polygonal line $O,v_1,v_2,\dots$ with $$v_1=(1,0),\qquad v_{N+1}=v_N+\frac{J v_N}{\sqrt N}\quad(N\ge1).$$ The first segment is $Ov_1$; the $N$-th segment ends at $v_N$. Thus $N$ is the number of segments of side $1$ travelled up to $v_N$.

**Theorem 19** (always side $1$, quadrance $N$). *For every $N\ge1$: $\operatorname{Q}(v_N)=N$; the step $v_{N+1}-v_N$ has quadrance $1$ and is perpendicular to $v_N$. In complex form, $z_N=\prod_{k=1}^{N-1}\bigl(1+i/\sqrt k\bigr)$ and $$\operatorname{Q}(v_N)=\prod_{k=1}^{N-1}\left(1+\frac1k\right)=\prod_{k=1}^{N-1}\frac{k+1}{k}=N .$$*

*Proof.* For every vector $v$, $\operatorname{Q}(Jv)=\operatorname{Q}(v)$ and $v\cdot Jv=0$. If $\operatorname{Q}(v_N)=N$, then $\operatorname{Q}(v_{N+1})=\operatorname{Q}(v_N)+\operatorname{Q}(Jv_N)/N+2\,v_N\cdot Jv_N/\sqrt N=N+1+0$; since $\operatorname{Q}(v_1)=1$, induction gives $\operatorname{Q}(v_N)=N$ for all $N$. The step $Jv_N/\sqrt N$ has quadrance $N/N=1$ and is perpendicular to $v_N$. In complex form, $v_{N+1}=v_N(1+i/\sqrt N)$, and the product of the quadrances $1+1/k=(k+1)/k$ telescopes to $N$. ◻

The coordinates of $v_N$ contain roots, but none of them has to be computed: the root appears only as a name, and what is computed is the quadrance, the integer $N$.

**Theorem 20** (the three spreads). *The triangle $O\,v_N\,v_{N+1}$ has quadrances $N$, $1$ and $N+1$, and $\operatorname{Q}(Ov_N)+\operatorname{Q}(v_Nv_{N+1})=N+1=\operatorname{Q}(Ov_{N+1})$ (right angle at $v_N$). Its spreads are $1$ at $v_N$, $1/(N+1)$ at the centre $O$ and $N/(N+1)$ at $v_{N+1}$. The angle $\theta_N$ at the centre has $\csc^2\theta_N=N+1$ and squared cotangent $N$. In triangle $13$, the spread at the centre is $1/14$ and the cosecant is $\sqrt{14}$: it is the triangle $1,\sqrt{13},\sqrt{14}$ of Section 4.*

*Proof.* By Theorem 19 and Pythagoras. At the centre, the opposite side is the step, of quadrance $1$; at $v_{N+1}$, the opposite side is the radius $Ov_N$, of quadrance $N$; both are divided by the hypotenuse, of quadrance $N+1$. The sum $1/(N+1)+N/(N+1)=1$ is that of the two acute angles of a right triangle. ◻

**Proposition 21** (tangent and power of a point). *Let $C_N$ be the circle $x^2+y^2=N$. The step leaving $v_N$ is tangent to $C_N$ at $v_N$ and ends on $C_{N+1}$. The power of the point $v_M$ with respect to $C_N$ is the integer $M-N$; in particular, the tangent segment from $v_{N+1}$ to $C_N$ has quadrance $1$: the step of side $1$ is exactly the tangent drawn from the new point to the previous circle.*

*Proof.* The line perpendicular to the radius at the point of the circle is the tangent. The power of a point $P$ with respect to a circle of centre $O$ and quadrance $r$ is $\operatorname{Q}(P)-r$; when $P$ is outside the circle or on it, it equals the quadrance of the tangent segment. For $P=v_M$ and $r=N$ it is $M-N$, and the case $M\ge N$ is that of the tangent segment. ◻

**Proposition 22** (the spiral does not close). *At the point $v_N+t\,u_N$ of the step $u_N=v_{N+1}-v_N$, with $0\le t\le1$, the quadrance to the centre is $N+t^2$. Hence, along the polygonal line, the quadrance increases strictly: the spiral crosses each circle $x^2+y^2=r$, $r\ge1$, exactly once, no point repeats and no loop closes.*

*Proof.* $\operatorname{Q}(v_N+tu_N)=\operatorname{Q}(v_N)+2t\,v_N\cdot u_N+t^2\operatorname{Q}(u_N)=N+0+t^2$. The function is continuous and strictly increasing on each step and equals $N+1$ at the end of step $N$, which is the start of step $N+1$; it is therefore strictly increasing along the whole polygonal line, from $1$ to infinity. ◻

As a point set, each circle $C_N$ is a closed curve; what does not close is the path that reads them. Even more, Teuffel proved in 1958 that no two hypotenuses of the spiral lie on the same line, however far it continues \[14, 15\]: neither the points nor the directions repeat.

**Proposition 23** (perfect squares). *The distance from $v_N$ to the centre is rational if and only if $N$ is a perfect square, and it is then the integer $k=\sqrt N$. The points $v_1,v_4,v_9,v_{16},\dots$ are exactly the points of the spiral on circles of integer radius $1,2,3,4,\dots$*

*Proof.* If $\sqrt N=a/b$ in lowest terms, then $Nb^2=a^2$; since $\gcd(a,b)=1$, $b^2$ divides $1$, and $N=a^2$. ◻

In quadrance, all points of the spiral are exact, since they are integers; in distance, only the perfect squares are. This is the path of perfect squares inside the spiral itself.

![Figure 12: The spiral of Theodorus by quadrance. (a) The $16$ triangles of side $1$ up to the hypotenuse $\sqrt{17}$ add up to $351.15^\circ$; the $17$th would exceed one turn (certificate T8). The number next to each point is its quadrance $N$, the number of segments of side $1$; the gold circles have integer radius (perfect squares $1$, $4$, $9$, $16$). In purple, triangle $13$, with cosecant $\sqrt{14}$. (b) Each step is tangent to the circle $x^2+y^2=N$ and ends on the circle $x^2+y^2=N+1$; the power of $v_{N+1}$ with respect to circle $N$ is $1$. (c) A row of $n$ squares uses $3n+1$ segments of side $1$.](fig_png/fig14_teodoro_circulos_en.png)

## 10. The geometric meaning: the spiral as a way of understanding the circle

In the plane drawing, a circle is a closed curve. The spiral of Theodorus reads the family of circles $x^2+y^2=N$ in another way: each circle is touched at a single point, by a tangent step of side $1$, and the figure moves on to the next circle. This section proves four readings of that idea.

### 10.1 Why always side 1

\(a\) Side $1$ turns counting into geometry. Each step adds exactly $1$ to the quadrance, so that after $N$ steps the quadrance is $N$: the integer counter and the geometric measure are the same number, and Pythagoras’ theorem becomes the sum $N+1$.

\(b\) $1$ is the only positive length equal to its own quadrance, since $1^2=1$: the side and the area of the unit square coincide, and the unit needs no root.

\(c\) With side $1$, every angle of every triangle of the spiral is rational in spread: $1/(N+1)$, $N/(N+1)$ and $1$.

\(d\) The rule is the same at every step, a unit perpendicular to the radius, without measuring any angle and without $\pi$.

### 10.2 The development of the diagonals of the cubes

**Theorem 24** (development). *Let $e_1,e_2,\dots$ be the unit vectors of the axes and $d_N=e_1+\dots+e_N$ the diagonal of the unit cube of dimension $N$. The triangle $(0,d_N,d_{N+1})$ is congruent to the Theodorus triangle $(O,v_N,v_{N+1})$, and two consecutive triangles share the side of quadrance $N+1$, which is $0\,d_{N+1}$ in space and $Ov_{N+1}$ in the plane. The spiral of Theodorus is therefore the development, into the plane, of the fan of triangles formed by the diagonal of the cube of dimension $N$, a new edge of side $1$ perpendicular to all previous ones, and the diagonal of the cube of dimension $N+1$. If $N=a^2+b^2$, triangle $N$ already exists in ordinary space: it is the triangle with vertices $(0,0,0)$, $(a,b,0)$, $(a,b,1)$ of the $a\times b\times1$ box, formed by the diagonal of a face, the edge of side $1$ and the space diagonal.*

*Proof.* $\operatorname{Q}(d_N)=N$, $\operatorname{Q}(d_{N+1}-d_N)=\operatorname{Q}(e_{N+1})=1$ and $d_N\cdot e_{N+1}=0$: the three quadrances are $N$, $1$, $N+1$, with a right angle at $d_N$, the same as in the Theodorus triangle, and three quadrances determine a triangle up to isometry. Rotating each triangle about the common side into the plane of the previous one, on the opposite side of it, the fan opens into the plane without changing any quadrance: this is the development. In the box, $\operatorname{Q}(a,b,0)=N$, $\operatorname{Q}(0,0,1)=1$, $(a,b,0)\cdot(0,0,1)=0$ and $\operatorname{Q}(a,b,1)=N+1$. ◻

The first two triangles of the spiral lie inside the ordinary unit cube: triangle $1$ on a face, with $(1,0,0)\to(1,1,0)$, and triangle $2$ crossing the cube, with the face diagonal $(1,1,0)$, the vertical edge and the cube diagonal $(1,1,1)$, of quadrance $3$. Triangle $13$, since $13=2^2+3^2$, is that of the $2\times3\times1$ box: face diagonal $\sqrt{13}$, edge $1$ and space diagonal $\sqrt{14}$, the box of Section 4. Each step of side $1$ asks for a new direction, perpendicular to everything before it. In a space of many dimensions there are plenty of new directions; in the plane there is only one direction perpendicular to the radius, and the spiral turns. The spiral is what the ladder of dimensions leaves in the plane.

### 10.3 The progression of inscribed and circumscribed squares

The author observed that each radius of the spiral at the levels $2^j$ is an edge or a diagonal of an inscribed or circumscribed square, and that the initial point is the vertex of an infinite progression of squares inscribed in and circumscribed about the circles. The next theorem gives this observation its exact form.

For $j\ge0$, let $C_j^\ast$ be the circle $x^2+y^2=2^j$ and let $S_j$ be the square with vertices $$(\pm2^m,0),\ (0,\pm2^m)\ \text{ if } j=2m,\qquad (\pm2^m,\pm2^m)\ \text{ if } j=2m+1 .$$

**Theorem 25** (progression of squares). *For every $j\ge1$:*

*(i) $S_j$ is inscribed in $C_j^\ast$ and circumscribed about $C_{j-1}^\ast$, and its four sides touch $C_{j-1}^\ast$ exactly at the four vertices of $S_{j-1}$;*

*(ii) the side of $S_j$ has quadrance $2^{j+1}$, its half-diagonal has quadrance $2^j$ and its apothem has quadrance $2^{j-1}$; thus the radius of $C_j^\ast$ is, at the same time, the side of $S_{j-1}$, the half-diagonal of $S_j$ and the half-side of $S_{j+1}$;*

*(iii) the vertices of $S_j$ are integer points: on the axes when $j$ is even, with integer radius $2^{j/2}$ (quadrance $4^m$, a perfect square), and on the diagonals when $j$ is odd, with radius $2^m\sqrt2$ (quadrance $2\cdot4^m$);*

*(iv) the start of the spiral of Theodorus is the start of the progression: $v_1=(1,0)$ is a vertex of $S_0$ and the point where a side of $S_1$ touches $C_0^\ast$; $v_2=(1,1)$ is a vertex of $S_1$; the first step is half a side of $S_1$, and the first triangle $O\,v_1\,v_2$ is one eighth of $S_1$;*

*(v) each point $v_{2^j}$ of the spiral lies on $C_j^\ast$, and the square obtained by rotating $S_j$ about $O$ until a vertex falls on $v_{2^j}$ is still inscribed in $C_j^\ast$ and circumscribed about $C_{j-1}^\ast$.*

*The progression continues without end outwards and also inwards, on the circles of quadrance $1/2,1/4,\dots$, towards the centre.*

*Proof.* (i) If $j=2m+1$, the sides are the lines $x=\pm2^m$ and $y=\pm2^m$, at distance $2^m$ from the centre, and they touch the circle of quadrance $4^m=2^{j-1}$ at $(\pm2^m,0)$ and $(0,\pm2^m)$, the vertices of $S_{2m}$. If $j=2m$, the sides are the lines $|x|+|y|=2^m$, whose distance to the centre has quadrance $(2^m)^2/2=2^{j-1}$; the foot of the perpendicular from the centre to the line $x+y=2^m$ is $(2^{m-1},2^{m-1})$, a vertex of $S_{2m-1}$, and by symmetry the same holds for the other sides. (ii) For $j=2m+1$, the side goes from $(2^m,2^m)$ to $(-2^m,2^m)$ and has quadrance $4^{m+1}=2^{j+1}$; for $j=2m$, it goes from $(2^m,0)$ to $(0,2^m)$ and has quadrance $2\cdot4^m=2^{j+1}$. The half-diagonal is the radius, of quadrance $2^j$, and the apothem is the distance in item (i), of quadrance $2^{j-1}$. The side of $S_{j-1}$ has quadrance $2^{j}$, equal to that of the radius of $C_j^\ast$, and the half-side of $S_{j+1}$ has quadrance $2^{j+2}/4=2^j$. (iii) Direct reading of the coordinates. (iv) By definition, $v_2=v_1+Jv_1=(1,1)$; the segment from $(1,0)$ to $(1,1)$ is half of the side $x=1$ of $S_1$, and the triangles $O$, $(\pm1,0)$ or $(0,\pm1)$, $(\pm1,\pm1)$ divide $S_1$ into eight equal parts. (v) $\operatorname{Q}(v_{2^j})=2^j$ by Theorem 19, and the rotation about $O$ preserves quadrances to the centre and distances to the sides. ◻

**Corollary 26** (the even step is the Meno backwards). *For every $n\ge1$, the square inscribed in the circle $x^2+y^2=n$ has a side of quadrance $2n$ and an apothem of quadrance $n/2$; hence the circle inscribed in the square inscribed in $x^2+y^2=n$ is the circle $x^2+y^2=n/2$. For even $n$, the step $n\to n/2$ of the $3n+1$ problem takes the circle of $v_n$ to the circle inscribed in its inscribed square, and the step $n\to 2n$ goes the opposite way, which is the construction of the Meno: the square on the diagonal has twice the area \[2\]. For odd $m$, call the progression of squares of the circle $x^2+y^2=m$ the sequence of circles $x^2+y^2=2^a m$, $a\ge0$, in which each circle is the one inscribed in the square inscribed in the next. Every integer $n=2^a m$, with $m$ odd, lies at level $a$ of the progression of its odd part $m$, and the divisions by $2$ walk down this progression to its base $m$; the progression of the initial point is that of $m=1$.*

*Proof.* In the inscribed square, the half-diagonal has quadrance $n$, the side has quadrance $2n$ and the apothem, which is half the side, has quadrance $2n/4=n/2$, whatever the rotation of the square. ◻

![Figure 13: The progression of inscribed and circumscribed squares (Theorem 25). (a) Squares $S_0$ to $S_6$ on the circles $x^2+y^2=2^j$: at even levels (gold) the vertices are on the axes and the radius is an integer; at odd levels (purple) they are on the diagonals. The black dots are the points $v_{2^j}$ of the spiral of Theodorus, and the red square is the initial point $(1,0)$. (b) The first triangle of the spiral is one eighth of $S_1$. (c) The even step $n\to n/2$ takes the circle $x^2+y^2=n$ to the circle inscribed in its inscribed square.](fig_png/fig15_progressao_quadrados_en.png)

### 10.4 The lift: height is quadrance

**Theorem 27** (paraboloid). *Lift each point $v_N$ to the point $V_N=(v_N,N)$ in space. Then:*

*(i) $V_N$ lies on the paraboloid $z=x^2+y^2$, and the circle $C_N$ is the shadow, on the $xy$ plane, of the horizontal section of the paraboloid at height $N$;*

*(ii) each lifted step $V_N\to V_{N+1}$ moves $1$ horizontally and rises $1$ vertically: it has quadrance $2$ and spread $1/2$ with the $xy$ plane, that is, an inclination of $45^\circ$;*

*(iii) the height grows by $1$ at each step and never comes back: in space, the spiral is a $45^\circ$ ramp; the plane spiral is its shadow, and the circles are the shadows of its levels. Developed along its own horizontal path, the ramp is the straight line $z=s+1$, of slope $1$.*

*Proof.* (i) $z=N=\operatorname{Q}(v_N)$ by Theorem 19. (ii) The horizontal displacement $v_{N+1}-v_N$ has quadrance $1$, and the vertical one $(N+1)-N=1$; the spread with the plane is the vertical quadrance over the total, $1/2$. (iii) The height $N$ is strictly increasing; after $s$ steps the horizontal path measures $s$ and the height is $s+1$. ◻

This is the same $45^\circ$ angle at which the lateral edges of the regular tetrahedron cross the circle (Theorem 6), and the same situation as the helix of Section 8: the plane circle is the shadow of a path that climbs.

### 10.5 The turn that does not close and the number $\pi$

**Proposition 28** (gap between turns). *Let $\varphi_N=\sum_{k=1}^{N-1}\arctan(1/\sqrt k)$ be the angle swept from $v_1$ to $v_N$. Then $\varphi_N=2\sqrt N+K+O(N^{-1/2})$ for a constant $K$ (numerically, $K\approx-2.1578$). Consequently, on any ray from the centre, the radii at which the spiral crosses it in consecutive turns differ by $\pi+O(N^{-1/2})$: asymptotically, the spiral is the Archimedean spiral $r\approx(\varphi-K)/2$, and each turn moves away from the previous one by $\pi$.*

*Proof.* For $0<x\le1$, $0<x-\arctan x<x^3/3$. Hence $\varphi_N=\sum_{k<N}k^{-1/2}-\sum_{k<N}\varepsilon_k$, with $0<\varepsilon_k<k^{-3/2}/3$; the second series converges and its tail after $N$ is $O(N^{-1/2})$. By the Euler–Maclaurin formula, $\sum_{k\le x}k^{-1/2}=2\sqrt x+\zeta(1/2)+O(x^{-1/2})$ \[16, Theorem 3.2(b)\]; with $x=N-1$, and since $2\sqrt N-2\sqrt{N-1}=O(N^{-1/2})$, we get $\varphi_N=2\sqrt N+K+O(N^{-1/2})$, with $K=\zeta(1/2)-\sum_{k\ge1}\varepsilon_k$. Along each step the polar angle increases strictly: at the point $v_N+t\,u_N$ it exceeds that of $v_N$ by $\arctan(t/\sqrt N)$; so each ray is crossed once per turn. On a ray of direction $\alpha$, the crossings occur when $\varphi=\alpha+2\pi m$; between two consecutive crossings, $2\sqrt N$ grows by $2\pi+O(N^{-1/2})$, and the radius grows by $\pi+O(N^{-1/2})$. Within one step, the radius varies by less than $\sqrt{N+1}-\sqrt N<1/(2\sqrt N)$, which does not change the conclusion. ◻

The number $\pi$ does not enter the construction, which uses only the unit and the right angle. It appears as the measure of how far a turn fails to close. Figure 14(c) shows the numerical computation with $4\cdot10^6$ segments: the gap along the ray of the initial point starts at $3.176$ and, after $636$ turns, is at $3.1416$.

**The figure of the Theaetetus.** Plato tells that Theodorus proved, case by case, that the sides of the squares of area $3,5,\dots$ are incommensurable with the unit, “up to the one of seventeen feet, and there, somehow, he stopped” \[5\]. The spiral is a modern reconstruction of how he may have drawn the figures \[13\]. The geometric fact is exact: the $16$ triangles up to the hypotenuse $\sqrt{17}$ add up to $351.150420^\circ$, less than one turn, and the $17$ triangles up to $\sqrt{18}$ add up to $364.783442^\circ$, more than one turn. Up to $\sqrt{17}$ the figure fits in one turn without overlapping; with the next triangle, it does not. Certificate T8 proves both inequalities with rigorous rational bounds for each arctangent (alternating series) and for $\pi$ (Machin’s formula).

![Figure 14: (a) Lifted to the paraboloid $z=x^2+y^2$, with height equal to quadrance, the spiral is a $45^\circ$ ramp; the plane figure is the shadow (Theorem 27). (b) With $1000$ segments, the spiral does not close: each turn crosses the ray of the initial point farther out than the previous one. (c) The gap between consecutive turns tends to $\pi$; numerical computation with $4\cdot10^6$ segments, illustrating Proposition 28.](fig_png/fig16_teodoro_paraboloide_en.png)

### 10.6 The Theodorus steps as turns

**Theorem 29**. *The Theodorus step $n\to n+1$ ($\csc\theta_n=\sqrt{n+1}$, $\cos2\theta_n=\frac{n-1}{n+1}$), repeated as a turn, closes the loop if and only if $n=1$ (a $90^\circ$ turn, four steps) or $n=3$ ($60^\circ$, six steps). For $n=13$, cosecant $\sqrt{14}$, it never closes.*

*Proof.* $2\cos2\theta_n$ must be an integer: $(n+1)\mid2(n-1)$, that is, $(n+1)\mid4$. ◻

In the octahedron $\mathcal O_7$, the four tetrahedra $\operatorname{conv}\{P,-P,\pm u_2,\pm u_3\}$ around the axis $\sqrt{14}$ have the fold $7+7=14$, the step $1\to2$, and close exactly (right dihedral). On the face of the regular tetrahedron of edge $\sqrt7$, the altitude gives the triangle $1,\sqrt3,2$, the step $3\to4$, and six faces close at $60^\circ$. The dihedral angle of the regular tetrahedron has $\cos\delta=1/3$; $T_k(1/3)$ has denominator $3^k$ and never equals $1$: five tetrahedra around an edge leave the gap $\cos5\delta=241/243$.

![Figure 15: The Theodorus steps as turns: $n=1$ closes in a square, $n=3$ in a hexagon, $n=13$ never closes.](fig_png/fig6_teodoro_fecha_en.png)

![Figure 16: Four tetrahedra around the axis $\sqrt{14}$ close the octahedron; five regular tetrahedra around an edge do not close.](fig_png/fig7_tetraedros_en.png)

## 11. The $3n+1$ problem in the language of Theodorus

Let $T(n)=n/2$ if $n$ is even and $T(n)=3n+1$ if $n$ is odd. The Collatz conjecture states that, for every integer $n\ge1$, some iterate of $T$ equals $1$; from then on the trajectory repeats the loop $1\to4\to2\to1$. It has been verified by computer up to $2^{71}\approx2.36\cdot10^{21}$ \[21\]; the history of the problem and the known general results are in \[17, 18, 19, 20\]. With the author’s observation that $N$ is the number of segments of side $1$, each number becomes a point of the spiral, and each step of $T$ becomes a geometric operation (Table 2).

  $3n+1$ problem         Spiral of Theodorus
  ---------------------- -------------------------------------------------------------------------
  value $n$              point $v_n$, end of the $n$-th segment of side $1$, at quadrance $n$
  value $1$              initial point $v_1=(1,0)$, the first segment
  even step $n\to n/2$   from the circle to the circle inscribed in its inscribed square
  odd step $n\to3n+1$    the $3n+1$ segments of a row of $n$ squares
  powers of $2$          circles $x^2+y^2=2^j$ of the progression of the initial point
  perfect squares        circles of integer radius
  loop $1\to4\to2\to1$   levels $0$, $2$ and $1$ of the progression: radii $1$, $2$ and $\sqrt2$

  : Table 2: Dictionary between the $3n+1$ problem and the spiral of Theodorus.

**Proposition 30** (matchsticks). *A row of $n$ squares of side $1$ has exactly $3n+1$ segments of side $1$ ($2n$ horizontal and $n+1$ vertical), $2n+2$ vertices and $n+1$ faces counting the outer one, and satisfies Euler’s relation $V-E+F=2$.*

*Proof.* Direct count: $(2n+2)-(3n+1)+(n+1)=2$. ◻

With the dictionary, each trajectory of the $3n+1$ problem becomes an exact path between circles of the spiral, measured in integers.

## 12. The door theorem through the perfect square

**Theorem 31** (door). *Let $n\ge1$ be a number that is not a power of $2$ and whose trajectory reaches $1$. Let $2^j$ be the first power of $2$ in the trajectory and $p$ the term before it. Then $p$ is odd, $3p+1=2^j$, $j$ is even, $j=2k$ with $k\ge2$, and $p=(4^k-1)/3$. The trajectory enters the final descent through the perfect square $4^k=(2^k)^2$, coming from the odd number $(4^k-1)/3\in\{5,21,85,341,\dots\}$.*

*Proof.* Since $n$ is not a power of $2$ and the trajectory reaches $1=2^0$, there is a first term that is a power of $2$, and it has a predecessor $p$ that is not a power of $2$. If $p$ were even, it would be $p=2\cdot2^j$, a power of $2$; hence $p$ is odd and $3p+1=2^j$. Modulo $3$, $2^j\equiv1$; since $2\equiv-1$, this requires $(-1)^j=1$, that is, $j$ even, $j=2k$. Since $p$ is odd and not a power of $2$, $p\ge3$, and then $4^k=3p+1\ge10$, that is, $k\ge2$. Finally, $p=(4^k-1)/3$. ◻

**Corollary 32** (the last climb ends at an integer radius). *Let $n$ be as in Theorem 31. In the plane of Theodorus, the last odd step before the trajectory first reaches $1$ jumps from $v_p$ to $v_{4^k}$, on the circle of integer radius $2^k$, which is level $2k$ of the progression of squares of the initial point, an even level, whose square $S_{2k}$ has its vertices on the axes. From there, the $2k$ divisions by $2$ walk down the progression $S_{2k},S_{2k-1},\dots,S_0$, alternating circles of integer radius $2^m$ and circles of radius $2^m\sqrt2$, down to the initial point $(1,0)$. Each step down is the Meno backwards (Corollary 26).*

*Proof.* Theorem 31, Theorem 25 and Corollary 26. ◻

**Theorem 33** (rare doors). *Let $p_k=(4^k-1)/3$. Then $p_k\equiv k\pmod 3$. If $3\mid k$, the numbers that enter through the door $4^k$ are exactly the numbers $p_k\cdot2^a$, $a\ge0$; hence, between $1$ and $N$, exactly $\lfloor\log_2(N/p_k)\rfloor+1$ numbers use the door $4^k$, when $p_k\le N$.*

*Proof.* $p_k=1+4+\dots+4^{k-1}\equiv k\pmod3$, because $4\equiv1$. If $3\mid k$, every $x=p_k2^a$ is a multiple of $3$; an odd predecessor $y$ of $x$ would require $3y+1=x\equiv0\pmod3$, which is impossible, and the only predecessor of $x$ is $2x$. So the tree of predecessors of $p_k$ is the chain $p_k2^a$. By Theorem 31, every number entering through the door $4^k$ passes through $p_k$ and lies in that tree; conversely, each $p_k2^a$ goes down by divisions to $p_k$, meeting no power of $2$, since $p_k$ is odd and greater than $1$, and enters through $4^k$. The count is that of the $a\ge0$ with $p_k2^a\le N$. ◻

The arithmetic facts of Theorems 31 and 33, namely that the last odd number before the final descent is $(4^k-1)/3$ and that multiples of $3$ have no odd predecessor, are known from the study of the predecessor tree of the $3x+1$ problem \[17\]. What is added here is the geometric reading: the door is a perfect square, a circle of integer radius at an even level of the progression of squares of the initial point.

    door $4^k$   predecessor $(4^k-1)/3$   numbers $n\le10^9$   prediction
  ------------ ------------------------- -------------------- ------------
      $4^2=16$                       $5$      $937\,695\,288$ 
      $4^3=64$                      $21$                 $26$         $26$
     $4^4=256$                      $85$       $23\,754\,817$ 
    $4^5=1024$                     $341$       $37\,947\,841$ 
    $4^6=4096$                    $1365$                 $20$         $20$
         $4^7$                    $5461$            $80\,772$ 
         $4^8$                 $21\,845$           $486\,049$ 
         $4^9$                 $87\,381$                 $14$         $14$
      $4^{10}$                $349\,525$            $32\,534$ 
      $4^{11}$             $1\,398\,101$             $2\,106$ 
      $4^{12}$             $5\,592\,405$                  $8$          $8$
      $4^{13}$            $22\,369\,621$                $395$ 
      $4^{14}$            $89\,478\,485$                 $98$ 
      $4^{15}$           $357\,913\,941$                  $2$          $2$
         total                                $999\,999\,970$    $10^9-30$

  : Table 3: Doors of all $n\le10^9$ that are not powers of $2$ (program `porta_quadrado.c`, exact $128$-bit integers, no failures and no overflows). The rows with a prediction are the rare doors of Theorem 33; the prediction matches the count.

The door $16=4^2$ receives $93.77\%$ of the numbers up to $10^9$; all observed doors are powers $4^k$ with $k\ge2$, as Theorem 31 requires, and the total is $10^9-30$, because the $30$ powers of $2$ up to $10^9$ are excluded.

**Proposition 34** (equivalent reformulation). *The Collatz conjecture is equivalent to: every $n\ge1$ that is not a power of $2$ reaches, in its trajectory, one of the odd numbers $p_k=(4^k-1)/3$, $k\ge2$ ($5$, $21$, $85$, $341$, …). In the language of Theodorus: every trajectory reaches the progression of squares of the initial point, and does so at an even level, a circle of integer radius.*

*Proof.* If the conjecture holds, Theorem 31 gives the odd number $p_k$. Conversely, from $p_k$ the trajectory goes to $4^k$ and down by divisions to $1$. ◻

In the language of Theodorus, then, the Collatz conjecture is the statement that every trajectory, jumping between progressions of squares, reaches the progression of the initial point.

## 13. The author’s proposed solution

This section records the author’s proposal, built on the results proved in the previous sections. The mathematical statements it uses are proved in the article; the proposal is the author’s reading of them.

**Author’s proposal 1**. (1) Each number $N$ is the point $v_N$ of the spiral of side $1$, at quadrance $N$, and each trajectory of the $3n+1$ problem is an exact path between the circles of the spiral (Section 11).

\(2\) Returning to $1$ is returning to the initial point, the vertex of the progression of squares. For the author, returning to $1$ is the same as checking whether one has reached the sine equal to $1$; and, since the closed circle is a projection, there is no sine equal to $1$ at the centre: from the geometric and trigonometric point of view, there is the way out through the centre, by the cosecant $\sqrt{14}$.

\(3\) The proved facts that support this reading: the centre of the plane circle is a segment of the $z$ axis (Theorems 4 and 9); the turn of cosecant $\sqrt{14}$ does not close, and the path closes through the half-turn that passes through the centre (Theorem 13 and Proposition 15); the external point from which the tangents issue and the inner point are exchanged by inversion (Proposition 16); on the spiral, the spread at the centre is $1/(N+1)$, never $1$, and the right angle sits at the point of tangency, from which the step moves outwards (Theorem 20); the spiral does not close and climbs in space (Proposition 22 and Theorem 27).

\(4\) The even step walks down the progression of squares (Corollary 26), the odd step $N\to3N+1$ counts the $3N+1$ segments of a row of $N$ squares (Proposition 30), and, for numbers that are not powers of $2$, the entry into the final descent always happens through a perfect square, on a circle of integer radius (Theorem 31 and Corollary 32).

\(5\) Through perfect squares, the author concludes that the path of every trajectory leaves the circle, reaches the door through the perfect square and walks down the progression to the initial point (if the starting number is a power of $2$, the trajectory is already on that progression); this is his proposed solution of the Collatz conjecture, which he submits for evaluation.

In the form of Proposition 34, the proposal states that the trajectory of every number that is not a power of $2$ reaches one of the doors $4^k$, $k\ge2$, that is, the progression of squares of the initial point at an even level.

## 14. Comparison with the neighbouring maps $3n-1$ and $5n+1$

**Theorem 35** (doors and cycles of the neighbouring maps). *(a) For the map $n\mapsto3n-1$ ($n$ odd), $n\mapsto n/2$ ($n$ even), if the trajectory of an $n$ that is not a power of $2$ reaches a power of $2$, the first one comes from an odd $p$ with $3p-1=2^j$ and $j$ odd: the door is $2\cdot4^k$, $k\ge1$, an odd level of the progression, of radius $2^k\sqrt2$, which is not a perfect square. This map has the cycles $5\to14\to7\to20\to10\to5$ and $17\to50\to25\to74\to37\to110\to55\to164\to82\to41\to122\to61\to182\to91\to272\to136\to68\to34\to17$, which never reach a power of $2$.*

*(b) For the map $n\mapsto5n+1$ ($n$ odd), $n\mapsto n/2$ ($n$ even), under the same conditions, the first power of $2$ comes from an odd $p$ with $5p+1=2^j$, which requires $4\mid j$: the doors are $16^k=(4^k)^2$, $k\ge1$, perfect squares, even levels of the progression, of integer radius, as in $3n+1$. The map has the cycles $13\to66\to33\to166\to83\to416\to208\to104\to52\to26\to13$ and $17\to86\to43\to216\to108\to54\to27\to136\to68\to34\to17$, which never reach a door.*

*Proof.* As in Theorem 31, the predecessor $p$ of the first power of $2$ is odd, since an even predecessor would be a power of $2$, and $p\ge3$. (a) $2^j\equiv-1\equiv2\pmod3$ if and only if $j$ is odd, and $2^j=3p-1\ge8$. (b) The order of $2$ modulo $5$ is $4$, and $2^j\equiv1\pmod5$ if and only if $4\mid j$, with $2^j=5p+1\ge16$. The cycles are checked step by step; none of their terms is a power of $2$. ◻

Among the $99\,983$ numbers up to $10^5$ that are not powers of $2$, the trajectories of $3n-1$ all reach either a door ($33\,013$ numbers) or one of the two cycles ($32\,104$ the cycle of $5$ and $34\,866$ that of $17$). Among the $19\,985$ numbers up to $2\cdot10^4$ that are not powers of $2$, those of $5n+1$ reach a door $16^k$ ($370$ numbers), enter the cycle of $13$ ($603$) or that of $17$ ($133$), or exceed $10^{40}$ without reaching a door or a cycle ($18\,879$). The map $3n-1$ on the positive integers is the same as $3n+1$ on the negative integers ($n\mapsto-n$): its three known cycles, $\{1,2\}$, that of $5$ and that of $17$, are the cycles of $3n+1$ at $-1$, $-5$ and $-17$, and that there are no others is also a conjecture.

In $3n+1$, the door is always a perfect square $4^k$, and all trajectories tested, up to $10^{10}$, reach the loop $1\to4\to2\to1$. In the neighbouring maps, the door changes with the multiplier, $2\cdot4^k$ in $3n-1$ and $16^k$ in $5n+1$, and the cycles above appear already among the first numbers.

![Figure 17: Trajectories measured on the spiral of Theodorus: at each step, the distance $\sqrt N$ from the point $v_N$ to the centre; the dashed lines are the circles of the doors. Top, the $3n+1$ problem: the trajectories of $3$, $7$ and $27$ enter the final descent through the door $16=4^2$, on the circle of integer radius $4$. Bottom, the neighbouring maps: $3n-1$, with doors $2\cdot4^k$ and the cycles of $5$ and $17$, and $5n+1$, with doors $16^k$ and the cycle of $13$.](fig_png/fig17_teodoro_collatz_en.png)

## 15. The phantom: systematic floating-point error

The same rotation $\mathcal R$ was applied $10^6$ times to the vertex $P$ in three forms. In exact fractions the quadrance $|P_n|^2-7/2$ and the height $P_n\cdot a-13/2$ are zero at every step (Theorem 13). In IEEE 754 double precision \[22\]:

       $n$  matrix $M/91$ in `double`   matrix from $\sin$ and $\cos$ of $2\arcsin(1/\sqrt{14})$
  -------- --------------------------- ----------------------------------------------------------
      $10$     $2.2\times10^{-15}$                        $1.8\times10^{-15}$
    $10^3$     $2.4\times10^{-13}$                        $8.6\times10^{-14}$
    $10^5$     $2.4\times10^{-11}$                        $7.6\times10^{-12}$
    $10^6$     $2.4\times10^{-10}$                        $7.7\times10^{-11}$

  : Table 4: Deviation $||P_n|^2-7/2|$ in floating point. Exact: $0$ at every step.

The deviation grows in proportion to $n$: it is systematic, not random. Up close, at the tenth step, the figure looks perfect; from afar, after a million steps, the point has left the sphere. This is the phantom of the *Sophist* in numerical language. The deviation comes from the finite representation of numbers such as $1/91$, $\cos2\theta$ and $\sin2\theta$; the route of perfect squares, with quadrances and rational rotations, keeps the identity exact. The measurement supports the thesis in the case studied; it does not prove that every computational error comes from the circle.

## 16. Exact verification

All certificates use exact integers and fractions; no floating point decides anything. There are three sets of programs, with no code shared between them.

**The framework (Sections 4 to 8 and 15).** The program `loop_csc14.py` (Python, exact fractions) performs $25\,035$ exact checks, including the projections of the octahedron, the cube, the tetrahedron $T^+$ and the tetrahedron of edge $7$ at both scales, the crossing of the lateral edges on the circle, the loop up to $n=2000$, the tangents and the helix, with no failure, and catches $16$ sabotages, among them a displaced vertex and a wrong scale. The program `confere_loop_csc14.c` (C) proves non-closure for every $n$ through the modulo-$7$ certificate, checks it up to $n=10^6$ and catches $10$ sabotages; `compara.py` shows that the ten keys shared by the two implementations coincide; `deriva_float.py` produces the table of Section 15. The suite `tetraedro_circulo_3d.html`, a single HTML file with JavaScript, with no dependencies and no need for an internet connection, shows the tetrahedron at any angle, with the circle, the cylinder, the midsphere, the octahedron of the midpoints, the shadow on the $xy$ plane and the $xz$ section, and recomputes the certificates on the page itself with arbitrary-size integers and exact fractions.

**The spiral and the $3n+1$ problem (Sections 9 to 14).** The program `confere_teodoro_collatz.py` (Python, standard library only) records its predictions before running and checks the items of Table 5, plus seven sabotages, deliberately wrong versions that must be rejected, and are. The coordinates of $v_N$ are computed exactly by the recursion itself, as sums $\sum c_s\sqrt s$ with $c_s$ rational and $s$ squarefree; the two coordinates of $v_{25}$ already have $1024$ terms in all, and none is approximated. Not every statement has its own certificate: Proposition 28 is illustrated numerically, and Propositions 23 and 34 and Corollaries 26 and 32 follow directly from the proofs.

  ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
              What it checks                                                                                                                                                                                                                                                                                Range
  ----------- --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- ------------------------
  T1          identity of the telescoping product $\prod_{k<N}(k+1)/k=N$                                                                                                                                                                                                                                    $N\le10^5$

  T2          exact coordinates of $v_N$ in the field generated by $\sqrt2,\sqrt3,\sqrt5,\dots$: $\operatorname{Q}(v_N)=N$, step of quadrance $1$ perpendicular to the radius, spreads $1/(N+1)$ and $N/(N+1)$, $\operatorname{Q}(v_N+tu_N)=N+t^2$, power $M-N$; development and boxes $a\times b\times1$   $N\le25$; $5050$ boxes

  T3          row of $n$ squares: $3n+1$ segments and Euler’s relation                                                                                                                                                                                                                                      $n\le59$

  T4          door $4^k$, $k\ge2$, coming from $(4^k-1)/3$, by complete trajectories                                                                                                                                                                                                                        $n\le10^6$

  T5          rare doors: $\lfloor\log_2(N/p_k)\rfloor+1$                                                                                                                                                                                                                                                   $N=10^6$ and $N=10^9$

  T6          $3n-1$: doors $2\cdot4^k$; only the cycles of $5$ and $17$                                                                                                                                                                                                                                    $n\le10^5$

  T7          $5n+1$: doors $16^k$; cycles of $13$ and $17$                                                                                                                                                                                                                                                 $n\le2\cdot10^4$

  T8          $16$ triangles $<360^\circ<17$ triangles                                                                                                                                                                                                                                                      rational bounds

  T9          progression $S_j$: vertices, tangency at the vertices of $S_{j-1}$, sides                                                                                                                                                                                                                     $j\le60$

  T10         lifted step, with the exact coordinates: quadrance $2$, spread $1/2$ with the plane                                                                                                                                                                                                           $N\le25$

  S1–S7       seven sabotages                                                                                                                                                                                                                                                                               $7/7$ rejected
  ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

  : Table 5: Exact certificates of this article.

The door counts up to $10^9$ come from `porta_quadrado.c`, which stores the door of every number already resolved and uses $128$-bit integers with an overflow test ($28$ seconds, no failure, no overflow); the independent program `porta_quadrado_independente.py` follows each whole trajectory up to the first power of $2$ and reproduces the same counts up to $10^6$. The program `collatz_exato.c` confirms that every $n\le10^{10}$ reaches $1$, without overflow; the longest time to drop below the starting point is that of $2\,788\,008\,987$ ($729$ steps), and the highest peak is that of $8\,528\,817\,511$, which climbs to $18\,144\,594\,937\,356\,598\,024$. The figures use floating point only for drawing; the numbers of Proposition 28 in Figure 14(c) are a numerical illustration of a proved result.

## 17. Principles and arguments of the author

The principles and arguments below are the author’s and guide the whole work; next to each one is the result of this article that develops it.

\(a\) Plane geometry is the projection, on the $xy$ plane, of spatial geometry. The plane circle is the shadow of an object in space, and the $z$ axis, depth, has to be recovered, as in leaving Plato’s cave \[4\]. In the framework: the square with both diagonals is the shadow of the tetrahedron, and the circle with the inscribed and circumscribed squares is the shadow of the octahedron, the cube and the tetrahedron, with the centre on the $z$ axis (Sections 5 and 6). In the spiral: the lift to the paraboloid, in which height is quadrance (Theorem 27), and the development of the diagonals of the cubes (Theorem 24).

\(b\) Exactness comes through perfect squares: measuring quadrances, without $\pi$ and without roots of integers that are not perfect squares. The foundation is the Meno, in which the square on the diagonal has twice the area \[2\], and the Sophist, which distinguishes the proportional image, perfect from near and from afar, from the semblance, which looks beautiful from afar and is crooked up close \[3\]. In the spiral: Theorems 19 and 20 and Proposition 23.

\(c\) The mathematics of the closed circle, with $\pi$, approximate roots and floating point, is a source of systematic error in computing; through perfect squares the error is exactly zero (Section 15). In this article no certificate uses floating point (Section 16).

\(d\) The spiral of Theodorus, always of side $1$, is a specific way of understanding the circle: $N$ is the number of segments of side $1$, and the quadrance of the point is $N$ itself (Theorem 19 and Section 10).

\(e\) The initial point of the spiral is the vertex of an infinite progression of squares inscribed in and circumscribed about the circles, and each radius of this progression is an edge or a diagonal of an inscribed or circumscribed square (Theorem 25 and Corollary 26).

\(f\) The circle is not a prison: the path that reads the circles does not close, climbs in space and has an exit through the centre, through the cosecant $\sqrt{14}$ of triangle $13$ (Sections 7 and 8; Propositions 22 and 28, Theorems 20 and 27). The author reads the return to $1$, in the $3n+1$ problem, as the question about the closed circle; in the spiral, the spread at the centre is $1/(N+1)$, never $1$, and the right angle sits at the point of tangency (Theorem 20).

\(g\) In the $3n+1$ problem, the odd step $3N+1$ is the number of matchsticks in a row of $N$ squares, the even step is the Meno backwards, and, for numbers that are not powers of $2$, the entry into the final descent happens through a perfect square (Proposition 30, Corollary 26 and Theorem 31).

\(h\) The applications that the author proposes for the mathematics of exactness are in physics, including quantum physics, in transport, in systems that demand precision and in artificial intelligence models \[1\].

## 18. Conclusion

The theorems, propositions, lemmas and corollaries of this article, numbered 1 to 35, are proved in full, with elementary arguments, and the identities and counts they assert are checked by exact programs with sabotages, to the extent shown in Section 16. The framework shows that the plane circle is a projection: the square with the diagonals is the shadow of the tetrahedron; the circle with the inscribed and circumscribed squares is the shadow of the octahedron, the cube and the tetrahedron on the sphere of diameter $\sqrt{14}$; the centre is the $z$ axis; the turn of cosecant $\sqrt{14}$ does not close, and the path has an exit through the centre. The spiral of Theodorus is a specific and exact way of understanding the circle: through side $1$, through the integer quadrance, through the progression of squares that starts at the initial point and through the $45^\circ$ ramp on the paraboloid. In the $3n+1$ problem, this reading gives a language in integers, in which the final descent walks down the progression of the initial point and the door is a perfect square, on a circle of integer radius; all trajectories tested, up to $10^{10}$, reach $1$ and, by Theorem 31, those of numbers that are not powers of $2$ enter through that door. On this basis the author states his proposed solution of the Collatz conjecture (Section 13). For the author, this work is a demonstration, from the perspective of the mathematics of exactness, that the circle will not be humanity’s eternal prison.

## References

\[1\] COTA, D. C. D. *Matemática da perfeição e da exatidão quadrática* (Mathematics of perfection and quadratic exactness), version 3.4. Brazil, Oct. 16, 2026.

\[2\] PLATO. *Meno*, 82b–85b.

\[3\] PLATO. *Sophist*, 235d–236c.

\[4\] PLATO. *Republic*, Book VII, 514a–517a.

\[5\] PLATO. *Theaetetus*, 147d–148b.

\[6\] WILDBERGER, N. J. *Divine Proportions: Rational Trigonometry to Universal Geometry*. Wild Egg Books, 2005.

\[7\] RIVLIN, T. J. *The Chebyshev Polynomials*. Wiley, 1974.

\[8\] COXETER, H. S. M. *Regular Polytopes*. 3rd ed. Dover, 1973.

\[9\] EULER, L. Problema algebraicum ob affectiones prorsus singulares memorabile. *Novi Commentarii Acad. Sci. Petropolitanae* 15 (1771), 75–106.

\[10\] RODRIGUES, O. Des lois géométriques qui régissent les déplacements d’un système solide dans l’espace. *J. Math. Pures Appl.* 5 (1840), 380–440.

\[11\] NIVEN, I. *Irrational Numbers*. Mathematical Association of America, 1956.

\[12\] HARDY, G. H.; WRIGHT, E. M. *An Introduction to the Theory of Numbers*. 6th ed. Oxford, 2008, ch. XXIII.

\[13\] DAVIS, P. J. *Spirals: From Theodorus to Chaos*. Wellesley: A K Peters, 1993.

\[14\] TEUFFEL, E. Eine Eigenschaft der Quadratwurzelschnecke. *Mathematisch-Physikalische Semesterberichte* 6 (1958), 148–152.

\[15\] STOUTEN, F. In Theodorus’ spiral no two hypothenusa lie on the same line. arXiv:2403.20207, 2024.

\[16\] APOSTOL, T. M. *Introduction to Analytic Number Theory*. New York: Springer, 1976.

\[17\] LAGARIAS, J. C. (ed.). *The Ultimate Challenge: The $3x+1$ Problem*. Providence: American Mathematical Society, 2010.

\[18\] TERRAS, R. A stopping time problem on the positive integers. *Acta Arithmetica* 30 (1976), 241–252.

\[19\] TAO, T. Almost all orbits of the Collatz map attain almost bounded values. *Forum of Mathematics, Pi* 10 (2022), e12.

\[20\] CONWAY, J. H. Unpredictable iterations. In: *Proceedings of the 1972 Number Theory Conference*. Boulder: University of Colorado, 1972, 49–52.

\[21\] BAŘINA, D. Improved verification limit for the convergence of the Collatz conjecture. *The Journal of Supercomputing* 81 (2025), article 810.

\[22\] IEEE. *IEEE Standard for Floating-Point Arithmetic*, IEEE Std 754-2019.

## Authorship statement

The thesis, the formulation of the problems, the sphere of diameter $\sqrt{14}$, the geometric proposals, the reading of the $3n+1$ problem on the spiral of Theodorus, with $N$ as the number of segments of side $1$, the observation of the progression of inscribed and circumscribed squares from the initial point and the proposed solution are by Davi Cançado Dutra Cota. The proofs, the verification programs, the interactive suite and the figures were prepared with the help of the artificial intelligence assistant Claude (Anthropic) and checked by execution.

*Jesus Christ is THE LORD.*

*The stone rejected by the builders is now the main foundation stone!*
