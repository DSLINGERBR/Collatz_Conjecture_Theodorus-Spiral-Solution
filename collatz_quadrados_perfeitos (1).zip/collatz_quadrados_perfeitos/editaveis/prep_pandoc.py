#!/usr/bin/env python3
"""Prepara um artigo LaTeX para o pandoc: resolve \\ref e \\cite com os números do PDF (arquivo .aux),
numera figuras e tabelas, troca as figuras PDF por PNG e escreve o cabeçalho (frase, título, autor) no corpo.
Uso: python3 prep_pandoc.py artigo.tex artigo.aux idioma(pt|en) saida.tex"""
import re
import sys

tex_path, aux_path, lang, out_path = sys.argv[1:5]
s = open(tex_path, encoding="utf-8").read()
aux = open(aux_path, encoding="utf-8").read()
labels = dict(re.findall(r"\\newlabel\{([^}]*)\}\{\{([^}]*)\}", aux))

corpo = s[s.index("\\begin{document}") + len("\\begin{document}"):s.index("\\end{document}")]
preambulo = s[:s.index("\\begin{document}")]

# macros simples do preâmbulo, repetidas no corpo para o pandoc
macros = "\n".join(l for l in preambulo.splitlines() if l.startswith(("\\newcommand", "\\renewcommand")) and "pedra" not in l and "FloatBarrier" not in l)
macros = macros.replace("\\renewcommand{\\csc}", "\\newcommand{\\csc}")
teoremas = "\n".join(l for l in preambulo.splitlines() if l.startswith(("\\newtheorem", "\\theoremstyle")))

# título, subtítulo, frase
titulo_bruto = re.search(r"\\title\{(.*?)\}\n\\author", preambulo, re.S).group(1)
frase = re.search(r"\\itshape (.*?)\}", titulo_bruto).group(1).replace("\\par", "").strip()
# a epígrafe tem duas linhas (separadas por \\ no LaTeX): cada uma vira um parágrafo em itálico
linhas_frase = [l.strip() for l in re.split(r"\\\\(?:\[[^\]]*\])?", frase) if l.strip()]
epigrafe = "\n\n".join("\\emph{" + l + "}" for l in linhas_frase)
resto = titulo_bruto[titulo_bruto.index("\\textbf{"):]
titulo = re.search(r"\\textbf\{(.*?)\}", resto).group(1)
subtitulo = resto.split("\\large", 1)[1].strip()
subtitulo = re.sub(r"\\\\(\[[^\]]*\])?", " ", subtitulo).strip()
data = re.search(r"\\date\{\\small (.*?)\}", preambulo).group(1)
pais = "Brasil" if lang == "pt" else "Brazil"


def grupo(t, k):
    """Conteúdo e fim do grupo {...} que começa na posição k (chaves aninhadas)."""
    nivel = 0
    for p in range(k, len(t)):
        if t[p] == "{":
            nivel += 1
        elif t[p] == "}":
            nivel -= 1
            if nivel == 0:
                return t[k + 1:p], p + 1
    raise ValueError("chaves desbalanceadas")


while "\\texorpdfstring{" in corpo:
    i = corpo.index("\\texorpdfstring{")
    a, k = grupo(corpo, i + len("\\texorpdfstring"))
    _, k = grupo(corpo, k)
    corpo = corpo[:i] + a + corpo[k:]
corpo = re.sub(r"\\needspace\{[^}]*\}", "", corpo)

bib = re.findall(r"\\bibitem\{([^}]*)\}", corpo)
num = {k: i + 1 for i, k in enumerate(bib)}


def cite(m):
    opt, chaves = m.group(1), m.group(2).split(",")
    nums = ", ".join(str(num[c.strip()]) for c in chaves)
    return f"[{nums}, {opt}]" if opt else f"[{nums}]"


corpo = re.sub(r"\\cite(?:\[([^\]]*)\])?\{([^}]*)\}", cite, corpo)
corpo = re.sub(r"\\ref\{([^}]*)\}", lambda m: labels[m.group(1)], corpo)
corpo = re.sub(r"\\label\{[^}]*\}", "", corpo)                  # rótulos já resolvidos; evita {#rótulo} solto no .md
corpo = corpo.replace("\\bigl|", "|").replace("\\bigr|", "|")     # delimitadores simples convertem melhor
corpo = corpo.replace("\\Bigl(", "\\left(").replace("\\Bigr)", "\\right)")   # o conversor de equações recusa \Bigl( depois de \prod
corpo = re.sub(r"\\bibitem\{([^}]*)\}", lambda m: f"\n\n[{num[m.group(1)]}] ", corpo)
corpo = re.sub(r"\\begin\{thebibliography\}\{[^}]*\}", "\\\\section*{" + ("Referências" if lang == "pt" else "References") + "}\n", corpo)
corpo = corpo.replace("\\end{thebibliography}", "")

# figuras e tabelas numeradas como no PDF
rot_f, rot_t = ("Figura", "Tabela") if lang == "pt" else ("Figure", "Table")
partes, nf, nt, pos = [], 0, 0, 0
for m in re.finditer(r"\\begin\{(figure|table)\}", corpo):
    partes.append(corpo[pos:m.start()])
    fim = corpo.index("\\end{" + m.group(1) + "}", m.start())
    bloco = corpo[m.start():fim]
    if m.group(1) == "figure":
        nf += 1
        bloco = bloco.replace("\\caption{", f"\\caption{{{rot_f} {nf}: ", 1)
    else:
        nt += 1
        bloco = bloco.replace("\\caption{", f"\\caption{{{rot_t} {nt}: ", 1)
    partes.append(bloco)
    pos = fim
partes.append(corpo[pos:])
corpo = "".join(partes)
corpo = re.sub(r"\\includegraphics\[[^\]]*\]\{([^}]*)\.pdf\}", r"\\includegraphics{fig_png/\1.png}", corpo)

# tabela de certificados: no Word a célula tem margem interna maior, então a primeira coluna precisa de mais espaço
corpo = corpo.replace("{@{}p{0.09\\linewidth}>{\\raggedright\\arraybackslash}p{0.6\\linewidth}p{0.24\\linewidth}@{}}",
                      "{@{}p{0.16\\linewidth}p{0.50\\linewidth}p{0.27\\linewidth}@{}}")

# listas rotuladas (a), (b)... viram parágrafos que começam pelo rótulo, como no PDF
corpo = re.sub(r"\\begin\{enumerate\}\s*(?=\\item\[)", "", corpo)
corpo = re.sub(r"\\item\[(\([0-9a-z]+\))\]", r"\n\n\1 ", corpo)
corpo = re.sub(r"\\end\{enumerate\}", "", corpo)

# dentro de enunciados (já em itálico) o \\emph vira negrito, para não aninhar ênfases no .md
def sem_emph(m):
    return m.group(0).replace("\\emph{", "\\textbf{")


corpo = re.sub(r"\\begin\{(teorema|proposicao|corolario|lema|definicao|tese|proposta|theorem|proposition|corollary|lemma|definition|thesis|proposal)\}.*?\\end\{\1\}", sem_emph, corpo, flags=re.S)

# resumo como seção; \paragraph como negrito; limpezas
corpo = corpo.replace("\\begin{abstract}", "\\section*{" + ("Resumo" if lang == "pt" else "Abstract") + "}").replace("\\end{abstract}", "")
corpo = re.sub(r"\\paragraph\{((?:[^{}]|\{[^{}]*\})*)\}", r"\\textbf{\1} ", corpo)
for x in ("\\maketitle", "\\tableofcontents", "\\noindent", "\\FloatBarrier", "\\appendix", "\\centering", "\\small"):
    corpo = corpo.replace(x, "")
corpo = corpo.replace("\\pedra", "\n\n" + epigrafe + "\n\n")
corpo = re.sub(r"\\begin\{center\}\\itshape (.*?)\\end\{center\}",
               lambda m: "\n\n".join("\\emph{" + l.strip() + "}" for l in re.split(r"\\\\", m.group(1)) if l.strip()),
               corpo, flags=re.S)

# seções e subseções numeradas como no PDF, um nível abaixo do título
contador = [0, 0]


def secao(m):
    sub, estrela, titulo = m.group(1), m.group(2), m.group(3)
    if sub:
        if estrela:
            return "\\subsubsection*{" + titulo + "}"
        contador[1] += 1
        return "\\subsubsection*{" + f"{contador[0]}.{contador[1]} " + titulo + "}"
    if estrela:
        return "\\subsection*{" + titulo + "}"
    contador[0] += 1
    contador[1] = 0
    return "\\subsection*{" + f"{contador[0]}. " + titulo + "}"


corpo = re.sub(r"\\(sub)?section(\*?)\{((?:[^{}]|\{[^{}]*\})*)\}", secao, corpo)

cab = (f"{epigrafe}\n\n\\section*{{{titulo}}}\n\n\\textbf{{{subtitulo}}}\n\n"
       f"Davi Cançado Dutra Cota --- {pais} --- {data}\n\n")
saida = ("\\documentclass{article}\n\\usepackage{amsmath,amsthm}\n" + macros + "\n" + teoremas +
         "\n\\begin{document}\n" + cab + corpo + "\n\\end{document}\n")
open(out_path, "w", encoding="utf-8").write(saida)
print(f"{out_path}: {nf} figuras, {nt} tabelas, {len(bib)} referências, {len(labels)} rótulos")
